-- Path of Building
--
-- Module: Import Tab
-- Import/Export tab for the current build.
--
local ipairs = ipairs
local t_insert = table.insert
local t_remove = table.remove
local t_concat = table.concat
local s_format = string.format
local m_max = math.max
local dkjson = require "dkjson"

local tradeHelpers = LoadModule("Classes/TradeHelpers")

local realmList = {
	{ label = "PoE2", id = "PoE2", realmCode = "poe2", hostName = "https://www.pathofexile.com/", profileURL = "account/view-profile/" },
}

---@class ImportTab: ControlHost, Control
local ImportTabClass = newClass("ImportTab", "ControlHost", "Control")

function ImportTabClass:ImportTab(build)
	self:ControlHost()
	self:Control()

	self.build = build
	if not main.api then
		main.api = new("PoEAPI"):PoEAPI(main.lastToken, main.lastRefreshToken, main.tokenExpiry)
	end


	self.charImportMode = "AUTHENTICATION"
	self.charImportStatus = colorCodes.WARNING.."Not authenticated"
	self.controls.sectionCharImport = new("SectionControl"):SectionControl({ "TOPLEFT", self, "TOPLEFT" }, { 10, 18, 650, 200 }, "Character Import")
	self.controls.charImportStatusLabel = new("LabelControl"):LabelControl({ "TOPLEFT", self.controls.sectionCharImport, "TOPLEFT" }, { 6, 14, 200, 16 }, function()
		return "^7Character import status: "..(type(self.charImportStatus) == "function" and self.charImportStatus() or self.charImportStatus)
	end)

	self.controls.logoutApiButton = new("ButtonControl"):ButtonControl({ "TOPLEFT", self.controls.charImportStatusLabel, "TOPRIGHT" }, { 4, 0, 180, 16 }, "^7Logout from Path of Exile API", function()
		main.lastToken = nil
		main.api.authToken = nil
		main.lastRefreshToken = nil
		main.api.refreshToken = nil
		main.tokenExpiry = nil
		main.api.tokenExpiry = nil
		main:SaveSettings()
		self.charImportMode = "AUTHENTICATION"
		self.charImportStatus = colorCodes.WARNING.."Not authenticated"
	end)
	self.controls.logoutApiButton.shown = function()
		return (self.charImportMode == "SELECTCHAR" or self.charImportMode == "GETACCOUNTNAME") and main.api.authToken ~= nil
	end

	self.controls.characterImportAnchor = new("Control"):Control({ "TOPLEFT", self.controls.sectionCharImport, "TOPLEFT" }, { 6, 40, 200, 16 })
	self.controls.sectionCharImport.height = function() return self.charImportMode == "AUTHENTICATION" and 60 or 200 end

	-- Stage: Authenticate
	self.controls.authenticateButton = new("ButtonControl"):ButtonControl({ "TOPLEFT", self.controls.characterImportAnchor, "TOPLEFT" }, { 0, 0, 200, 16 }, "^7Authorize with Path of Exile", function()
		main.api:FetchAuthToken(function(_, errCode)
			if main.api.authToken then
				self.charImportMode = "GETACCOUNTNAME"
				self.charImportStatus = "Authenticated"

				main.lastToken = main.api.authToken
				main.lastRefreshToken = main.api.refreshToken
				main.tokenExpiry = main.api.tokenExpiry
				main:SaveSettings()
				self:DownloadCharacterList()
			elseif errCode and errCode ~= main.api.ERROR_NO_AUTH then
				self.charImportStatus = colorCodes.NEGATIVE .. "Authentication failed: " .. errCode
			else
				self.charImportStatus = colorCodes.WARNING.."Not authenticated"
			end
		end)
		local clickTime = os.time()
		self.charImportStatus = function() return "Logging in... (" .. m_max(0, (clickTime + 60) - os.time()) .. ") - URL copied to clipboard" end
	end)
	self.controls.authenticateButton.shown = function()
		return self.charImportMode == "AUTHENTICATION"
	end

	-- Stage: fetch characters
	self.controls.accountNameHeader = new("LabelControl"):LabelControl({ "TOPLEFT", self.controls.characterImportAnchor, "TOPLEFT" }, { 0, 0, 200, 16 }, "^7To start importing a character, select your character's realm:")
	self.controls.accountNameHeader.shown = function()
		return self.charImportMode == "GETACCOUNTNAME"
	end
	self.controls.accountRealm = new("DropDownControl"):DropDownControl({ "TOPLEFT", self.controls.accountNameHeader, "BOTTOMLEFT" }, { 0, 4, 60, 20 }, realmList)
	self.controls.accountRealm:SelByValue(main.lastRealm or "PC", "id")

	self.controls.accountNameGo = new("ButtonControl"):ButtonControl({ "LEFT", self.controls.accountNameHeader, "RIGHT" }, { 8, 0, 60, 20 }, "Start", function()
		self:DownloadCharacterList()
	end)

	-- Stage: select character and import data
	self.controls.charSelectHeader = new("LabelControl"):LabelControl({ "TOPLEFT", self.controls.sectionCharImport, "TOPLEFT" }, { 6, 40, 200, 16 }, "^7Choose character to import data from:")
	self.controls.charSelectHeader.shown = function()
		return self.charImportMode == "SELECTCHAR" or self.charImportMode == "IMPORTING"
	end
	self.controls.charSelectLeagueLabel = new("LabelControl"):LabelControl({ "TOPLEFT", self.controls.charSelectHeader, "BOTTOMLEFT" }, { 0, 6, 0, 14 }, "^7League:")
	self.controls.charSelectLeague = new("DropDownControl"):DropDownControl({ "LEFT", self.controls.charSelectLeagueLabel, "RIGHT" }, { 4, 0, 150, 18 }, nil, function(index, value)
		self:BuildCharacterList(value.league)
	end)
	self.controls.charSelect = new("DropDownControl"):DropDownControl({ "TOPLEFT", self.controls.charSelectHeader, "BOTTOMLEFT" }, { 0, 24, 400, 18 })
	self.controls.charSelect.enabled = function()
		return self.charImportMode == "SELECTCHAR"
	end
	self.controls.charImportHeader = new("LabelControl"):LabelControl({ "TOPLEFT", self.controls.charSelect, "BOTTOMLEFT" }, { 0, 16, 200, 16 }, "^7Import:")
	self.controls.charImportTree = new("ButtonControl"):ButtonControl({ "LEFT", self.controls.charImportHeader, "RIGHT" }, { 8, 0, 170, 20 }, "Passive Tree and Jewels", function()
		if self.build.spec:CountAllocNodes() > 0 then
			main:OpenConfirmPopup("Character Import", "Importing the passive tree will overwrite your current tree.", "Import", function()
				self:DownloadPassiveTree()
			end)
		else
			self:DownloadPassiveTree()
		end
	end)
	self.controls.charImportTree.enabled = function()
		return self.charImportMode == "SELECTCHAR"
	end
	self.controls.charImportTreeClearJewels = new("CheckBoxControl"):CheckBoxControl({ "LEFT", self.controls.charImportTree, "RIGHT" }, { 90, 0, 18 }, "Delete jewels:", nil, "Delete all existing jewels when importing.", true)
	self.controls.charImportItems = new("ButtonControl"):ButtonControl({ "LEFT", self.controls.charImportTree, "LEFT" }, { 0, 36, 110, 20 }, "Items and Skills", function()
		self:DownloadItems()
	end)
	self.controls.charImportItems.enabled = function()
		return self.charImportMode == "SELECTCHAR"
	end
	self.controls.charImportItemsClearSkills = new("CheckBoxControl"):CheckBoxControl({ "LEFT", self.controls.charImportItems, "RIGHT" }, { 85, 0, 18 }, "Delete skills:", nil, "Delete all existing skills when importing.", true)
	self.controls.charImportItemsClearItems = new("CheckBoxControl"):CheckBoxControl({ "LEFT", self.controls.charImportItems, "RIGHT" }, { 220, 0, 18 }, "Delete equipment:", nil, "Delete all equipped items when importing.", true)
	self.controls.charImportItemsIgnoreWeaponSwap = new("CheckBoxControl"):CheckBoxControl({ "LEFT", self.controls.charImportItems, "RIGHT" }, { 380, 0, 18 }, "Ignore weapon swap:", nil, "Ignore items and skills in weapon swap.", false)

	-- Build import/export
	self.controls.sectionBuild = new("SectionControl"):SectionControl({ "TOPLEFT", self.controls.sectionCharImport, "BOTTOMLEFT", true }, { 0, 18, 650, 182 }, "Build Sharing")
	self.controls.generateCodeLabel = new("LabelControl"):LabelControl({ "TOPLEFT", self.controls.sectionBuild, "TOPLEFT" }, { 6, 14, 0, 16 }, "^7Generate a code to share this build with other Path of Building users:")
	self.controls.generateCode = new("ButtonControl"):ButtonControl({ "LEFT", self.controls.generateCodeLabel, "RIGHT" }, { 4, 0, 80, 20 }, "Generate", function()
		self.controls.generateCodeOut:SetText(common.base64.encode(Deflate(self.build:SaveDB("code"))):gsub("+","-"):gsub("/","_"))
	end)
	self.controls.enablePartyExportBuffs = new("CheckBoxControl"):CheckBoxControl({ "LEFT", self.controls.generateCode, "RIGHT" }, { 100, 0, 18 }, "Export Support", function(state)
		self.build.partyTab.enableExportBuffs = state
		self.build.buildFlag = true
	end, "This is for party play, to export support character, it enables the exporting of auras, curses and modifiers to the enemy", false)
	self.controls.generateCodeOut = new("EditControl"):EditControl({ "TOPLEFT", self.controls.generateCodeLabel, "BOTTOMLEFT" }, { 0, 8, 250, 20 }, "", "Code", "%Z")
	self.controls.generateCodeOut.enabled = function()
		return #self.controls.generateCodeOut.buf > 0
	end
	self.controls.generateCodeCopy = new("ButtonControl"):ButtonControl({ "LEFT", self.controls.generateCodeOut, "RIGHT" }, { 8, 0, 60, 20 }, "Copy", function()
		Copy(self.controls.generateCodeOut.buf)
		self.controls.generateCodeOut:SetText("")
	end)
	self.controls.generateCodeCopy.enabled = function()
		return #self.controls.generateCodeOut.buf > 0
	end

	local getExportSitesFromImportList = function()
		local exportWebsites = { }
		for k,v in pairs(buildSites.websiteList) do
			-- if entry has fields needed for Export
			if buildSites.websiteList[k].postUrl and buildSites.websiteList[k].postFields and buildSites.websiteList[k].codeOut then
				table.insert(exportWebsites, v)
			end
		end
		return exportWebsites
	end
	local exportWebsitesList = getExportSitesFromImportList()

	self.controls.exportFrom = new("DropDownControl"):DropDownControl({ "LEFT", self.controls.generateCodeCopy, "RIGHT" }, { 8, 0, 120, 20 }, exportWebsitesList, function(_, selectedWebsite)
		main.lastExportWebsite = selectedWebsite.id
		self.exportWebsiteSelected = selectedWebsite.id
	end)
	self.controls.exportFrom:SelByValue(self.exportWebsiteSelected or main.lastExportWebsite or "Pastebin", "id")
	self.controls.generateCodeByLink = new("ButtonControl"):ButtonControl({ "LEFT", self.controls.exportFrom, "RIGHT" }, { 8, 0, 100, 20 }, "Share", function()
		local exportWebsite = exportWebsitesList[self.controls.exportFrom.selIndex]
		local subScriptId = buildSites.UploadBuild(self.controls.generateCodeOut.buf, exportWebsite)
		if subScriptId then
			self.controls.generateCodeOut:SetText("")
			self.controls.generateCodeByLink.label = "Creating link..."
			launch:RegisterSubScript(subScriptId, function(pasteLink, errMsg)
				self.controls.generateCodeByLink.label = "Share"
				if errMsg then
					main:OpenMessagePopup(exportWebsite.id, "Error creating link:\n"..errMsg)
				else
					self.controls.generateCodeOut:SetText(exportWebsite.codeOut..pasteLink)
				end
			end)
		end
	end)
	self.controls.generateCodeByLink.enabled = function()
		for _, exportSite in ipairs(exportWebsitesList) do
			if #self.controls.generateCodeOut.buf > 0 and self.controls.generateCodeOut.buf:match(exportSite.matchURL) then
				return false
			end
		end
		return #self.controls.generateCodeOut.buf > 0
	end
	self.controls.exportFrom.enabled = function()
		for _, exportSite in ipairs(exportWebsitesList) do
			if #self.controls.generateCodeOut.buf > 0 and self.controls.generateCodeOut.buf:match(exportSite.matchURL) then
				return false
			end
		end
		return #self.controls.generateCodeOut.buf > 0
	end
	self.controls.generateCodeNote = new("LabelControl"):LabelControl({ "TOPLEFT", self.controls.generateCodeOut, "BOTTOMLEFT" }, { 0, 4, 0, 14 }, "^7Note: this code can be very long; you can use 'Share' to shrink it.")
	self.controls.importCodeHeader = new("LabelControl"):LabelControl({ "TOPLEFT", self.controls.generateCodeNote, "BOTTOMLEFT" }, { 0, 26, 0, 16 }, "^7To import a build, enter URL or code here:")

	local importCodeHandle = function (buf)
		self.importCodeSite = nil
		self.importCodeDetail = ""
		self.importCodeXML = nil
		self.importCodeValid = false
		self.importCodeJson = nil

		if #buf == 0 then
			return
		end

		if not self.build.dbFileName then
			self.controls.importCodeMode.selIndex = 2
		end

		self.importCodeDetail = colorCodes.NEGATIVE.."Invalid input"
		local urlText = buf:gsub("^[%s?]+", ""):gsub("[%s?]+$", "") -- Quick Trim
		if urlText:match("youtube%.com/redirect%?") or urlText:match("google%.com/url%?") then
			local nested_url = urlText:gsub(".*[?&]q=([^&]+).*", "%1")
			urlText = UrlDecode(nested_url)
		end

		for j=1,#buildSites.websiteList do
			if urlText:match(buildSites.websiteList[j].matchURL) then
				self.controls.importCodeIn.text = urlText
				self.importCodeValid = true
				self.importCodeDetail = colorCodes.POSITIVE.."URL is valid ("..buildSites.websiteList[j].label..")"
				self.importCodeSite = j
				if buf ~= urlText then
					self.controls.importCodeIn:SetText(urlText, false)
				end
				return
			end
		end

		-- If we are in dev mode and the string is a json
		if launch.devMode and urlText:match("^%{.*%}$") ~= nil then
			local jsonData, _, errDecode = dkjson.decode(urlText)
			if errDecode then
				self.importCodeDetail = colorCodes.NEGATIVE.."Invalid JSON format (decode error)"
				return
			end
			if not jsonData.character then
				self.importCodeDetail = colorCodes.NEGATIVE.."Invalid JSON format (character missing)"
				return
			end
			jsonData = jsonData.character
			if not jsonData.equipment or not jsonData.passives then
				self.importCodeDetail = colorCodes.NEGATIVE.."Invalid JSON format (equipment or passives missing)"
				return
			end
			self.importCodeJson = jsonData
			self.importCodeDetail = colorCodes.POSITIVE.."JSON is valid"
			self.importCodeValid = true
			return
		end

		local xmlText = Inflate(common.base64.decode(buf:gsub("-","+"):gsub("_","/")))
		if not xmlText then
			return
		end
		if launch.devMode and IsKeyDown("SHIFT") then
			Copy(xmlText)
		end
		self.importCodeValid = true
		self.importCodeDetail = colorCodes.POSITIVE.."Code is valid"
		self.importCodeXML = xmlText
	end

	local importSelectedBuild = function()
		if not self.importCodeValid or self.importCodeFetching then
			return
		end

		if self.controls.importCodeMode.selIndex == 1 then
			main:OpenConfirmPopup("Build Import", colorCodes.WARNING.."Warning:^7 Importing to the current build will erase ALL existing data for this build.", "Import", function()
				self.build:Shutdown()
				self.build:Init(self.build.dbFileName, self.build.buildName, self.importCodeXML, false, self.importCodeSite and self.controls.importCodeIn.buf or nil)
				self.build.viewMode = "TREE"
			end)
		elseif self.controls.importCodeMode.selIndex == 3 then
			-- Import as comparison build
			if self.build.compareTab then
				if self.build.compareTab:ImportBuild(self.importCodeXML, "Imported comparison") then
					self.build.viewMode = "COMPARE"
				else
					main:OpenMessagePopup("Import Error", "Failed to import build for comparison.")
				end
			end
		else
			self.build:Shutdown()
			self.build:Init(false, "Imported build", self.importCodeXML, false, self.importCodeSite and self.controls.importCodeIn.buf or nil)
			self.build.viewMode = "TREE"
		end
	end

	self.controls.importCodeIn = new("EditControl"):EditControl({ "TOPLEFT", self.controls.importCodeHeader, "BOTTOMLEFT" }, { 0, 4, 328, 20 }, "", nil, nil, nil, importCodeHandle, nil, nil, true)
	self.controls.importCodeIn.enterFunc = function()
		if self.importCodeValid then
			self.controls.importCodeGo.onClick()
		end
	end
	self.controls.importCodeState = new("LabelControl"):LabelControl({ "LEFT", self.controls.importCodeIn, "RIGHT" }, { 8, 0, 0, 16 })
	self.controls.importCodeState.label = function()
		return self.importCodeDetail or ""
	end
	self.controls.importCodeMode = new("DropDownControl"):DropDownControl({ "TOPLEFT", self.controls.importCodeIn, "BOTTOMLEFT" }, { 0, 4, 200, 20 }, { "Import to this build", "Import to a new build", "Import as comparison" })
	self.controls.importCodeMode.enabled = function()
		return (self.build.dbFileName or self.controls.importCodeMode.selIndex == 3) and self.importCodeValid
	end
	self.controls.importCodeGo = new("ButtonControl"):ButtonControl({ "LEFT", self.controls.importCodeMode, "RIGHT" }, { 8, 0, 160, 20 }, "Import", function()
		if self.importCodeSite and not self.importCodeXML then
			self.importCodeFetching = true
			local selectedWebsite = buildSites.websiteList[self.importCodeSite]
			buildSites.DownloadBuild(self.controls.importCodeIn.buf, selectedWebsite, function(isSuccess, data)
				self.importCodeFetching = false
				if not isSuccess then
					self.importCodeDetail = colorCodes.NEGATIVE..data
					self.importCodeValid = false
				else
					importCodeHandle(data)
					importSelectedBuild()
				end
			end)
			return
		end

		if self.importCodeJson then
			self:ImportPassiveTreeAndJewels(self.importCodeJson)
			self.build.calcsTab:BuildOutput()
			self:ImportItemsAndSkills(self.importCodeJson)
			return
		end

		importSelectedBuild()
	end)
	self.controls.importCodeGo.label = function ()
		return self.importCodeFetching and "Retrieving paste.." or "Import"
	end
	self.controls.importCodeGo.enabled = function()
		return self.importCodeValid and not self.importCodeFetching
	end
	self.controls.importCodeGo.enterFunc = function()
		if self.importCodeValid then
			self.controls.importCodeGo.onClick()
		end
	end

	-- Path of Exile 2 BuildPlanner export
	local BuildExportPoE2 = require("Modules.BuildExportPoE2")
	local function updateBuildPlannerPath()
		if not self.controls.poe2ExportPath then return end
		local buildName = self.controls.buildPlannerBuildName.buf ~= "" and self.controls.buildPlannerBuildName.buf or self.controls.buildPlannerBuildName.placeholder
		local spec = self.build.treeTab and self.build.treeTab.specList[self.exportSpecIndex]
		self.controls.poe2ExportPath:SetText(BuildExportPoE2.BuildPath(buildName, spec and spec.treeVersion, self.controls.poe2ExportPath.buf))
	end
	self.controls.sectionPoE2Export = new("SectionControl"):SectionControl({ "TOPLEFT", self.controls.sectionBuild, "BOTTOMLEFT", true }, { 0, 18, 650, 330 }, "Export to in-game build planner")
	self.controls.poe2ExportDesc = new("LabelControl"):LabelControl({"TOPLEFT",self.controls.sectionPoE2Export,"TOPLEFT"}, {6, 14, 0, 16}, "^7Save this build as a .build file the in-game build planner can load.")
	self.controls.poe2ExportDesc2 = new("LabelControl"):LabelControl({ "TOPLEFT", self.controls.poe2ExportDesc, "BOTTOMLEFT" }, { 0, 2, 0, 14 }, "^8Each file holds one passive tree, one skill set and one item set.")

	self.controls.buildPlannerBuildName = new("EditControl"):EditControl({ "TOPLEFT", self.controls.poe2ExportDesc2, "BOTTOMLEFT" }, { 0, 8, 200, 20 }, nil, "Build name", nil, nil, function()
		updateBuildPlannerPath()
	end)
	self.controls.buildPlannerBuildName:SetPlaceholder("Unnamed Build")
	self.controls.buildPlannerAuthorName = new("EditControl"):EditControl({"LEFT",self.controls.buildPlannerBuildName,"RIGHT"}, {8, 0, 200, 20}, nil, "Author name", nil, nil)
	self.controls.buildPlannerAuthorName:SetPlaceholder("Author")
	self.controls.buildPlannerTreeLabel = new("LabelControl"):LabelControl({ "TOPLEFT", self.controls.buildPlannerBuildName, "BOTTOMLEFT" }, { 0, 8, 0, 16 }, "^7Tree")
	self.controls.buildPlannerSkillLabel = new("LabelControl"):LabelControl({ "TOPLEFT", self.controls.buildPlannerBuildName, "BOTTOMLEFT" }, { 188, 8, 0, 16 }, "^7Skill")
	self.controls.buildPlannerItemLabel = new("LabelControl"):LabelControl({ "TOPLEFT", self.controls.buildPlannerBuildName, "BOTTOMLEFT" }, { 376, 8, 0, 16 }, "^7Item")
	self.controls.buildPlannerSpec = new("DropDownControl"):DropDownControl({ "TOPLEFT", self.controls.buildPlannerTreeLabel, "BOTTOMLEFT" }, { 0, 2, 180, 20 }, {}, function(index, value)
		self.exportSpecIndex = value.key
		updateBuildPlannerPath()
	end, "^7Which passive tree to export")
	self.controls.buildPlannerSkillSet = new("DropDownControl"):DropDownControl({ "LEFT", self.controls.buildPlannerSpec, "RIGHT" }, { 8, 0, 180, 20 }, {}, function(index, value)
		self.exportSkillSetId = value.key
	end, "^7Which skill set to export")
	self.controls.buildPlannerItemSet = new("DropDownControl"):DropDownControl({ "LEFT", self.controls.buildPlannerSkillSet, "RIGHT" }, { 8, 0, 180, 20 }, {}, function(index, value)
		self.exportItemSetId = value.key
	end, "^7Which item set to export")
	self.controls.buildPlannerUseGeneratedItemText = new("CheckBoxControl"):CheckBoxControl({ "TOPLEFT", self.controls.buildPlannerSpec, "BOTTOMLEFT" }, { 0, 2, 18 }, "Generated text for empty item notes", function()
		self.build.modFlag = true
	end, "^7For items without a note, generate a note that contains the current mods, item name and item base", true)
	self.controls.buildPlannerUseGeneratedItemText.labelRight = true
	self:RefreshBuildPlannerSets()

	self.controls.buildPlannerDescLabel = new("LabelControl"):LabelControl({ "TOPLEFT", self.controls.buildPlannerSpec, "BOTTOMLEFT" }, { 0, 28, 0, 16 }, "^7Description:")
	self.controls.buildPlannerDescription = new("EditControl"):EditControl({"TOPLEFT",self.controls.buildPlannerDescLabel,"BOTTOMLEFT"}, {0, 8, 560, 64}, "", nil, "^%C\t\n", nil, nil, 16)
	self.controls.poe2ExportPath = new("EditControl"):EditControl({ "TOPLEFT", self.controls.buildPlannerDescription, "BOTTOMLEFT" }, { 0, 8, 560, 20 }, BuildExportPoE2.BuildPath(self.controls.buildPlannerBuildName.placeholder), "Path", nil, 260)
	updateBuildPlannerPath()
	self.controls.poe2ExportPath.shown = function() return self.controls.poe2ExportShowPath.state end
	self.controls.poe2ExportPathDisplay = new("LabelControl"):LabelControl({ "TOPLEFT", self.controls.buildPlannerDescription, "BOTTOMLEFT" }, { 0, 10, 0, 16 }, function()
		return "^8Save location: " .. BuildExportPoE2.DisplayPath(self.controls.poe2ExportPath.buf)
	end)
	self.controls.poe2ExportPathDisplay.shown = function() return not self.controls.poe2ExportShowPath.state end
	local function displayPath(path)
		return self.controls.poe2ExportShowPath.state and path or BuildExportPoE2.DisplayPath(path)
	end
	self.controls.poe2ExportOpenFolder = new("ButtonControl"):ButtonControl({ "TOPLEFT", self.controls.buildPlannerDescription, "BOTTOMLEFT" }, { 0, 36, 110, 20 }, "Open Folder", function()
		local path = self.controls.poe2ExportPath.buf
		local directory = path:match("^(.*[/\\])") or "."
		local err = OpenURL(directory)
		if err then
			main:OpenMessagePopup("Error", "Couldn't open the folder:\n" .. displayPath(directory) .. "\n\n" .. err)
		end
	end)
	self.controls.poe2ExportOpenFolder.tooltipText = "^7Open the BuildPlanner export folder."
	self.controls.poe2ExportShowPath = new("CheckBoxControl"):CheckBoxControl({ "LEFT", self.controls.poe2ExportOpenFolder, "RIGHT" }, { 120, 1, 18 }, "Show full path", nil, "^7Reveal the editable absolute save path.", false)
	self.controls.poe2ExportSave = new("ButtonControl"):ButtonControl({ "TOPLEFT", self.controls.buildPlannerDescription, "BOTTOMLEFT" }, { 0, 64, 140, 20 }, "Export Selected Sets", function()
		local path = self.controls.poe2ExportPath.buf
		local function doWrite()
			local ok, err = BuildExportPoE2.WriteFile(self.build, path, self:GetBuildPlannerMetadata(), {
				specIndex = self.exportSpecIndex,
				skillSetId = self.exportSkillSetId,
				itemSetId = self.exportItemSetId,
			})
			if not ok then
				main:OpenMessagePopup("Error", "Couldn't save the build file to:\n" .. displayPath(path) .. "\n\n" .. err .. "\nMake sure the save folder exists and is writable.")
			else
				main:OpenMessagePopup("Success", string.format("Build file exported successfully to:\n%s", displayPath(path)))
			end
		end
		-- Confirm overwrite if the file already exists.
		local existing = io.open(path, "r")
		if existing then
			existing:close()
			main:OpenConfirmPopup("Overwrite?", "A file already exists at:\n" .. displayPath(path) .. "\n\nOverwrite it?", "Overwrite", doWrite)
		else
			doWrite()
		end
	end)
	self.controls.poe2ExportSave.enabled = function()
		return self.controls.poe2ExportPath.buf and self.controls.poe2ExportPath.buf ~= ""
	end
	self.controls.poe2ExportSave.tooltipText = "^7Writes a single file containing the three sets picked above."
	self.controls.poe2ExportSaveAll = new("ButtonControl"):ButtonControl({ "LEFT", self.controls.poe2ExportSave, "RIGHT" }, { 8, 0, 140, 20 }, "Export All Loadouts", function()
		local path = self.controls.poe2ExportPath.buf
		local loadouts = BuildExportPoE2.GetLoadouts(self.build)
		local function doWrite()
			local written, errors = BuildExportPoE2.WriteAllLoadouts(self.build, path, self:GetBuildPlannerMetadata(), loadouts)
			local displayedPaths = {}
			for _, writtenPath in ipairs(written) do
				t_insert(displayedPaths, displayPath(writtenPath))
			end
			local msg = s_format("Wrote %d file(s):\n%s", #written, t_concat(displayedPaths, "\n"))
			if #errors > 0 then
				msg = msg .. s_format("\n\n%d failed:\n%s", #errors, t_concat(errors, "\n"))
			end
			main:OpenMessagePopup("Loadout export", msg)
		end
		local existingFiles = {}
		for _, loadout in ipairs(loadouts) do
			local spec = BuildExportPoE2.ResolveSelection(self.build, loadout)
			local loadoutPath = BuildExportPoE2.LoadoutPath(path, loadout.fileName or loadout.name, spec and spec.treeVersion)
			local existing = io.open(loadoutPath, "r")
			if existing then
				existing:close()
				t_insert(existingFiles, loadoutPath:match("([^/\\]+)$"))
			end
		end
		if #existingFiles > 0 then
			main:OpenConfirmPopup("Overwrite?",
				s_format("%d file(s) already exist:\n%s\n\nOverwrite them?", #existingFiles, t_concat(existingFiles, "\n")),
				"Overwrite", doWrite)
		else
			doWrite()
		end
	end)
	self.controls.poe2ExportSaveAll.enabled = function()
		return self.controls.poe2ExportPath.buf and self.controls.poe2ExportPath.buf ~= ""
	end
	self.controls.poe2ExportSaveAll.tooltipText = "^7Exports one file per loadout. The loadout name is appended to each filename."

	-- validate the status of the api the first time
	self:RefreshAuthStatus()
	return self
end

-- Metadata shared by both export buttons.
function ImportTabClass:GetBuildPlannerMetadata()
	return {
		name = self.controls.buildPlannerBuildName.buf ~= "" and self.controls.buildPlannerBuildName.buf or self.controls.buildPlannerBuildName.placeholder,
		author = self.controls.buildPlannerAuthorName.buf ~= "" and self.controls.buildPlannerAuthorName.buf or self.controls.buildPlannerAuthorName.placeholder,
		description = self.controls.buildPlannerDescription.buf,
		useGeneratedItemText = self.controls.buildPlannerUseGeneratedItemText.state,
	}
end

-- Rebuild the three set dropdowns
function ImportTabClass:RefreshBuildPlannerSets()
	local build = self.build
	if not (build and build.treeTab and build.skillsTab and build.itemsTab) then return end

	-- these shouldn't really ever be empty as even a fresh build will have default sets active
	local treeList = {}
	for index, spec in ipairs(build.treeTab.specList) do
		t_insert(treeList, { label = spec.title or "Default", key = index })
	end

	local skillList = {}
	for _, setId in ipairs(build.skillsTab.skillSetOrderList) do
		local skillSet = build.skillsTab.skillSets[setId]
		if skillSet then
			t_insert(skillList, { label = skillSet.title or "Default", key = setId })
		end
	end

	local itemList = {}
	for _, setId in ipairs(build.itemsTab.itemSetOrderList) do
		local itemSet = build.itemsTab.itemSets[setId]
		if itemSet then
			t_insert(itemList, { label = itemSet.title or "Default", key = setId })
		end
	end

	self.controls.buildPlannerSpec:SetList(treeList)
	self.controls.buildPlannerSkillSet:SetList(skillList)
	self.controls.buildPlannerItemSet:SetList(itemList)

	-- ensure selected index is in bounds and that something is selected
	self.controls.buildPlannerSpec.selIndex = nil
	self.controls.buildPlannerSkillSet.selIndex = nil
	self.controls.buildPlannerItemSet.selIndex = nil
	self.controls.buildPlannerSpec:SetSel(1)
	self.controls.buildPlannerSkillSet:SetSel(1)
	self.controls.buildPlannerItemSet:SetSel(1)
end
function ImportTabClass:RefreshAuthStatus()
	main.api:ValidateAuth(function(valid, updateSettings)
			if valid then
				if self.charImportMode == "AUTHENTICATION" then
					self.charImportMode = "GETACCOUNTNAME"
					self.charImportStatus = "Authenticated"
				end
				if updateSettings then
					self:SaveApiSettings()
				end
			else
				self.charImportMode = "AUTHENTICATION"
				self.charImportStatus = colorCodes.WARNING.."Not authenticated"
			end
		end)
end

function ImportTabClass:SaveApiSettings()
	main.lastToken = main.api.authToken
	main.lastRefreshToken = main.api.refreshToken
	main.tokenExpiry = main.api.tokenExpiry
	main:SaveSettings()
end

function ImportTabClass:Load(xml, fileName)
	self.lastRealm = xml.attrib.lastRealm
	self.controls.accountRealm:SelByValue(self.lastRealm or main.lastRealm or "PC", "id")
	self.lastLeague = xml.attrib.lastLeague
	self.controls.charSelectLeague:SelByValue(self.lastLeague or "Standard", "id")
	self.lastAccountHash = xml.attrib.lastAccountHash
	self.importLink = xml.attrib.importLink
	self.controls.enablePartyExportBuffs.state = xml.attrib.exportParty == "true"
	self.build.partyTab.enableExportBuffs = self.controls.enablePartyExportBuffs.state
	self.controls.buildPlannerUseGeneratedItemText.state = xml.attrib.useGeneratedItemText ~= "false"
	if self.lastAccountHash then
		for accountName in pairs(main.gameAccounts) do
			if common.sha1(accountName) == self.lastAccountHash then
				self.controls.accountName:SetText(accountName)
			end
		end
	end
	self.lastCharacterHash = xml.attrib.lastCharacterHash
end

function ImportTabClass:Save(xml)
	xml.attrib = {
		lastRealm = self.lastRealm,
		lastLeague = self.lastLeague,
		lastAccountHash = self.lastAccountHash,
		lastCharacterHash = self.lastCharacterHash,
		exportParty = tostring(self.controls.enablePartyExportBuffs.state),
		useGeneratedItemText = tostring(self.controls.buildPlannerUseGeneratedItemText.state),
		importLink = self.importLink
	}

	if self.build.importLink then
		xml.attrib.importLink = self.build.importLink
	end
	-- Gets rid of erroneous, potentially infinitely nested full base64 XML stored as an import link
	xml.attrib.importLink = (xml.attrib.importLink and xml.attrib.importLink:len() < 100) and xml.attrib.importLink or nil
end

function ImportTabClass:Draw(viewPort, inputEvents)
	self.x = viewPort.x
	self.y = viewPort.y
	self.width = viewPort.width
	self.height = viewPort.height

	self:ProcessControlsInput(inputEvents, viewPort)

	main:DrawBackground(viewPort)

	self:DrawControls(viewPort)
end

function ImportTabClass:DownloadCharacterList()
	function FindMatchingStandardLeague(league)
		-- Find a Standard league name for a given league name
		-- Reference https://api.pathofexile.com/league?realm=pc
		if string.find(league, "Hardcore") then
			return "Hardcore"
		elseif string.find(league, "HC SSF") then
			-- includes Ruthless "HC SSF R "
			return "SSF Hardcore"
		elseif string.find(league, "SSF") then
			-- Any non HardCore SSF's - includes Ruthless "SSF R "
			return "SSF Standard"
		else
			-- normal league and ruthless league (Sanctum, Ruthless Sanctum)
			return "Standard"
		end
	end

	self.charImportMode = "DOWNLOADCHARLIST"
	self.charImportStatus = "Retrieving character list..."
	local realm = realmList[self.controls.accountRealm.selIndex]
	main.api:DownloadCharacterList(realm.realmCode, function(body, errMsg, updateSettings)
		if updateSettings then
			self:SaveApiSettings()
		end
		if errMsg == main.api.ERROR_NO_AUTH then
			self.charImportMode = "AUTHENTICATION"
			self.charImportStatus = colorCodes.WARNING.."Not authenticated"
			return
		elseif errMsg == "Response code: 401" then
			self.charImportStatus = colorCodes.NEGATIVE.."Sign-in is required."
			self.charImportMode = "GETSESSIONID"
			return
		elseif errMsg == "Response code: 403" then
			self.charImportStatus = colorCodes.NEGATIVE.."Account profile is private."
			self.charImportMode = "GETSESSIONID"
			return
		elseif errMsg == "Response code: 404" then
			self.charImportStatus = colorCodes.NEGATIVE.."Account name is incorrect."
			self.charImportMode = "GETACCOUNTNAME"
			return
		elseif errMsg == "Response code: 429" then
			self.charImportStatus = function() return colorCodes.NEGATIVE.."Requests are being sent too fast, try again in " .. tostring(m_max(0, body - os.time())) .. " seconds." end
			self.charImportMode = "GETACCOUNTNAME"
			return
		elseif errMsg then
			self.charImportStatus = colorCodes.NEGATIVE.."Error retrieving character list, try again ("..errMsg:gsub("\n"," ")..")"
			self.charImportMode = "GETACCOUNTNAME"
			return
		end
		local charList, _pos, errDecode = dkjson.decode(body)
		if errDecode then
			self.charImportStatus = colorCodes.NEGATIVE.."Error processing character list, try again later"
			self.charImportMode = "GETACCOUNTNAME"
			return
		end
		charList = charList.characters
		--ConPrintTable(charList)
		if #charList == 0 then
			self.charImportStatus = colorCodes.NEGATIVE.."The account has no characters to import."
			self.charImportMode = "GETACCOUNTNAME"
			return
		end

		self.charImportStatus = "Character list successfully retrieved."
		self.charImportMode = "SELECTCHAR"
		self.lastRealm = realm.id
		main.lastRealm = realm.id
		local leagueList = { }
		for i, char in ipairs(charList) do
			-- validate if the class have internal class
			if self.build.latestTree.internalAscendNameMap[char.class] ~= nil then
				char.class = self.build.latestTree.internalAscendNameMap[char.class].ascendClass.name
			end
			if not isValueInArray(leagueList, char.league) then
				t_insert(leagueList, char.league)
			end
		end
		table.sort(leagueList)
		charSelectLeague = self.controls.charSelectLeague
		wipeTable(self.controls.charSelectLeague.list)
		for _, league in ipairs(leagueList) do
			t_insert(self.controls.charSelectLeague.list, {
				label = league,
				league = league,
			})
		end
		t_insert(self.controls.charSelectLeague.list, {
			label = "All",
		})
		-- set the league combo to the last used if possible, used for previously imported characters
			if self.lastLeague then
				charSelectLeague:SelByValue(self.lastLeague, "league")
				-- check that it worked
				if charSelectLeague:GetSelValueByKey("league") ~= self.lastLeague then
					-- League maybe over, Character will be in standard
					local standardLeagueName = FindMatchingStandardLeague(self.lastLeague)
					self.controls.charSelectLeague:SelByValue(standardLeagueName, "league")
					if charSelectLeague:GetSelValueByKey("league") ~= standardLeagueName then
						-- give up and select the first entry. Ruthless mode may not have Standard equivalents
						charSelectLeague.selIndex = 1
					else
						self.lastLeague = standardLeagueName
					end
				end
			else
				if self.controls.charSelectLeague.selIndex > #self.controls.charSelectLeague.list then
					self.controls.charSelectLeague.selIndex = 1
				end
		end
		self.lastCharList = charList
		self:BuildCharacterList(self.controls.charSelectLeague:GetSelValueByKey("league"))
	end)
end

function ImportTabClass:BuildCharacterList(league)
	wipeTable(self.controls.charSelect.list)
	for i, char in ipairs(self.lastCharList) do
		if not league or char.league == league then
			charLvl = char.level or 0
			charLeague = char.league or "?"
			charName = char.name or "?"
			charClass = char.class or "?"

			classColor = colorCodes.DEFAULT
			if charClass ~= "?" then
				local tree = main:LoadTree(latestTreeVersion)
				local ascendClass = tree and tree.ascendNameMap[charClass]
				local baseClassName = ascendClass and ascendClass.class.name
				classColor = colorCodes[charClass:upper()] or (baseClassName and colorCodes[baseClassName:upper()]) or "^7"
			end

			local detail
			if league == nil then
				detail = string.format("%s%s ^x808080lvl %d in %s", classColor, charClass, charLvl, charLeague)
			else
				detail = string.format("%s%s ^x808080lvl %d", classColor, charClass, charLvl)
			end
			t_insert(self.controls.charSelect.list, {
				label = charName,
				char = char,
				searchFilter = charName.." "..charClass,
				detail = detail
			})
		end
	end
	table.sort(self.controls.charSelect.list, function(a,b)
		return a.char.name:lower() < b.char.name:lower()
	end)
	self.controls.charSelect.selIndex = 1
	if self.lastCharacterHash then
		for i, char in ipairs(self.controls.charSelect.list) do
			if common.sha1(char.char.name) == self.lastCharacterHash then
				self.controls.charSelect.selIndex = i
				break
			end
		end
	end
end

function ImportTabClass:DownloadCharacter(callback)
	self.charImportMode = "IMPORTING"
	self.charImportStatus = "Retrieving character data..."
	local realm = realmList[self.controls.accountRealm.selIndex]
	local charSelect = self.controls.charSelect
	local charData = charSelect.list[charSelect.selIndex].char
	main.api:DownloadCharacter(realm.realmCode, charData.name, function(body, errMsg, updateSettings)
		self.charImportMode = "SELECTCHAR"
		if updateSettings then
			self:SaveApiSettings()
		end
		if errMsg then
			if errMsg == main.api.ERROR_NO_AUTH then
				self.charImportMode = "AUTHENTICATION"
				self.charImportStatus = colorCodes.WARNING.."Not authenticated"
				return
			elseif errMsg == "Response code: 429" then
				self.charImportStatus = function() return colorCodes.NEGATIVE.."Requests are being sent too fast, try again in " .. tostring(m_max(0, body - os.time())) .. " seconds." end
				self.charImportMode = "GETACCOUNTNAME"
				return
			else
				self.charImportStatus = colorCodes.NEGATIVE.."Error importing character data, try again ("..errMsg:gsub("\n"," ")..")"
				return
			end
		elseif body == "false" then
			self.charImportStatus = colorCodes.NEGATIVE.."Failed to retrieve character data, try again."
			return
		end
		self.lastCharacterHash = common.sha1(charData.name)
		if not self.lastLeague then
			self.lastLeague = charSelectLeague:GetSelValueByKey("league")
		end
		--local out = io.open("get-passive-skills.json", "w")
		--out:write(json)
		--out:close()
		local fullCharData, _pos, errParsing = dkjson.decode(body)
		--local out = io.open("get-passive-skills.json", "w")
		--writeLuaTable(out, charPassiveData, 1)
		--out:close()

		if errParsing then
			self.charImportStatus = colorCodes.NEGATIVE.."Error processing character data, try again later."
			return
		end
		fullCharData = fullCharData.character
		charSelect.list[charSelect.selIndex].char = fullCharData
		callback(fullCharData)
	end)
end

function ImportTabClass:DownloadPassiveTree()
	self:DownloadCharacter(function(charData)
		self:ImportPassiveTreeAndJewels(charData)
	end)
end

function ImportTabClass:DownloadItems()
	self:DownloadCharacter(function(charData)
		self:ImportItemsAndSkills(charData)
	end)
end

function ImportTabClass:ImportQuestRewardConfig(questStats)
	local configTab = self.build.configTab

	-- Reduce a stat line to a numberless key + value (e.g. "+30 to [Spirit|Spirit]" -> "+# to spirit", 30)
	local function statKey(text)
		text = escapeGGGString(text):lower():gsub("^%s+", ""):gsub("%s+$", "")
		return tradeHelpers.modLineTemplate(text), tradeHelpers.modLineValue(text) or 0
	end

	local statTotals = {}
	local updated = false
	for _, stat in ipairs(questStats) do
		local key, value = statKey(stat)
		if key == "# broken boss faces" then
			if configTab.placeholder.configBossFaceBroken ~= value then
				configTab.placeholder.configBossFaceBroken = value
				updated = true
			end
		else
			statTotals[key] = (statTotals[key] or 0) + value
		end
	end

	-- Stats shared by 3+ quests can't be split greedily (two +30 Spirit quests make 40/70 ambiguous),
	-- so resolve those by exact total then zero their totals.
	local disambiguation = {
		["+# to spirit"] = {
			[30] = { "King In The Mists" },
			[40] = { "Lythara" },
			[60] = { "King In The Mists", "Ignagduk" },
			[70] = { "King In The Mists", "Lythara" },
			[100] = { "King In The Mists", "Ignagduk", "Lythara" },
		},
	}
	local resolved = {}
	for stat, byTotal in pairs(disambiguation) do
		local taken = byTotal[statTotals[stat] or 0]
		if taken then
			for _, info in ipairs(taken) do resolved[info] = true end
			statTotals[stat] = 0
		end
	end

	local function splitLine(text)
		local out = {}
		for line in tostring(text):gmatch("[^\r\n]+") do
			local key, value = statKey(line)
			t_insert(out, { key = key, value = value })
		end
		return out
	end

	-- True if the totals still hold every line of the reward; consume them so a later quest can't reclaim it
	local function matchQuest(requiredLines)
		for _, line in ipairs(requiredLines) do
			if (statTotals[line.key] or 0) < line.value then
				return false
			end
		end
		for _, line in ipairs(requiredLines) do
			statTotals[line.key] = statTotals[line.key] - line.value
		end
		return true
	end

	for _, quest in ipairs(data.questRewards) do
		if quest.useConfig == true then
			local var = "quest" .. quest.Description .. quest.Area .. quest.Info
			if quest.Stat then
				local matches = resolved[quest.Info] or matchQuest(splitLine(quest.Stat))
				if configTab.input[var] ~= matches then
					configTab.input[var] = matches
					updated = true
				end
			elseif quest.Options then
				local selected = configTab.defaultState[var] or "None"
				for _, option in ipairs(quest.Options) do
					if matchQuest(splitLine(option)) then
						selected = option
						break
					end
				end
				if configTab.input[var] ~= selected then
					configTab.input[var] = selected
					updated = true
				end
			end
		end
	end

	if updated then
		configTab:BuildModList()
		configTab:UpdateControls()
		configTab.modFlag = true
		self.build.buildFlag = true
	end
end

function ImportTabClass:ImportPassiveTreeAndJewels(charData)
	local charPassiveData = charData.passives
	self.charImportStatus = colorCodes.POSITIVE.."Passive tree and jewels successfully imported."
	self.build.spec.jewel_data = copyTable(charPassiveData.jewel_data)
	--ConPrintTable(charPassiveData)
	if self.controls.charImportTreeClearJewels.state then
		for _, slot in pairs(self.build.itemsTab.slots) do
			if slot.selItemId ~= 0 and slot.nodeId then
				self.build.itemsTab.build.spec.ignoreAllocatingSubgraph = true -- ignore allocated cluster nodes on Import when Delete Jewel is true, clean slate
				self.build.itemsTab:DeleteItem(self.build.itemsTab.items[slot.selItemId])
			end
		end
	end
	for _, itemData in ipairs(charData.jewels) do
		self:ImportItem(itemData)
	end
	self.build.itemsTab:PopulateSlots()
	self.build.itemsTab:AddUndoState()

	local hashes = copyTable(charPassiveData.hashes, true)
	local weaponSets = {}
	for setName, nodesId in pairs(charPassiveData.specialisations) do
		local weaponSet = tonumber(setName:match("^set(%d)"))
		for _, nodeId in ipairs(nodesId) do
			weaponSets[nodeId] = weaponSet
			t_insert(hashes, nodeId)
		end
	end

	self.build.spec:ImportFromNodeList(charData.class, nil, nil, charPassiveData.alternate_ascendancy or 0, hashes, weaponSets, {}, charPassiveData.mastery_effects or {}, latestTreeVersion)

	-- workaround to update the ui to last option
	self.build.treeTab.controls.versionSelect.selIndex = #self.build.treeTab.treeVersions
	-- attributes nodes
	for skillId, nodeInfo in pairs(charPassiveData.skill_overrides) do
		local changeAttributeId = 0
		if nodeInfo.name == "Intelligence" then
			changeAttributeId = 3
		elseif nodeInfo.name == "Dexterity" then
			changeAttributeId = 2
		elseif nodeInfo.name == "Strength" then
			changeAttributeId = 1
		end

		if changeAttributeId > 0 then
			local id = tonumber(skillId)
			self.build.spec:SwitchAttributeNode(id, changeAttributeId)
			local node = self.build.spec.nodes[id]

			if node then
				self.build.spec:ReplaceNode(node, self.build.spec.hashOverrides[id])
			end
		end
	end

	self.build.spec:AddUndoState()
	self:ImportQuestRewardConfig(charPassiveData.quest_stats)
	if not self.lastLeague then
		self.lastLeague = charSelectLeague and charSelectLeague:GetSelValueByKey("league")
	end
	self.build.characterLevel = charData.level
	self.build.characterLevelAutoMode = false
	self.build.configTab:UpdateLevel()
	self.build.controls.characterLevel:SetText(charData.level)
	self.build:EstimatePlayerProgress()
	local resistancePenaltyIndex = 7
	if self.build.Act then -- Estimate resistance penalty setting based on act progression estimate
		if type(self.build.Act) == "string" and self.build.Act == "Endgame" then resistancePenaltyIndex = 7
		elseif type(self.build.Act) == "number" then
			if self.build.Act > 6 then resistancePenaltyIndex = 7
			elseif self.build.Act < 1 then resistancePenaltyIndex = 1
			else resistancePenaltyIndex = self.build.Act end
		end
	end
	self.build.configTab.varControls["resistancePenalty"]:SetSel(resistancePenaltyIndex)
	self.build.buildFlag = true
	main:SetWindowTitleSubtext(string.format("%s (%s, %s, %s)", self.build.buildName, charData.name, charData.class, charData.league))
end

local SOCKET_GROUP_REIMPORT_KEY_SEPARATOR = "\31"

local function getSocketGroupReimportKey(socketGroup)
	-- Use a rarely-used separator to avoid accidental collisions when concatenating fields.
	local gemNameParts = { }
	for _, gem in ipairs(socketGroup.gemList) do
		t_insert(gemNameParts, (gem.nameSpec or ""):lower())
	end
	return table.concat({
		tostring(#socketGroup.gemList),
		table.concat(gemNameParts, SOCKET_GROUP_REIMPORT_KEY_SEPARATOR),
	}, SOCKET_GROUP_REIMPORT_KEY_SEPARATOR)
end

local function snapshotSocketGroupReimportState(socketGroup, isMainGroup)
	local gemStates = { }
	for gemIndex, gem in ipairs(socketGroup.gemList) do
		gemStates[gemIndex] = {
			enabled = gem.enabled,
			count = gem.count,
			statSet = gem.statSet and copyTable(gem.statSet),
			statSetCalcs = gem.statSetCalcs and copyTable(gem.statSetCalcs),
			skillPart = gem.skillPart,
			skillPartCalcs = gem.skillPartCalcs,
			skillStageCount = gem.skillStageCount,
			skillStageCountCalcs = gem.skillStageCountCalcs,
			skillMineCount = gem.skillMineCount,
			skillMineCountCalcs = gem.skillMineCountCalcs,
			skillMinion = gem.skillMinion,
			skillMinionCalcs = gem.skillMinionCalcs,
			skillMinionItemSet = gem.skillMinionItemSet,
			skillMinionItemSetCalcs = gem.skillMinionItemSetCalcs,
			skillMinionSkill = gem.skillMinionSkill,
			skillMinionSkillCalcs = gem.skillMinionSkillCalcs,
			skillMinionSkillStatSetIndexLookup = gem.skillMinionSkillStatSetIndexLookup and copyTable(gem.skillMinionSkillStatSetIndexLookup),
			skillMinionSkillStatSetIndexLookupCalcs = gem.skillMinionSkillStatSetIndexLookupCalcs and copyTable(gem.skillMinionSkillStatSetIndexLookupCalcs),
			enableGlobal1 = gem.enableGlobal1,
			enableGlobal2 = gem.enableGlobal2,
		}
	end
	return {
		enabled = socketGroup.enabled,
		includeInFullDPS = socketGroup.includeInFullDPS,
		groupCount = socketGroup.groupCount,
		label = socketGroup.label,
		mainActiveSkill = socketGroup.mainActiveSkill,
		mainActiveSkillCalcs = socketGroup.mainActiveSkillCalcs,
		gemStates = gemStates,
		isMainGroup = isMainGroup,
	}
end

local function applyGemReimportState(gem, state)
	gem.enabled = state.enabled
	gem.count = state.count
	gem.statSet = state.statSet and copyTable(state.statSet)
	gem.statSetCalcs = state.statSetCalcs and copyTable(state.statSetCalcs)
	gem.skillPart = state.skillPart
	gem.skillPartCalcs = state.skillPartCalcs
	gem.skillStageCount = state.skillStageCount
	gem.skillStageCountCalcs = state.skillStageCountCalcs
	gem.skillMineCount = state.skillMineCount
	gem.skillMineCountCalcs = state.skillMineCountCalcs
	gem.skillMinion = state.skillMinion
	gem.skillMinionCalcs = state.skillMinionCalcs
	gem.skillMinionItemSet = state.skillMinionItemSet
	gem.skillMinionItemSetCalcs = state.skillMinionItemSetCalcs
	gem.skillMinionSkill = state.skillMinionSkill
	gem.skillMinionSkillCalcs = state.skillMinionSkillCalcs
	gem.skillMinionSkillStatSetIndexLookup = state.skillMinionSkillStatSetIndexLookup and copyTable(state.skillMinionSkillStatSetIndexLookup)
	gem.skillMinionSkillStatSetIndexLookupCalcs = state.skillMinionSkillStatSetIndexLookupCalcs and copyTable(state.skillMinionSkillStatSetIndexLookupCalcs)
	gem.enableGlobal1 = state.enableGlobal1
	gem.enableGlobal2 = state.enableGlobal2
end

local function applySocketGroupReimportState(socketGroup, state)
	socketGroup.enabled = state.enabled
	socketGroup.includeInFullDPS = state.includeInFullDPS
	socketGroup.groupCount = state.groupCount
	socketGroup.label = state.label
	socketGroup.mainActiveSkill = state.mainActiveSkill
	socketGroup.mainActiveSkillCalcs = state.mainActiveSkillCalcs
	if state.gemStates then
		for gemIndex, gemState in ipairs(state.gemStates) do
			if socketGroup.gemList[gemIndex] then
				applyGemReimportState(socketGroup.gemList[gemIndex], gemState)
			end
		end
	end
end

function ImportTabClass:ImportItemsAndSkills(charData)
	local charItemData = charData.equipment
	if self.controls.charImportItemsClearItems.state then
		for _, slot in pairs(self.build.itemsTab.slots) do
			if slot.selItemId ~= 0 and not slot.nodeId then
				self.build.itemsTab:DeleteItem(self.build.itemsTab.items[slot.selItemId])
			end
		end
		for _, slotName in ipairs(self.build.itemsTab.runeSlotOrder) do
			self.build.itemsTab.runeSlots[slotName]:SelByValue("None", "name")
			self.build.itemsTab.activeItemSet[slotName].runeName = "None"
		end
	end

	local mainSkillEmpty = #self.build.skillsTab.socketGroupList == 0
	local skillOrder
	local preservedSocketGroupStateByKey
	if self.controls.charImportItemsClearSkills.state then
		skillOrder = { }
		preservedSocketGroupStateByKey = { }
		for _, socketGroup in ipairs(self.build.skillsTab.socketGroupList) do
			for _, gem in ipairs(socketGroup.gemList) do
				if gem.grantedEffect and not gem.grantedEffect.support then
					t_insert(skillOrder, gem.grantedEffect.name)
				end
			end
		end
		for index, socketGroup in ipairs(self.build.skillsTab.socketGroupList) do
			local key = getSocketGroupReimportKey(socketGroup)
			preservedSocketGroupStateByKey[key] = preservedSocketGroupStateByKey[key] or { }
			t_insert(preservedSocketGroupStateByKey[key], snapshotSocketGroupReimportState(socketGroup, index == self.build.mainSocketGroup))
		end
		wipeTable(self.build.skillsTab.socketGroupList)
		self.build.skillsTab.controls.groupList.selIndex = nil
		self.build.skillsTab.controls.groupList.selValue = nil
		self.build.skillsTab:SetDisplayGroup()
	end
	self.charImportStatus = colorCodes.POSITIVE.."Items and skills successfully imported."
	--ConPrintTable(charItemData)
	for _, itemData in ipairs(charItemData) do
		self:ImportItem(itemData)
	end

	local funcGetGemInstance = function(skillData)
		local typeLine = sanitiseText(skillData.typeLine) .. (skillData.support and " Support" or "")
		local gemId = self.build.data.gemForBaseName[typeLine:lower()]

		if typeLine:match("^Spectre:") then
			gemId = "Metadata/Items/Gems/SkillGemSummonSpectre"
		end
		if typeLine:match("^Companion:") then
			gemId = "Metadata/Items/Gems/SkillGemSummonBeast"
		end

		-- Prefer the character skill requirement, then fall back to equipped items for older responses and dual wielding.
		if typeLine:match("Mace Strike") then
			local weaponRequirement = skillData.weaponRequirements and skillData.weaponRequirements[1]
			local requiredWeaponType = weaponRequirement and escapeGGGString(weaponRequirement.values[1][1])
			local weapon1Sel = self.build.itemsTab.activeItemSet["Weapon 1"] and self.build.itemsTab.activeItemSet["Weapon 1"].selItemId or 0
			local weapon2Sel = self.build.itemsTab.activeItemSet["Weapon 2"] and self.build.itemsTab.activeItemSet["Weapon 2"].selItemId or 0
			if requiredWeaponType == "Two Hand Mace" then
				gemId = "Metadata/Items/Gems/SkillGemPlayerDefault2HMace"
			elseif weapon2Sel == 0 then
				if weapon1Sel == 0 or self.build.itemsTab.items[weapon1Sel].base.type == "One Hand Mace" then -- Facebreaker uses single handed mace strike
					gemId = "Metadata/Items/Gems/SkillGemPlayerDefault1HMace"
				elseif self.build.itemsTab.items[weapon1Sel].base.type == "Two Hand Mace" then
					gemId = "Metadata/Items/Gems/SkillGemPlayerDefault2HMace"
				end
			else
				if self.build.itemsTab.items[weapon2Sel].base.type == "One Hand Mace" or self.build.itemsTab.items[weapon2Sel].base.type == "Two Hand Mace" then
					gemId = "Metadata/Items/Gems/SkillGemPlayerDefaultMaceMace" -- Dual wielding maces
				elseif self.build.itemsTab.items[weapon1Sel].base.type == "One Hand Mace" then
					gemId = "Metadata/Items/Gems/SkillGemPlayerDefault1HMace"
				elseif self.build.itemsTab.items[weapon1Sel].base.type == "Two Hand Mace" then
					gemId = "Metadata/Items/Gems/SkillGemPlayerDefault2HMace"
				end
			end
		end
		if typeLine:match("Spear Stab") and (self.build.itemsTab.activeItemSet["Weapon 2"].selItemId or 0) ~= 0 then
			gemId = "Metadata/Items/Gems/SkillGemPlayerDefaultSpearOffHand"
		end

		if gemId then
			local gemInstance = { level = 20, quality = 0, enabled = true, enableGlobal1 = true, enableGlobal2 = true, count = 1,  gemId = gemId }
			gemInstance.support = skillData.support
			gemInstance.corrupted = skillData.corrupted

			local spectreList = data.spectres
			if typeLine:sub(1, 8) == "Spectre:" then
				local spectreName = typeLine:sub(10) -- gets monster name after "Spectre: "
				for _, property in pairs(skillData.properties) do
					if property.name == "Reservation" and property.values and property.values[1] and property.values[1][1] then
						-- Example: "42 [Spirit]"
						local reservationValue = property.values[1][1]:match("(%d+)")
						if reservationValue then
							gemInstance.reservation = tonumber(reservationValue)
						end
					end
				end
				for id, spectre in pairs(spectreList) do
					if spectre.name == spectreName and gemInstance.reservation == spectre.spectreReservation then
						if not isValueInArray(self.build.spectreList, id) then
							t_insert(self.build.spectreList, id)
						end
						gemInstance.skillMinion = id -- Sets imported minion in dropdown on left
						gemInstance.skillMinionCalcs = id-- Sets imported minion in dropdown in calcs tab
						break
					end
				end
			end
			if typeLine:sub(1, 10) == "Companion:" then
				local companionName = typeLine:sub(12)
				for _, property in pairs(skillData.properties) do
					if property.name == "Reservation" and property.values and property.values[1] and property.values[1][1] then
						-- Example: "42.3% [Spirit]"
						local companionReservation = property.values[1][1]:match("([%d%.]+)%%?")
						if companionReservation then
							gemInstance.companionReservation = tonumber(companionReservation)
						end
					end
				end
				for id, spectre in pairs(spectreList) do
					if spectre.name == companionName and gemInstance.companionReservation == spectre.companionReservation then
						if not isValueInArray(self.build.beastList, id) then
							t_insert(self.build.beastList, id)
						end
						gemInstance.skillMinion = id
						gemInstance.skillMinionCalcs = id
						break
					end
				end
			end

			gemInstance.nameSpec = self.build.data.gems[gemId].name
			for _, property in pairs(skillData.properties) do
				if property.name == "Level" then
					if skillData.properties[_ + 1] and skillData.properties[_ + 1].values[1][1]:match("(%d+) Level[s]? from Gem") then
						gemInstance.level = tonumber(skillData.properties[_ + 1].values[1][1]:match("(%d+) Level[s]? from Gem"))
					else
						gemInstance.level = tonumber(property.values[1][1]:match("%d+"))
					end
					if skillData.properties[_ + 2] and skillData.properties[_ + 2].values[1][1]:match("(-?%d+) Level[s]? from Corruption") then
						gemInstance.corruptLevel = tonumber(skillData.properties[_ + 2].values[1][1]:match("(-?%d+) Level[s]? from Corruption"))
					else
						gemInstance.corruptLevel = 0
					end
				elseif escapeGGGString(property.name) == "Quality" then
					gemInstance.quality = tonumber(property.values[1][1]:match("%d+"))
				end
			end

			return gemInstance
		end
		return nil
	end
	for _, skillData in pairs(charData.skills) do
		local gemInstance = funcGetGemInstance(skillData)

		if gemInstance then
			local group = { label = "", enabled = true, gemList = { } }
			t_insert(group.gemList, gemInstance )

			if skillData.socketedItems then
				for _, anotherSkillData in pairs(skillData.socketedItems) do
					local anotherGemInstance = funcGetGemInstance(anotherSkillData)
					if anotherGemInstance then
						t_insert(group.gemList, anotherGemInstance )
					end
				end
			end

			t_insert(self.build.skillsTab.socketGroupList, group)
			self.build.skillsTab:ProcessSocketGroup(group)
		end
	end

	if skillOrder then
		local groupOrder = { }
		for index, socketGroup in ipairs(self.build.skillsTab.socketGroupList) do
			groupOrder[socketGroup] = index
		end
		table.sort(self.build.skillsTab.socketGroupList, function(a, b)
			local orderA
			for _, gem in ipairs(a.gemList) do
				if gem.grantedEffect and not gem.grantedEffect.support then
					local i = isValueInArray(skillOrder, gem.grantedEffect.name)
					if i and (not orderA or i < orderA) then
						orderA = i
					end
				end
			end
			local orderB
			for _, gem in ipairs(b.gemList) do
				if gem.grantedEffect and not gem.grantedEffect.support then
					local i = isValueInArray(skillOrder, gem.grantedEffect.name)
					if i and (not orderB or i < orderB) then
						orderB = i
					end
				end
			end
			if orderA and orderB then
				if orderA ~= orderB then
					return orderA < orderB
				else
					return groupOrder[a] < groupOrder[b]
				end
			elseif not orderA and not orderB then
				return groupOrder[a] < groupOrder[b]
			else
				return orderA
			end
		end)
	end
	if preservedSocketGroupStateByKey then
		local restoredMainSocketGroup
		for index, socketGroup in ipairs(self.build.skillsTab.socketGroupList) do
			local stateList = preservedSocketGroupStateByKey[getSocketGroupReimportKey(socketGroup)]
			if stateList and stateList[1] then
				local state = t_remove(stateList, 1)
				applySocketGroupReimportState(socketGroup, state)
				if state.isMainGroup then
					restoredMainSocketGroup = index
				end
			end
		end
		if restoredMainSocketGroup then
			self.build.mainSocketGroup = restoredMainSocketGroup
		end
	end
	if mainSkillEmpty then
		self.build.mainSocketGroup = self:GuessMainSocketGroup()
	end
	self.build.calcsTab:BuildOutput()
	self.build.itemsTab:PopulateSlots()
	self.build.itemsTab:AddUndoState()
	self.build.skillsTab:AddUndoState()
	self.build.characterLevel = charData.level
	self.build.configTab:UpdateLevel()
	self.build.controls.characterLevel:SetText(charData.level)
	self.build.buildFlag = true
	return charData -- For the wrapper
end

local rarityMap = { [0] = "NORMAL", "MAGIC", "RARE", "UNIQUE", [9] = "RELIC", [10] = "RELIC", [11] = "NORMAL", [12] = "MAGIC", [13] = "RARE", [14] = "UNIQUE" }
local slotMap = { ["Weapon"] = "Weapon 1", ["Offhand"] = "Weapon 2", ["Weapon2"] = "Weapon 1 Swap", ["Offhand2"] = "Weapon 2 Swap", ["Helm"] = "Helmet", ["BodyArmour"] = "Body Armour", ["Gloves"] = "Gloves", ["Boots"] = "Boots", ["Amulet"] = "Amulet", ["Ring"] = "Ring 1", ["Ring2"] = "Ring 2", ["Ring3"] = "Ring 3", ["Belt"] = "Belt", ["IncursionArmLeft"] = "Arm 2", ["IncursionArmRight"] = "Arm 1", ["IncursionLegLeft"] = "Leg 2", ["IncursionLegRight"] = "Leg 1" }

function ImportTabClass:ImportItem(itemData, slotName)
	if not slotName then
		if itemData.inventoryId == "Chakra" then
			slotName = self.build.itemsTab.runeSlotOrder[itemData.x + 1]
			local slot = slotName and self.build.itemsTab.runeSlots[slotName]
			if slot and itemData.baseType then
				slot:SelByValue(itemData.baseType, "name")
				if slot:GetSelValue().name == itemData.baseType then
					self.build.itemsTab.activeItemSet[slotName].runeName = itemData.baseType
				end
				return
			end
		elseif itemData.inventoryId == "PassiveJewels" then
			slotName = "Jewel ".. self.build.latestTree.jewelSlots[itemData.x + 1]
		elseif itemData.inventoryId == "Flask" then
			if itemData.x > 1 then
				slotName = "Charm " .. (itemData.x - 1)
			else
				slotName = "Flask "..(itemData.x + 1)
			end
		elseif not (self.controls.charImportItemsIgnoreWeaponSwap.state and (itemData.inventoryId == "Weapon2" or itemData.inventoryId == "Offhand2")) then
			slotName = slotMap[itemData.inventoryId]
		end
	end
	if not slotName then
		-- Ignore any items that won't go into known slots
		return
	end

	local item = new("Item"):Item()

	-- Determine rarity, display name and base type of the item
	item.rarity = rarityMap[itemData.frameType]
	if #itemData.name > 0 then
		item.title = sanitiseText(itemData.name)
		item.baseName = sanitiseText(itemData.typeLine):gsub("Synthesised ","")
		item.name = item.title .. ", " .. item.baseName
		if item.baseName == "Two-Toned Boots" then
			-- Hack for Two-Toned Boots
			item.baseName = "Two-Toned Boots (Armour/Energy Shield)"
		end
		item.base = self.build.data.itemBases[item.baseName]
		if item.base then
			item.type = item.base.type
		else
			ConPrintf("Unrecognised base in imported item: %s", item.baseName)
		end
	else
		item.name = sanitiseText(itemData.typeLine)
		if item.name:match("Energy Blade") then
			local oneHanded = false
			for _, p in ipairs(itemData.properties) do
				if self.build.data.weaponTypeInfo[p.name] and self.build.data.weaponTypeInfo[p.name].oneHand then
					oneHanded = true
					break
				end
			end
			item.name = oneHanded and "Energy Blade One Handed" or "Energy Blade Two Handed"
			item.rarity = "NORMAL"
			itemData.implicitMods = { }
			itemData.explicitMods = { }
		end
		for baseName, baseData in pairs(self.build.data.itemBases) do
			local s, e = item.name:find(baseName, 1, true)
			if s then
				item.baseName = baseName
				item.namePrefix = item.name:sub(1, s - 1)
				item.nameSuffix = item.name:sub(e + 1)
				item.type = baseData.type
				break
			end
		end
		if not item.baseName then
			local s, e = item.name:find("Two-Toned Boots", 1, true)
			if s then
				-- Hack for Two-Toned Boots
				item.baseName = "Two-Toned Boots (Armour/Energy Shield)"
				item.namePrefix = item.name:sub(1, s - 1)
				item.nameSuffix = item.name:sub(e + 1)
				item.type = "Boots"
			end
		end
		item.base = self.build.data.itemBases[item.baseName]
	end
	if not item.base or not item.rarity then
		return
	end

	-- Import item data
	item.uniqueID = itemData.id
	if itemData.ilvl > 0 then
		item.itemLevel = itemData.ilvl
	end
	if item.base.quality then
		item.quality = 0
	end
	if itemData.properties then
		for _, property in pairs(itemData.properties) do
			local propertyName = escapeGGGString(property.name)
			if propertyName == "Quality" then
				item.quality = tonumber(property.values[1][1]:match("%d+"))
			elseif propertyName == "Radius" then
				item.jewelRadiusLabel = property.values[1][1]
			elseif propertyName == "Limited to" then
				item.limit = tonumber(property.values[1][1])
			elseif propertyName == "Evasion Rating" then
				if item.baseName == "Two-Toned Boots (Armour/Energy Shield)" then
					-- Another hack for Two-Toned Boots
					item.baseName = "Two-Toned Boots (Armour/Evasion)"
					item.base = self.build.data.itemBases[item.baseName]
				end
			elseif propertyName == "Energy Shield" then
				if item.baseName == "Two-Toned Boots (Armour/Evasion)" then
					-- Yet another hack for Two-Toned Boots
					item.baseName = "Two-Toned Boots (Evasion/Energy Shield)"
					item.base = self.build.data.itemBases[item.baseName]
				end
			end
			if propertyName == "Energy Shield" or propertyName == "Runic Ward" or propertyName == "Armour" or propertyName == "Evasion Rating" then
				item.armourData = item.armourData or { }
				local defenceType = propertyName:gsub("Runic Ward", "Ward"):gsub(" Rating", ""):gsub(" ", "")
				for _, value in ipairs(property.values) do
					item.armourData[defenceType] = (item.armourData[defenceType] or 0) + tonumber(value[1])
				end
			end
		end
	end
	item.mirrored = itemData.duplicated or itemData.mirrored
	item.corrupted = itemData.corrupted
	item.sanctified = itemData.sanctified
	item.doubleCorrupted = itemData.doubleCorrupted
	item.fractured = itemData.fractured
	item.desecrated = itemData.desecrated
	item.mutated = itemData.mutated
	if itemData.sockets and itemData.sockets[1] then
		item.sockets = { }
		item.itemSocketCount = 0
		item.jewelSocketCount = 0
		for i, socket in pairs(itemData.sockets) do
			if socket.type == "jewel" then
				item.jewelSocketCount = item.jewelSocketCount + 1
			else
				item.sockets[i] = { }
				item.itemSocketCount = item.itemSocketCount + 1
			end
		end
	end

	item.runes = { }
	if itemData.socketedItems then
		self:ImportSocketedItems(item, itemData.socketedItems, slotName, itemData.sockets)
	end
	if itemData.requirements and (not itemData.socketedItems or not itemData.socketedItems[1]) then
		-- Requirements cannot be trusted if there are socketed gems, as they may override the item's natural requirements
		item.requirements = { }
		for _, req in ipairs(itemData.requirements) do
			if req.name == "Level" then
				item.requirements.level = req.values[1][1]
			elseif req.name == "Class:" then
				item.classRestriction = req.values[1][1]
			elseif req.name == "Charm Slots:" then
				item.charmLimit = req.values[1][1]
			end
		end
	end
	local dbItem = item:GetUniqueDBItem()
	if dbItem then
		item.requirements = item.requirements or { }
		item.requirements.level = dbItem.requirements.naturalLevel or dbItem.requirements.level
	end
	item.enchantModLines = { }
	item.runeModLines = { }
	item.classRequirementModLines = { }
	item.implicitModLines = { }
	item.explicitModLines = { }
	if itemData.enchantMods then
		for _, line in ipairs(itemData.enchantMods) do
			for line in line:gmatch("[^\n]+") do
				local modList, extra = modLib.parseMod(line)
				t_insert(item.enchantModLines, { line = line, extra = extra, mods = modList or { }, enchant = true })
			end
		end
	end
	if itemData.runeMods then
		for _, line in ipairs(itemData.runeMods) do
			for line in line:gmatch("[^\n]+") do
				local modList, extra = modLib.parseMod(line)
				t_insert(item.runeModLines, { line = line, extra = extra, mods = modList or { }, enchant = true, rune = true })
			end
		end
	end
	if itemData.implicitMods then
		for _, itemMod in ipairs(itemData.implicitMods) do
			local modLine = itemMod.description or itemMod
			for line in modLine:gmatch("[^\n]+") do
				local modList, extra = modLib.parseMod(line)
				t_insert(item.implicitModLines, { line = line, extra = extra, mods = modList or { } })
			end
		end
	end
	-- TODO: Remove once 3.29 releases https://www.pathofexile.com/developer/docs/changelog#3-29-0
	if itemData.fracturedMods then
		for _, line in ipairs(itemData.fracturedMods) do
			for line in line:gmatch("[^\n]+") do
				local modList, extra = modLib.parseMod(line)
				t_insert(item.explicitModLines, { line = line, extra = extra, mods = modList or { }, fractured = true })
			end
		end
	end
	if itemData.explicitMods then
		for _, itemMod in ipairs(itemData.explicitMods) do
			local modLine = itemMod.description or itemMod
			local flags = itemMod.flags or itemMod
			for line in modLine:gmatch("[^\n]+") do
				local modList, extra = modLib.parseMod(line)
				t_insert(item.explicitModLines, { line = line, extra = extra, mods = modList or { },
					fractured = flags.fractured,
					crafted = flags.crafted,
					mutated = flags.mutated })
			end
		end
	end
	if itemData.desecratedMods then
		for _, line in ipairs(itemData.desecratedMods) do
			for line in line:gmatch("[^\n]+") do
				local modList, extra = modLib.parseMod(line)
				t_insert(item.explicitModLines, { line = line, extra = extra, mods = modList or { }, desecrated = true })
			end
		end
	end
	-- TODO: Remove once 3.29 releases https://www.pathofexile.com/developer/docs/changelog#3-29-0
	if itemData.mutatedMods then
		for _, line in ipairs(itemData.mutatedMods) do
			for line in line:gmatch("[^\n]+") do
				local modList, extra = modLib.parseMod(line)
				t_insert(item.explicitModLines, { line = line, extra = extra, mods = modList or { }, mutated = true })
			end
		end
	end
	-- TODO: Remove once 3.29 releases https://www.pathofexile.com/developer/docs/changelog#3-29-0
	if itemData.craftedMods then
		for _, line in ipairs(itemData.craftedMods) do
			for line in line:gmatch("[^\n]+") do
				local modList, extra = modLib.parseMod(line)
				t_insert(item.explicitModLines, { line = line, extra = extra, mods = modList or { }, crafted = true })
			end
		end
	end

	if itemData.grantedSkills then
		for _, grantedSkillInfo in ipairs(itemData.grantedSkills) do
			local level = grantedSkillInfo.values and #grantedSkillInfo.values > 0 and #grantedSkillInfo.values[1] > 0 and grantedSkillInfo.values[1][1] or "unknown"
			local grantedSkills =  string.format(
				"%s: %s",
				grantedSkillInfo.name,
				level
			)
			local modList, extra = modLib.parseMod(grantedSkills)
			t_insert(item.implicitModLines, { line = grantedSkills, extra = extra, mods = modList or { } })
		end
	end

	-- Sometimes flavour text has actual mods that PoB cares about
	-- Right now, the only known one is "This item can be anointed by Cassia"
	if itemData.flavourText then
		for _, line in ipairs(itemData.flavourText) do
			for line in line:gmatch("[^\n]+") do
				-- Remove any text outside of curly braces, if they exist.
				-- This fixes lines such as:
				--   "<default>{This item can be anointed by Cassia}"
				-- To now be:
				--   "This item can be anointed by Cassia"
				local startBracket = line:find("{")
				local endBracket = line:find("}")
				if startBracket and endBracket and endBracket > startBracket then
					line = line:sub(startBracket + 1, endBracket - 1)
				end

				-- If the line parses, then it should be included as an explicit mod
				local modList, extra = modLib.parseMod(line)
				if modList then
					t_insert(item.explicitModLines, { line = line, extra = extra, mods = modList or { } })
				end
			end
		end
	end

	-- Add and equip the new item
	item:BuildAndParseRaw()
	--ConPrintf("%s", item.raw)
	if item.base then
		local repIndex, repItem
		for index, item in pairs(self.build.itemsTab.items) do
			if item.uniqueID == itemData.id then
				repIndex = index
				repItem = item
				break
			end
		end
		if repIndex then
			-- Item already exists in the build, overwrite it
			item.id = repItem.id
			self.build.itemsTab.items[item.id] = item
			item:BuildModList()
		else
			self.build.itemsTab:AddItem(item, true)
		end
		if self.build.itemsTab.slots[slotName] then
			self.build.itemsTab.slots[slotName]:SetSelItemId(item.id)
		else
			ConPrintf("Unrecognised slot name in imported item: %s", slotName)
		end
	end
end

function ImportTabClass:ImportSocketedItems(item, socketedItems, slotName, sockets)
	-- Build socket group list
	for _, socketedItem in ipairs(socketedItems) do
		if isValueInTable({ "Diamond", "Emerald", "Ruby", "Sapphire" }, socketedItem.baseType) then
			local jewelSocketIndex = socketedItem.socket + 1
			if sockets then
				for index = 1, socketedItem.socket + 1 do
					if sockets[index] and sockets[index].type ~= "jewel" then
						jewelSocketIndex = jewelSocketIndex - 1
					end
				end
			end
			self:ImportItem(socketedItem, slotName .. " Jewel Socket "..jewelSocketIndex)
		else
			t_insert(item.runes, socketedItem.baseType)
		end
	end
end

-- Return the index of the group with the most gems
function ImportTabClass:GuessMainSocketGroup()
	local largestGroupSize = 0
	local largestGroupIndex = 1
	for i, socketGroup in ipairs(self.build.skillsTab.socketGroupList) do
		if #socketGroup.gemList > largestGroupSize then
			largestGroupSize = #socketGroup.gemList
			largestGroupIndex = i
		end
	end
	return largestGroupIndex
end

function HexToChar(x)
	return string.char(tonumber(x, 16))
end

function UrlDecode(url)
	if url == nil then
		return
	end
	url = url:gsub("+", " ")
	url = url:gsub("%%(%x%x)", HexToChar)
	return url
end

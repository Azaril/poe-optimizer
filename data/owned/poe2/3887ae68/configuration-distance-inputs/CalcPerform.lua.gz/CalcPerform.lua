-- Path of Building
--
-- Module: Calc Perform
-- Manages the offence/defence calculations.
--
---@class Calcs
local calcs = require("Modules.CalcBase")

local pairs = pairs
local ipairs = ipairs
local t_insert = table.insert
local t_remove = table.remove
local m_min = math.min
local m_max = math.max
local m_ceil = math.ceil
local m_floor = math.floor
local m_modf = math.modf
local s_format = string.format
local m_huge = math.huge

--- getCachedOutputValue
---  retrieves a value specified by key from a cached version of skill
---  specified by @uuid or if not found in cache computes teh cache.
---@param env Env
---@param activeSkill ActiveSkill Active skill to use as main when calculating output values
---@param ... string Keys of values to return
---@return any ... Cached output values
local function getCachedOutputValue(env, activeSkill, ...)
	local uuid = cacheSkillUUID(activeSkill, env)
	if not GlobalCache.cachedData[env.mode][uuid] or env.mode == "CALCULATOR" then
		calcs.buildActiveSkill(env, env.mode, activeSkill, uuid, {[uuid] = true})
	end

	local tempValues = {}
	for i,v in ipairs({...}) do
		tempValues[i] = GlobalCache.cachedData[env.mode][uuid].Env.player.output[v]
	end
	return unpack(tempValues)
end

-- Merge an instance of a buff, taking the highest value of each modifier
local function mergeBuff(src, destTable, destKey)
	if not destTable[destKey] then
		destTable[destKey] = new("ModList"):ModList()
	end
	local dest = destTable[destKey]
	for _, mod in ipairs(src) do
		local match = false
		if mod.type ~= "LIST" then
			for index, destMod in ipairs(dest) do
				if modLib.compareModParams(mod, destMod) then
					if type(destMod.value) == "number" and mod.value > destMod.value then
						dest[index] = mod
					end
					match = true
					break
				end
			end
		end
		if not match then
			t_insert(dest, mod)
		end
	end
end

-- Mageblood Legacies
local legacies = {
	LegacyOfAmethyst = {
		effects = {
			{ stat = "ChaosResist", type = "BASE", value = 45 },
		}
	},
	LegacyOfBasalt = {
		effects = {
			{ stat = "Armour", type = "INC", value = 150 },
		}
	},
	LegacyOfBismuth = {
		effects = {
			{ stat = "ElementalResist", type = "BASE", value = 45 },
		}
	},
	LegacyOfDiamond = {
		effects = {
			{ stat = "CritChance", type = "INC", value = 75 },
		}
	},
	LegacyOfGold = {
		effects = {
			{ stat = "LootRarity", type = "INC", value = 45 },
		}
	},
	LegacyOfGranite = {
		effects = {
			{ stat = "Armour", type = "BASE", value = 2000 },
		}
	},
	LegacyOfJade = {
		effects = {
			{ stat = "Evasion", type = "BASE", value = 2000 },
		}
	},
	LegacyOfQuicksilver = {
		effects = {
			{ stat = "MovementSpeed", type = "INC", value = 30 },
		}
	},
	LegacyOfRuby = {
		effects = {
			{ stat = "FireResist", type = "BASE", value = 60 },
			{ stat = "FireResistMax", type = "BASE", value = 5 },
		}
	},
	LegacyOfSapphire = {
		effects = {
			{ stat = "ColdResist", type = "BASE", value = 60 },
			{ stat = "ColdResistMax", type = "BASE", value = 5 },
		}
	},
	LegacyOfSilver = {
		effects = {
			{ stat = "Speed", type = "INC", value = 30 },
			{ stat = "WarcrySpeed", type = "INC", value = 30 },
			{ stat = "TotemPlacementSpeed", type = "INC", value = 30 },
		}
	},
	LegacyOfStibnite = {
		effects = {
			{ stat = "Evasion", type = "INC", value = 150 },
		}
	},
	LegacyOfSulphur = {
		effects = {
			{ stat = "Damage", type = "INC", value = 60 },
		}
	},
	LegacyOfTopaz = {
		effects = {
			{ stat = "LightningResist", type = "BASE", value = 60 },
			{ stat = "LightningResistMax", type = "BASE", value = 5 },
		}
	},
}

-- Merge keystone modifiers
---@param env Env
local function mergeKeystones(env)
	for _, modObj in ipairs(env.modDB:Tabulate("LIST", nil, "Keystone")) do
		if not env.keystonesAdded[modObj.value] and env.spec.tree.keystoneMap[modObj.value] then
			env.keystonesAdded[modObj.value] = true
			local fromTree = modObj.mod.source and not modObj.mod.source:lower():match("tree")
			for _, mod in ipairs(env.spec.tree.keystoneMap[modObj.value].modList) do
				env.modDB:AddMod(fromTree and modLib.setSource(mod, modObj.mod.source) or mod)
			end
		end
	end
end
-- Add certain weapon base stats to output for use as "Stat" in mods like Tactician's ""Watch How I Do It" Ascendancy notable" and Amazon's "Penetrate"
-- Note: This might run into issues with Energy Blade, Shapeshifting or similar mechanics that could "replace" the weapon items, but it's hard to test because PoE2 doesn't have those mechanics yet
---@param actor Actor
local function addWeaponBaseStats(actor)
	local output = actor.output
	local dmgTypeList = {"Physical", "Lightning", "Cold", "Fire", "Chaos"} -- Note: we're using local dmgTypeList vars a lot, might be better to eventually just use a global since it presumably won't change
	for i in pairs({ "1", "2" }) do
		-- Section for martial weapons only for now
		if actor.itemList["Weapon " .. i] and actor.itemList["Weapon " .. i].base and actor.itemList["Weapon " .. i].base.weapon then
			-- Add base min and max damage
			for _, damageType in ipairs(dmgTypeList) do
				if actor.itemList["Weapon " .. i] and actor["weaponData" .. i][damageType .. "Min"] then
					output[damageType .. "Min" .. "OnWeapon " .. i] = actor["weaponData" .. i][damageType .. "Min"]
				end
				if actor["weaponData" .. i][damageType .. "Max"] then
					output[damageType .. "Max" .. "OnWeapon " .. i] = actor["weaponData" .. i][damageType .. "Max"]
				end
			end
			-- Add total local accuracy
			output["AccuracyOnWeapon " .. i] = actor.itemList["Weapon " .. i].baseModList:Sum("BASE", nil, "Accuracy")
		end
	end
end

local function hasActiveSkillExposureSource(activeSkill, modName)
	return activeSkill.skillModList and activeSkill.skillCfg
		and (activeSkill.skillModList:HasMod("BASE", activeSkill.skillCfg, modName) or activeSkill.skillModList:HasMod("FLAG", activeSkill.skillCfg, "InflictExposure"))
		or activeSkill.baseSkillModList
		and (activeSkill.baseSkillModList:HasMod("BASE", nil, modName) or activeSkill.baseSkillModList:HasMod("FLAG", nil, "InflictExposure"))
end
local function hasExposureSource(modDB, env, element)
	local modName = element .. "ExposureChance"
	if modDB:Sum("BASE", nil, modName) > 0 or modDB:HasMod("FLAG", nil, "InflictExposure") then
		return true
	end
	for _, activeSkill in ipairs(env.player.activeSkillList) do
		if hasActiveSkillExposureSource(activeSkill, modName) then
			return true
		end
	end
	return false
end
-- Generic radius/area calculator for a given key prefix (e.g. "Presence", "Surrounded")
---@param actor Actor
---@param key string  -- e.g. "Presence" or "Surrounded"
local function calcBuffRadius(actor, key)
	local radiusKey, areaKey , modKey = key .. "Radius", key .. "Area", key .. "Mod"
	-- Calculate modifications to radius first
	local baseRadius = actor.modDB:Sum("BASE", nil, radiusKey)
	local incRadius  = actor.modDB:Sum("INC",  nil, radiusKey)
	local moreRadius = actor.modDB:More(nil, radiusKey)
	local scaledRadius = actor.modDB:Override(nil, radiusKey) or (baseRadius * (1 + incRadius / 100) * moreRadius)
	-- Calculate modifications to area second
	local baseArea = math.pi * (scaledRadius * scaledRadius)
	local incArea  = actor.modDB:Sum("INC",  nil, areaKey)
	local moreArea = actor.modDB:More(nil, areaKey)
	local scaledArea = actor.modDB:Override(nil, areaKey) or (baseArea * (1 + incArea / 100) * moreArea)
	-- Convert back to final radius
	local finalRadius = math.floor(math.sqrt(scaledArea / math.pi))
	actor.output[radiusKey] = finalRadius
	actor.output[radiusKey .. "Metres"] = finalRadius / 10
	if scaledRadius / baseRadius ~= 1 then
		actor.output[modKey] = scaledRadius / baseRadius
	end
	if actor.breakdown then
		actor.breakdown[radiusKey] = actor.breakdown.area(scaledRadius, (1 + incArea / 100) * moreArea, finalRadius)
		if baseRadius ~= scaledRadius then
			actor.breakdown[modKey] = {}
			t_insert(actor.breakdown[modKey], s_format("%.1fm ^8(base radius)", baseRadius / 10))
			t_insert(actor.breakdown[modKey], s_format(" x %.2f  ^8(inc)", 1 + incRadius / 100))
			t_insert(actor.breakdown[modKey], s_format(" x %.2f  ^8(more)", moreRadius))
			t_insert(actor.breakdown[modKey], s_format(" = %.1fm", scaledRadius / 10))
		end
	end
end
local function calculateAttributes(modDB, output, breakdown, condList)
	for _ = 1, 2 do -- Calculate twice because of circular dependency (X attribute higher than Y attribute)
		for _, stat in ipairs({ "Str", "Dex", "Int" }) do
			output[stat] = m_max(round(calcLib.val(modDB, stat)), 0)
			if breakdown then
				breakdown[stat] = breakdown.simple(nil, nil, output[stat], stat)
			end
		end

		local stats = { output.Str, output.Dex, output.Int }
		table.sort(stats)
		output.LowestAttribute = stats[1]
		condList["TwoHighestAttributesEqual"] = stats[2] == stats[3]

		condList["DexHigherThanInt"] = output.Dex > output.Int
		condList["StrHigherThanInt"] = output.Str > output.Int
		condList["IntHigherThanDex"] = output.Int > output.Dex
		condList["StrHigherThanDex"] = output.Str > output.Dex
		condList["IntHigherThanStr"] = output.Int > output.Str
		condList["DexHigherThanStr"] = output.Dex > output.Str

		condList["StrHighestAttribute"] = output.Str >= output.Dex and output.Str >= output.Int
		condList["IntHighestAttribute"] = output.Int >= output.Str and output.Int >= output.Dex
		condList["DexHighestAttribute"] = output.Dex >= output.Str and output.Dex >= output.Int
		condList["IntSingleHighestAttribute"] = output.Int > output.Str and output.Int > output.Dex
		condList["DexSingleHighestAttribute"] = output.Dex > output.Str and output.Dex > output.Int
	end
end
-- Calculate attributes, and set conditions
---@param env Env
---@param actor Actor
local function doActorAttribsConditions(env, actor)
	local modDB = actor.modDB
	---@class Output
	local output = actor.output
	---@class Breakdown
	local breakdown = actor.breakdown
	local condList = modDB.conditions

	-- Set conditions
	if (actor.itemList["Weapon 2"] and actor.itemList["Weapon 2"].type == "Shield") then
		condList["UsingShield"] = true
	elseif (actor.itemList["Weapon 2"] and actor.itemList["Weapon 2"].type == "Focus") then
		condList["UsingFocus"] = true
	elseif not actor.itemList["Weapon 2"] then
		condList["OffHandIsEmpty"] = true
	end
	if actor.weaponData1.type == "None" then
		condList["Unarmed"] = true
		if not actor.itemList["Weapon 2"] and not actor.itemList["Gloves"] then
			condList["Unencumbered"] = true
		end
	else
		local info = env.data.weaponTypeInfo[actor.weaponData1.type]
		condList["Using"..info.flag] = true
		if actor.weaponData1.countsAsAll1H then
			actor.weaponData1["AddedUsingAxe"] = not condList["UsingAxe"]
			condList["UsingAxe"] = true
			actor.weaponData1["AddedUsingSword"] = actor.weaponData1.name:match("Varunastra") or not condList["UsingSword"] --Varunastra is a sword
			condList["UsingSword"] = true
			actor.weaponData1["AddedUsingDagger"] = not condList["UsingDagger"]
			condList["UsingDagger"] = true
			actor.weaponData1["AddedUsingMace"] = not condList["UsingMace"]
			condList["UsingMace"] = true
			actor.weaponData1["AddedUsingClaw"] = not condList["UsingClaw"]
			condList["UsingClaw"] = true
			actor.weaponData1["AddedUsingSpear"] = not condList["UsingSpear"]
			condList["UsingSpear"] = true
			-- GGG stated that a single Varunastra satisfied requirement for wielding two different weapons
			condList["WieldingDifferentWeaponTypes"] = true
		end
		if info.melee then
			condList["UsingMeleeWeapon"] = true
		end
		if info.oneHand then
			condList["UsingOneHandedWeapon"] = true
		else
			condList["UsingTwoHandedWeapon"] = true
		end
		local weapon1Base = actor.itemList["Weapon 1"] and actor.itemList["Weapon 1"].base
		local weapon2Base = actor.itemList["Weapon 2"] and actor.itemList["Weapon 2"].base
		if (weapon1Base and weapon1Base.weapon) or (weapon2Base and weapon2Base.weapon) then -- technically checking weapon2 is unnecessary as there is currently no way to only attack with off-hand, but maybe it will come
			condList["UsingMartialWeapon"] = true
		end
		addWeaponBaseStats(actor)
	end
	local armourSlots = { "Helmet", "Body Armour", "Gloves", "Boots" }
	for _, slotName in ipairs(armourSlots) do
		if actor.itemList[slotName] then
			condList["Using"..slotName] = true
		end
	end
	if actor.weaponData2.type then
		if actor.weaponData2.type ~= "None" then
			local info = env.data.weaponTypeInfo[actor.weaponData2.type]
			condList["Using"..info.flag] = true
			if actor.weaponData2.countsAsAll1H then
				actor.weaponData2["AddedUsingAxe"] = not condList["UsingAxe"]
				condList["UsingAxe"] = true
				actor.weaponData2["AddedUsingSword"] = actor.weaponData2.name:match("Varunastra") or not condList["UsingSword"] --Varunastra is a sword
				condList["UsingSword"] = true
				actor.weaponData2["AddedUsingDagger"] = not condList["UsingDagger"]
				condList["UsingDagger"] = true
				actor.weaponData2["AddedUsingMace"] = not condList["UsingMace"]
				condList["UsingMace"] = true
				actor.weaponData2["AddedUsingClaw"] = not condList["UsingClaw"]
				condList["UsingClaw"] = true
				actor.weaponData2["AddedUsingSpear"] = not condList["UsingSpear"]
				condList["UsingSpear"] = true
				-- GGG stated that a single Varunastra satisfied requirement for wielding two different weapons
				condList["WieldingDifferentWeaponTypes"] = true
			end
			if info.melee then
				condList["UsingMeleeWeapon"] = true
			end
			if info.oneHand then
				condList["UsingOneHandedWeapon"] = true
			else
				condList["UsingTwoHandedWeapon"] = true
			end
		end
	end
	if actor.weaponData1.type and actor.weaponData2.type then
		condList["DualWielding"] = true
		if (actor.weaponData1.type == "Claw" or actor.weaponData1.countsAsAll1H) and (actor.weaponData2.type == "Claw" or actor.weaponData2.countsAsAll1H) then
			condList["DualWieldingClaws"] = true
		end
		if (actor.weaponData1.type == "Dagger" or actor.weaponData1.countsAsAll1H) and (actor.weaponData2.type == "Dagger" or actor.weaponData2.countsAsAll1H) then
			condList["DualWieldingDaggers"] = true
		end
		if (env.data.weaponTypeInfo[actor.weaponData1.type].label or actor.weaponData1.type) ~= (env.data.weaponTypeInfo[actor.weaponData2.type].label or actor.weaponData2.type) then
			local info1 = env.data.weaponTypeInfo[actor.weaponData1.type]
			local info2 = env.data.weaponTypeInfo[actor.weaponData2.type]
			if info1.oneHand and info2.oneHand then
				condList["WieldingDifferentWeaponTypes"] = true
			end
		end
	end
	if env.mode_combat then
		local skillFlags
		if env.mode == "CALCS" then
			skillFlags = actor.mainSkill.activeEffect.statSetCalcs.skillFlags
		else
			skillFlags = actor.mainSkill.activeEffect.statSet.skillFlags
		end
		if not actor.mainSkill.skillData.triggered and not skillFlags.trap and not skillFlags.mine and not skillFlags.totem then
			if skillFlags.attack then
				condList["AttackedRecently"] = true
			elseif skillFlags.spell then
				condList["CastSpellRecently"] = true
			end
			if actor.mainSkill.skillTypes[SkillType.Movement] then
				condList["UsedMovementSkillRecently"] = true
			end
			if skillFlags.minion and not skillFlags.duration then
				condList["UsedMinionSkillRecently"] = true
			end
			if actor.mainSkill.skillTypes[SkillType.Vaal] then
				condList["UsedVaalSkillRecently"] = true
			end
			if actor.mainSkill.skillTypes[SkillType.Channel] then
				condList["Channelling"] = true
			end
		end

		if actor.mainSkill.skillTypes[SkillType.Bear] then
			condList["Shapeshifted"] = true
			condList["BearForm"] = true
			modDB:NewMod("ArmourAppliesToFireDamageTaken", "BASE", 30, "Bear Form")
			modDB:NewMod("ArmourAppliesToColdDamageTaken", "BASE", 30, "Bear Form")
			modDB:NewMod("ArmourAppliesToLightningDamageTaken", "BASE", 30, "Bear Form")
			modDB:NewMod("Armour", "BASE", 10, "Bear Form", { type = "Multiplier", var = "Level", base = 10 })
		end
		if actor.mainSkill.skillTypes[SkillType.Wolf] then
			condList["Shapeshifted"] = true
			condList["WolfForm"] = true
			modDB:NewMod("MovementSpeed", "INC", 30, "Wolf Form")
		end
		if actor.mainSkill.skillTypes[SkillType.Wyvern] then
			condList["Shapeshifted"] = true
			condList["WyvernForm"] = true
			modDB:NewMod("EnergyShieldRechargeFaster", "INC", 50, "Wyvern Form")
			modDB:NewMod("StunThreshold", "INC", 50, "Wyvern Form")
			modDB:NewMod("AilmentThreshold", "INC", 50, "Wyvern Form")
		end
		if skillFlags.hit and not skillFlags.trap and not skillFlags.mine and not skillFlags.totem then
			condList["HitRecently"] = true
			if skillFlags.spell then
				condList["HitSpellRecently"] = true
			end
		end
		if skillFlags.totem then
			condList["HaveTotem"] = true
			condList["SummonedTotemRecently"] = true
			if skillFlags.hit then
				condList["TotemsHitRecently"] = true
				if skillFlags.spell then
					condList["TotemsSpellHitRecently"] = true
				end
			end
		end
		if skillFlags.mine then
			condList["DetonatedMinesRecently"] = true
		end
		if skillFlags.trap then
			condList["TriggeredTrapsRecently"] = true
		end
		if modDB:Sum("BASE", nil, "EnemyScorchChance") > 0 or modDB:Flag(nil, "CritAlwaysAltAilments") and not modDB:Flag(env.player.mainSkill.skillCfg, "NeverCrit") or modDB:Flag(nil, "IgniteCanScorch") then
			condList["CanInflictScorch"] = true
		end
		if modDB:Sum("BASE", nil, "EnemyBrittleChance") > 0 or modDB:Flag(nil, "CritAlwaysAltAilments") and not modDB:Flag(env.player.mainSkill.skillCfg, "NeverCrit") then
			condList["CanInflictBrittle"] = true
		end
		if modDB:Sum("BASE", nil, "EnemySapChance") > 0 or modDB:Flag(nil, "CritAlwaysAltAilments") and not modDB:Flag(env.player.mainSkill.skillCfg, "NeverCrit") then
			condList["CanInflictSap"] = true
		end
		-- Shrine Buffs: Must be done before life pool calculated for massive shrine
		local shrineEffectMod = 1 + modDB:Sum("INC", nil, "BuffEffectOnSelf", "ShrineBuffEffect") / 100
		if modDB:Flag(nil, "LesserMassiveShrine") then
			modDB:NewMod("Life", "INC", m_floor(20 * shrineEffectMod), "Lesser Massive Shrine")
			modDB:NewMod("AreaOfEffect", "INC", m_floor(20 * shrineEffectMod), "Lesser Massive Shrine")
		end
		if modDB:Flag(nil, "LesserBrutalShrine") then
			modDB:NewMod("Damage", "INC", m_floor(20 * shrineEffectMod), "Lesser Brutal Shrine")
			modDB:NewMod("EnemyStunDuration", "INC", m_floor(20 * shrineEffectMod), "Lesser Brutal Shrine")
			modDB:NewMod("EnemyKnockbackChance", "INC", 100, "Lesser Brutal Shrine")
		end
		if modDB:Flag(nil, "DiamondShrine") then
			modDB:NewMod("CritChance", "OVERRIDE", 100, "Diamond Shrine")
		end
		if modDB:Flag(nil, "MassiveShrine") then
			modDB:NewMod("Life", "INC", m_floor(40 * shrineEffectMod), "Massive Shrine")
			modDB:NewMod("AreaOfEffect", "INC", m_floor(40 * shrineEffectMod), "Massive Shrine")
		end
		if modDB:Flag(nil, "Gigantic") then
			modDB:NewMod("Life", "MORE", 20, "Gigantic")
			modDB:NewMod("Damage", "MORE", 20, "Gigantic")
		end
	end
	if env.mode_effective then
		if hasExposureSource(modDB, env, "Fire") then
			condList["CanApplyFireExposure"] = true
			modDB:NewMod("Condition:CanApplyFireExposure", "FLAG", true, "Exposure")
		end
		if hasExposureSource(modDB, env, "Cold") then
			condList["CanApplyColdExposure"] = true
			modDB:NewMod("Condition:CanApplyColdExposure", "FLAG", true, "Exposure")
		end
		if hasExposureSource(modDB, env, "Lightning") then
			condList["CanApplyLightningExposure"] = true
			modDB:NewMod("Condition:CanApplyLightningExposure", "FLAG", true, "Exposure")
		end
	end

	-- Calculate total attributes
	calculateAttributes(modDB, output, breakdown, condList)
	output.TotalAttr = output.Str + output.Dex + output.Int

	-- Special case for Devotion / Tribute
	output.Devotion = modDB:Sum("BASE", nil, "Devotion")
	output.Tribute = modDB:Sum("BASE", nil, "Tribute")

	-- Add attribute bonuses
	if not modDB:Flag(nil, "NoAttributeBonuses") then
		local inherentAttributeMultiplier = 1
		if modDB:Flag(nil, "DoubledInherentAttributeBonuses") then
			inherentAttributeMultiplier = 2
		end
		if not modDB:Flag(nil, "NoStrengthAttributeBonuses") then
			if not modDB:Flag(nil, "NoStrBonusToLife") then
				if modDB:Flag(nil, "HalvesLifeFromStrength") then
					modDB:NewMod("Life", "BASE", output.Str * 1 * inherentAttributeMultiplier, "Strength")
				else
					modDB:NewMod("Life", "BASE", output.Str * 2 * inherentAttributeMultiplier, "Strength")
				end
			end
		end
		if not modDB:Flag(nil, "NoDexterityAttributeBonuses") then
			if not modDB:Flag(nil, "NoDexBonusToAccuracy") then
				modDB:NewMod("Accuracy", "BASE", output.Dex * (modDB:Override(nil, "DexAccBonusOverride") or data.misc.AccuracyPerDexBase) * inherentAttributeMultiplier, "Dexterity")
			end
		end
		if not modDB:Flag(nil, "NoIntelligenceAttributeBonuses") then
			if not modDB:Flag(nil, "NoIntBonusToMana") then
				modDB:NewMod("Mana", "BASE", output.Int * 2 * inherentAttributeMultiplier, "Intelligence")
			end
		end
	end
	-- Calculate Presence / Surrounded value and set condition
	calcBuffRadius(actor, "Presence")
	calcBuffRadius(actor, "Surrounded")
	local enemyDistance = m_max(modDB:Sum("BASE", nil, "Multiplier:enemyDistance"), 0)
	local surroundedMinimum= m_max(modDB:Sum("BASE", nil, "SurroundedMinimum"), 1)
	condList["EnemyInPresence"] = output.PresenceRadius >= enemyDistance
	condList["Surrounded"] = surroundedMinimum == 1 and output.SurroundedRadius >= enemyDistance
end

-- Helper function to determine curse priority when processing curses beyond the curse limit
local function determineCursePriority(curseName, activeSkill)
	local curseName = curseName or ""
	local source = ""
	local slot = ""
	local socket = 1
	if activeSkill and activeSkill.socketGroup then
		source = activeSkill.socketGroup.source or ""
		slot = activeSkill.socketGroup.slot or ""
		for k, v in ipairs(activeSkill.socketGroup.gemList) do
			if v.gemData and v.gemData.name == curseName then
				-- We need to enforce a limit of 8 here to avoid collision with data.cursePriority["CurseFromEquipment"]
				socket = m_min(k, 8)
				break
			end
		end
	end
	local basePriority = data.cursePriority[curseName] or 0
	local socketPriority = socket * data.cursePriority["SocketPriorityBase"]
	local slotPriority = data.cursePriority[slot:gsub(" (Swap)", "")] or 0
	local sourcePriority = 0
	if activeSkill and activeSkill.skillTypes and activeSkill.skillTypes[SkillType.Aura] then
		sourcePriority = data.cursePriority["CurseFromAura"]
	elseif source ~= "" then
		sourcePriority = data.cursePriority["CurseFromEquipment"]
	end
	if source ~= "" and (slotPriority == data.cursePriority["Ring 2"] or slotPriority == data.cursePriority["Ring 3"]) then
		-- Implicit and explicit curses from rings have equal priority; only curses from socketed skill gems care about which ring slot they're equipped in
		slotPriority = data.cursePriority["Ring 1"]
	end
	return basePriority + socketPriority + slotPriority + sourcePriority
end

---@param actor Actor
---@param clearCache? boolean
local function applyEnemyModifiers(actor, clearCache)
	if clearCache or not actor.appliedEnemyModifiers then
		actor.appliedEnemyModifiers = { }
	end
	local cache = actor.appliedEnemyModifiers
	local enemyDB = actor.enemy.modDB
	for _, value in ipairs(actor.modDB:Tabulate(nil, nil, "EnemyModifier")) do
		local mod = value.value and value.value.mod
		if mod and not cache[mod] then
			local source = mod.source or value.mod.source
			enemyDB:AddMod(modLib.setSource(mod, source))
			cache[mod] = true
		end
	end
end

-- Process enemy modifiers and other buffs
---@param env Env
---@param actor Actor
local function doActorMisc(env, actor)
	local modDB = actor.modDB
	local enemyDB = actor.enemy.modDB
	---@class Output
	local output = actor.output
	local condList = modDB.conditions

	-- Add misc buffs/debuffs
	if env.mode_combat then
		if env.player.mainSkill.baseSkillModList:Flag(nil, "Cruelty") then
			modDB.multipliers["Cruelty"] = modDB:Override(nil, "Cruelty") or 40
		end
		-- Minimum Rage
		if modDB:Sum("BASE", nil, "MinimumRage") > (modDB.multipliers["Rage"] or 0) then
			modDB.multipliers["Rage"] = modDB:Sum("BASE", nil, "MinimumRage")
		end
		local alliedFortify = modDB:Flag(nil, "YourFortifyEqualToParent") and actor.parent.output.FortificationStacks or env.partyMembers and env.partyMembers.modDB:Flag(nil, "PartyMemberFortifyEqualToYours") and env.partyMembers.output.FortificationStacks or 0
		-- Minimum Fortification from King Maker or Perfect Naval Officer spectres or Ally override
		if modDB:Sum("BASE", nil, "MinimumFortification") > 0 or alliedFortify > 0 then
			condList["Fortified"] = true
		end
		-- Fortify
		if modDB:Flag(nil, "Fortified") or modDB:Sum("BASE", nil, "Multiplier:Fortification") > 0 then
			local maxStacks = modDB:Override(nil, "MaximumFortification") or modDB:Sum("BASE", skillCfg, "MaximumFortification")
			local minStacks = m_min(modDB:Sum("BASE", nil, "MinimumFortification"), maxStacks)
			local stacks = modDB:Override(nil, "FortificationStacks") or (alliedFortify > 0 and alliedFortify) or (minStacks > 0 and minStacks) or maxStacks
			output.FortificationStacks = stacks
			if not modDB:Flag(nil,"Condition:NoFortificationMitigation") then
				local effectScale = 1 + modDB:Sum("INC", nil, "BuffEffectOnSelf") / 100
				local effect = m_floor(effectScale * stacks)
				modDB:NewMod("DamageTakenWhenHit", "MORE", -effect, "Fortification")
			end
			if stacks >= maxStacks then
				modDB:NewMod("Condition:HaveMaximumFortification", "FLAG", true, "")
			end
			modDB.multipliers["BuffOnSelf"] = (modDB.multipliers["BuffOnSelf"] or 0) + 1
		end
		if modDB:Flag(nil, "Onslaught") then
			local effect
			--Loop detects if a Silver flask is used to grant Onslaught. If statement adds flask effect to calculation if one is being used
			local onslaughtFromFlask
			--This value is set to negative and not 0 or else reduced effect would not properly apply
			local flaskEffectInc = -100
			for item in pairs(env.flasks) do
				if item.baseName:match("Silver Flask") then
					onslaughtFromFlask = true

					local curFlaskEffectInc = item.flaskData.effectInc + modDB:Sum("INC", { actor = "player" }, "FlaskEffect")
					if item.rarity == "MAGIC" then
						curFlaskEffectInc = curFlaskEffectInc + modDB:Sum("INC", { actor = "player" }, "MagicUtilityFlaskEffect")
					end

					if flaskEffectInc < curFlaskEffectInc / 100 then
						flaskEffectInc = curFlaskEffectInc / 100
					end
				end
			end
			local onslaughtEffectInc = modDB:Sum("INC", nil, "OnslaughtEffect", "BuffEffectOnSelf") / 100
			if onslaughtFromFlask then
				effect = m_floor(10 * (1 + flaskEffectInc + onslaughtEffectInc))
			else
				effect = m_floor(10 * (1 + onslaughtEffectInc))
			end
			modDB:NewMod("Speed", "INC", 2 * effect, "Onslaught", ModFlag.Attack)
			modDB:NewMod("Speed", "INC", 2 * effect, "Onslaught", ModFlag.Cast)
			modDB:NewMod("WarcrySpeed", "INC", 2 * effect, "Onslaught")
			-- TODO: Skill speed effect is vague and says "and similar stats", may apply to more than this
			modDB:NewMod("MovementSpeed", "INC", effect, "Onslaught")
		end
		if modDB:Flag(nil, "Fanaticism") and actor.mainSkill and actor.mainSkill.activeEffect.srcInstance.selfCast then
			local effect = m_floor(75 * (1 + modDB:Sum("INC", nil, "BuffEffectOnSelf") / 100))
			modDB:NewMod("Speed", "MORE", effect, "Fanaticism", ModFlag.Cast)
			modDB:NewMod("Cost", "INC", -effect, "Fanaticism", ModFlag.Cast)
			modDB:NewMod("AreaOfEffect", "INC", effect, "Fanaticism", ModFlag.Cast)
		end
		if modDB:Flag(nil, "UnholyMight") then
			local effect = 1 + (modDB:Sum("INC", nil, "BuffEffectOnSelf") / 100)
			modDB:NewMod("Multiplier:UnholyMightMagnitude", "BASE", 100, "Unholy Might") -- Unholy Might Magnitude has to be implemented via Multiplier, because some stat data (Mana) is not yet available here for "perStat" mods
			modDB:NewMod("DamageGainAsChaos", "BASE", 0.3 * effect, "Unholy Might", { type = "Multiplier", var = "UnholyMightMagnitude" })
		end
		if modDB:Flag(nil, "ChaoticMight") then
			local effect = m_floor(30 * (1 + modDB:Sum("INC", nil, "BuffEffectOnSelf") / 100))
			modDB:NewMod("PhysicalDamageGainAsChaos", "BASE", effect, "Chaotic Might")
		end
		if modDB:Flag(nil, "Adrenaline") then
			local effectMod = 1 + modDB:Sum("INC", nil, "BuffEffectOnSelf") / 100
			modDB:NewMod("Damage", "INC", m_floor(100 * effectMod), "Adrenaline")
			modDB:NewMod("Speed", "INC", m_floor(25 * effectMod), "Adrenaline", ModFlag.Attack)
			modDB:NewMod("Speed", "INC", m_floor(25 * effectMod), "Adrenaline", ModFlag.Cast)
			modDB:NewMod("MovementSpeed", "INC", m_floor(25 * effectMod), "Adrenaline")
			modDB:NewMod("PhysicalDamageReduction", "BASE", m_floor(10 * effectMod), "Adrenaline")
		end
		if modDB:Flag(nil, "Convergence") then
			local effect = m_floor(30 * (1 + modDB:Sum("INC", nil, "BuffEffectOnSelf") / 100))
			modDB:NewMod("ElementalDamage", "MORE", effect, "Convergence")
		end
		if modDB:Flag(nil, "HerEmbrace") then
			condList["HerEmbrace"] = true
			modDB:NewMod("AvoidStun", "BASE", 100, "Her Embrace")
			modDB:NewMod("PhysicalDamageGainAsFire", "BASE", 123, "Her Embrace", ModFlag.Sword)
			modDB:NewMod("AvoidFreeze", "BASE", 100, "Her Embrace")
			modDB:NewMod("AvoidChill", "BASE", 100, "Her Embrace")
			modDB:NewMod("AvoidIgnite", "BASE", 100, "Her Embrace")
			modDB:NewMod("Speed", "INC", 20, "Her Embrace", ModFlag.Attack)
			modDB:NewMod("Speed", "INC", 20, "Her Embrace", ModFlag.Cast)
			modDB:NewMod("MovementSpeed", "INC", 20, "Her Embrace")
		end
		if modDB:Flag(nil, "Condition:PhantasmalMight") then
			modDB.multipliers["BuffOnSelf"] = (modDB.multipliers["BuffOnSelf"] or 0) + (output.ActivePhantasmLimit or 1) - 1 -- slight hack to not double count the initial buff
		end
		if modDB:Flag(nil, "Elusive") then
			local maxSkillInc = modDB:Max({ source = "Skill" }, "ElusiveEffect") or 0
			local inc = modDB:Sum("INC", nil, "ElusiveEffect", "BuffEffectOnSelf")
			if actor.mainSkill.skillModList:Flag(nil, "SupportedByNightblade") then
				inc = inc + modDB:Sum("INC", nil, "NightbladeSupportedElusiveEffect")
			end
			inc = inc + maxSkillInc
			local elusiveEffectMod = (1 + inc / 100) * modDB:More(nil, "ElusiveEffect", "BuffEffectOnSelf") * 100
			output.ElusiveEffectMod = (elusiveEffectMod + (modDB:Override(nil, "ElusiveEffectMinThreshold") or 0)) / 2
			-- if we want the max skill to not be noted as its own breakdown table entry, comment out below
			modDB:NewMod("ElusiveEffect", "INC", maxSkillInc, "Max Skill Effect")
			-- Override elusive effect if set.
			if modDB:Override(nil, "ElusiveEffect") then
				output.ElusiveEffectMod = m_min(modDB:Override(nil, "ElusiveEffect"), elusiveEffectMod)
			end
			local effect = output.ElusiveEffectMod / 100
			condList["Elusive"] = true
			modDB:NewMod("AvoidAllDamageFromHitsChance", "BASE", m_floor(15 * effect), "Elusive")
			modDB:NewMod("MovementSpeed", "INC", m_floor(30 * effect), "Elusive")
		end
		if modDB:Max(nil, "WitherEffectStack") then
			modDB:NewMod("Condition:CanWither", "FLAG", true, "Config")
			local effect = modDB:Max(nil, "WitherEffectStack")
			enemyDB:NewMod("ChaosDamageTaken", "INC", effect, "Withered", { type = "Multiplier", var = "WitheredStack", limit = 10 } )
		end
		if modDB:Flag(nil, "Condition:CanInflictIncision") then
			local effect = 10 * (1 + modDB:Sum("INC", nil, "IncisionEffect") / 100)
			enemyDB:NewMod("SelfBleedChance", "BASE", effect, "Incision", { type = "Multiplier", var = "IncisionStack", limit = 10 } )
		end
		if modDB:Flag(nil, "Condition:CanBeWithered") then
			local effect = 5 * (100 + modDB:Sum("INC", nil, "WitherEffectOnSelf")) / 100 * modDB:More(nil, "WitherEffectOnSelf")
			modDB:NewMod("ChaosDamageTaken", "INC", effect, "Withered", { type = "Multiplier", var = "WitheredStack", limit = 10 } )
		end
		if enemyDB:Flag(nil, "Condition:ArmourFullyBroken") then
			local effect = 20 * (1 + modDB:Sum("INC", nil, "FullyBrokenArmourEffect") / 100)
			if modDB:Flag(nil, "FullyBrokenArmourIncreasesAllDamageFromHits") then
				enemyDB:NewMod("DamageTaken", "INC", effect, "Fully Broken Armour", ModFlag.Hit)
			else
				enemyDB:NewMod("PhysicalDamageTaken", "INC", effect, "Fully Broken Armour", ModFlag.Hit)
				if modDB:Flag(nil, "ArmourBreakColdDamageTaken") then
					enemyDB:NewMod("ColdDamageTaken", "INC", effect, "Fully Broken Armour", ModFlag.Hit)
				end
				if modDB:Flag(nil, "ArmourBreakFireDamageTaken") then
					enemyDB:NewMod("FireDamageTaken", "INC", effect, "Fully Broken Armour", ModFlag.Hit)
				end
				if modDB:Flag(nil, "ArmourBreakLightningDamageTaken") then
					enemyDB:NewMod("LightningDamageTaken", "INC", effect, "Fully Broken Armour", ModFlag.Hit)
				end
			end
		end
		if modDB:Flag(nil, "Blind") and not modDB:Flag(nil, "CannotBeBlinded") then
			if not modDB:Flag(nil, "IgnoreBlindHitChance") then
				local effect = 1 + modDB:Sum("INC", nil, "BlindEffect", "BuffEffectOnSelf") / 100
				-- Override Blind effect if set.
				if modDB:Override(nil, "BlindEffect") then
					effect = m_min(modDB:Override(nil, "BlindEffect") / 100, effect)
				end
				local baseBlind = modDB:Flag(nil, "BlindEffectReversed") and 20 or -20
				modDB:NewMod("Accuracy", "MORE", m_floor(baseBlind * effect), "Blind")
				modDB:NewMod("Evasion", "MORE", m_floor(baseBlind * effect), "Blind")
			end
		end
		if modDB:Flag(nil, "Chill") then
			local ailmentData = data.nonDamagingAilment
			local chillValue = modDB:Override(nil, "ChillVal") or ailmentData.Chill.default

			local chillSelf = (modDB:Flag(nil, "Condition:ChilledSelf") and modDB:Sum("INC", nil, "EnemyChillMagnitude") / 100) or 0
			local totalChillSelfEffect = calcLib.mod(modDB, nil, "SelfChillEffect") + chillSelf

			local effect = m_min(m_max(m_floor(chillValue *  totalChillSelfEffect), 0), modDB:Override(nil, "ChillMax") or ailmentData.Chill.max)

			modDB:NewMod("ActionSpeed", "INC", effect * (modDB:Flag(nil, "SelfChillEffectIsReversed") and 1 or -1), "Chill")
		end
		if modDB:Flag(nil, "Freeze") then
			local effect = m_max(m_floor(70 * calcLib.mod(modDB, nil, "SelfChillEffect")), 0)
			modDB:NewMod("ActionSpeed", "INC", -effect, "Freeze")
		end
		if modDB:Flag(nil, "Unravelling") then
			modDB:NewMod("ChaosCanFreeze", "FLAG", true, { type = "Condition", var = "ColdUnravel"})
			modDB:NewMod("ChaosCanIgnite", "FLAG", true, { type = "Condition", var = "FireUnravel"})
			modDB:NewMod("ChaosCanShock", "FLAG", true, { type = "Condition", var = "LightningUnravel"})
		end
		if modDB:Flag(nil, "CanLeechLifeOnFullLife") and not modDB:Flag(nil, "GhostReaver") then
			condList["Leeching"] = true
			condList["LeechingLife"] = true
		end
		if modDB:Flag(nil, "CanLeechEnergyShieldOnFullEnergyShield") then
			condList["Leeching"] = true
			condList["LeechingEnergyShield"] = true
		end
		if modDB:Flag(nil, "Condition:CanGainRage") or modDB:Sum("BASE", nil, "RageRegen") > 0 then
			local maxStacks = modDB:Sum("BASE", skillCfg, "MaximumRage") * calcLib.mod(modDB, nil, "MaximumRage")
			local minStacks = m_min(modDB:Sum("BASE", nil, "MinimumRage"), maxStacks)
			local rageConfig = modDB:Sum("BASE", nil, "Multiplier:RageStack")
			local stacks = m_max(m_min(rageConfig, maxStacks), (minStacks > 0 and minStacks) or 0)
			output.RageEffect = modDB:Override(nil, "RageEffect") or m_floor(stacks * calcLib.mod(modDB, nil, "RageEffect"))
			modDB:NewMod("Multiplier:RageEffect", "BASE", output.RageEffect, "Base")
			output.Rage = stacks
			output.MaximumRage = maxStacks
			modDB:NewMod("Multiplier:Rage", "BASE", output.Rage, "Base")
			if modDB:Flag(nil, "Condition:RageSpellDamage") then
				modDB:NewMod("Damage", "MORE", output.RageEffect, "Rage", ModFlag.Spell)
			else
				modDB:NewMod("Damage", "MORE", output.RageEffect, "Rage", ModFlag.Attack)
			end
			if stacks == maxStacks then
				modDB:NewMod("Condition:HaveMaximumRage", "FLAG", true, "")
			end
			output.InherentRageLossDelay = 2 + modDB:Sum("BASE", nil, "InherentRageLossDelay")
			output.InherentRageLoss = (not modDB:Flag(nil, "InherentRageLossIsPrevented")) and 10 * (1 + modDB:Sum("INC", nil, "InherentRageLoss") / 100) or 0
		end
		if (env.configInput.multiplierManaBurnStacks or 0) > 0 then
			local maxManaBurn = modDB:Sum("BASE", nil, "MaxManaBurnStacks")
			if maxManaBurn == 0 then
				maxManaBurn = 9999
			end
			local manaBurnStacks = m_min((env.configInput.multiplierManaBurnStacks or 0), maxManaBurn)
			modDB:NewMod("Multiplier:ManaBurnStacks", "BASE", manaBurnStacks, "Config")
			manaBurnStacks = manaBurnStacks + modDB:Sum("BASE", { actor = "player" }, "EffectiveManaBurnStacks")
			if modDB:Flag(nil, "Condition:WeepingWoundsInsteadOfManaBurn") then
				modDB:NewMod("Multiplier:WeepingWoundsStacks", "BASE", manaBurnStacks, "Config")
			else
				modDB:NewMod("Multiplier:EffectiveManaBurnStacks", "BASE", manaBurnStacks, "Config")
			end
		end
		if modDB:Sum("BASE", nil, "CoveredInAshEffect") > 0 then
			local effect = modDB:Sum("BASE", nil, "CoveredInAshEffect")
			enemyDB:NewMod("FireDamageTaken", "INC", m_min(effect, 20), "Covered in Ash")
		end
		if modDB:Sum("BASE", nil, "CoveredInFrostEffect") > 0 then
			local effect = modDB:Sum("BASE", nil, "CoveredInFrostEffect")
			enemyDB:NewMod("ColdDamageTaken", "INC", m_min(effect, 20), "Covered in Frost")
		end
		if modDB:Flag(nil, "HasMalediction") then
			modDB:NewMod("DamageTaken", "INC", 10, "Malediction")
			modDB:NewMod("Damage", "INC", -10, "Malediction")
		end
		if modDB:Flag(nil, "HasMaddeningPresence") then
			modDB:NewMod("ActionSpeed", "INC", -10, "Maddening Presence")
			modDB:NewMod("Damage", "INC", -10, "Maddening Presence")
		end
		if modDB:Flag(nil, "HasShapersPresence") then
			modDB:NewMod("BuffExpireFaster", "MORE", -20, "Shapers Presence")
		end
		if modDB:Flag(nil, "Condition:CanHaveSoulEater") then
			local max = modDB:Override(nil, "SoulEaterMax") or modDB:Sum("BASE", nil, "SoulEaterMax")
			modDB:NewMod("Multiplier:SoulEater", "BASE", 1, "Base", { type = "Multiplier", var = "SoulEaterStack", limit = max })
		end
	end

	-- Process enemy modifiers
	applyEnemyModifiers(actor)

	-- Check enemy "Slowed" conditions
	-- NOTE: check is done based on negative speed modifiers as the list of possible slowing effects is very large
	if actor ~= env.player and actor ~= env.minion and (not modDB:Flag(nil, "UnaffectedBySlows")) then
		local slowEffect = modDB:SumNegativeValues("INC", nil, "ActionSpeed") or 0
		slowEffect = slowEffect + modDB:SumNegativeValues("INC", nil, "MovementSpeed") or 0
		slowEffect = slowEffect + modDB:SumNegativeValues("INC", nil, "TemporalChainsActionSpeed") or 0
		if slowEffect ~= 0 then
			modDB:NewMod("Condition:Slowed", "FLAG", true)
		end
	end
end

-- Process charges
---@param env Env
---@param actor Actor
local function doActorCharges(env, actor)
	local modDB = actor.modDB
	---@class Output
	local output = actor.output

	-- Calculate current and maximum charges
	output.PowerChargesMin = m_max(modDB:Sum("BASE", nil, "PowerChargesMin"), 0)
	output.PowerChargesMax = modDB:Override(nil, "PowerChargesMax") or m_max(modDB:Sum("BASE", nil, "PowerChargesMax"), 0)
    output.PowerChargesDuration = m_floor(modDB:Sum("BASE", nil, "ChargeDuration") * calcLib.mod(modDB, nil, "PowerChargesDuration", "ChargeDuration"))
	if modDB:Flag(nil, "MaximumFrenzyChargesIsMaximumPowerCharges") then
		local source = modDB.mods["MaximumFrenzyChargesIsMaximumPowerCharges"][1].source
		if not modDB:HasMod("OVERRIDE", {source = source:match("[^:]+")}, "FrenzyChargesMax") then
			modDB:NewMod("FrenzyChargesMax", "OVERRIDE", output.PowerChargesMax, source)
		end
	end
	output.FrenzyChargesMin = m_max(modDB:Sum("BASE", nil, "FrenzyChargesMin"), 0)
	output.FrenzyChargesMax = modDB:Override(nil, "FrenzyChargesMax") or  m_max(modDB:Flag(nil, "MaximumFrenzyChargesIsMaximumPowerCharges") and output.PowerChargesMax or modDB:Sum("BASE", nil, "FrenzyChargesMax"), 0)
	output.FrenzyChargesDuration = m_floor(modDB:Sum("BASE", nil, "ChargeDuration") * calcLib.mod(modDB, nil, "FrenzyChargesDuration", "ChargeDuration"))
	if modDB:Flag(nil, "MaximumEnduranceChargesIsMaximumFrenzyCharges") then
		local source = modDB.mods["MaximumEnduranceChargesIsMaximumFrenzyCharges"][1].source
		if not modDB:HasMod("OVERRIDE", {source = source:match("[^:]+")}, "EnduranceChargesMax") then
			modDB:NewMod("EnduranceChargesMax", "OVERRIDE", output.FrenzyChargesMax, source)
		end
	end
	output.EnduranceChargesMin = m_max(modDB:Sum("BASE", nil, "EnduranceChargesMin"), 0)
	output.EnduranceChargesMax = m_max(modDB:Override(nil, "EnduranceChargesMax") or env.partyMembers.modDB:Flag(nil, "PartyMemberMaximumEnduranceChargesEqualToYours") and env.partyMembers.output.EnduranceChargesMax or (modDB:Flag(nil, "MaximumEnduranceChargesIsMaximumFrenzyCharges") and output.FrenzyChargesMax or modDB:Sum("BASE", nil, "EnduranceChargesMax")), 0)
	output.EnduranceChargesDuration = m_floor(modDB:Sum("BASE", nil, "ChargeDuration") * calcLib.mod(modDB, nil, "EnduranceChargesDuration", "ChargeDuration"))
	output.SiphoningChargesMax = m_max(modDB:Sum("BASE", nil, "SiphoningChargesMax"), 0)
	output.ChallengerChargesMax = m_max(modDB:Sum("BASE", nil, "ChallengerChargesMax"), 0)
	output.BlitzChargesMax = m_max(modDB:Sum("BASE", nil, "BlitzChargesMax"), 0)
	output.InspirationChargesMax = m_max(modDB:Sum("BASE", nil, "InspirationChargesMax"), 0)
	output.CrabBarriersMax = m_max(modDB:Sum("BASE", nil, "CrabBarriersMax"), 0)
	output.BrutalChargesMin = m_max(modDB:Flag(nil, "MinimumEnduranceChargesEqualsMinimumBrutalCharges") and (modDB:Flag(nil, "MinimumEnduranceChargesIsMaximumEnduranceCharges") and output.EnduranceChargesMax or output.EnduranceChargesMin) or 0 , 0)
	output.BrutalChargesMax = m_max(modDB:Flag(nil, "MaximumEnduranceChargesEqualsMaximumBrutalCharges") and output.EnduranceChargesMax or 0, 0)
	output.AbsorptionChargesMin = m_max(modDB:Flag(nil, "MinimumPowerChargesEqualsMinimumAbsorptionCharges") and (modDB:Flag(nil, "MinimumPowerChargesIsMaximumPowerCharges") and output.PowerChargesMax or output.PowerChargesMin) or 0, 0)
	output.AbsorptionChargesMax = m_max(modDB:Flag(nil, "MaximumPowerChargesEqualsMaximumAbsorptionCharges") and output.PowerChargesMax or 0, 0)
	output.AfflictionChargesMin = m_max(modDB:Flag(nil, "MinimumFrenzyChargesEqualsMinimumAfflictionCharges") and (modDB:Flag(nil, "MinimumFrenzyChargesIsMaximumFrenzyCharges") and output.FrenzyChargesMax or output.FrenzyChargesMin) or 0, 0)
	output.AfflictionChargesMax = m_max(modDB:Flag(nil, "MaximumFrenzyChargesEqualsMaximumAfflictionCharges") and output.FrenzyChargesMax or 0, 0)
	output.BloodChargesMax = m_max(modDB:Sum("BASE", nil, "BloodChargesMax"), 0)
	output.SpiritChargesMax = m_max(modDB:Sum("BASE", nil, "SpiritChargesMax"), 0)

	-- Initialize Charges
	output.PowerCharges = 0
	output.FrenzyCharges = 0
	output.EnduranceCharges = 0
	output.SiphoningCharges = 0
	output.ChallengerCharges = 0
	output.BlitzCharges = 0
	output.InspirationCharges = 0
	output.GhostShrouds = 0
	output.BrutalCharges = 0
	output.AbsorptionCharges = 0
	output.AfflictionCharges = 0
	output.BloodCharges = 0
	output.SpiritCharges = 0

	-- Conditionally over-write Charge values
	if modDB:Flag(nil, "MinimumFrenzyChargesIsMaximumFrenzyCharges") then
		output.FrenzyChargesMin = output.FrenzyChargesMax
	end
	if modDB:Flag(nil, "MinimumEnduranceChargesIsMaximumEnduranceCharges") then
		output.EnduranceChargesMin = output.EnduranceChargesMax
	end
	if modDB:Flag(nil, "MinimumPowerChargesIsMaximumPowerCharges") then
		output.PowerChargesMin = output.PowerChargesMax
	end
	if modDB:Flag(nil, "Condition:UsePowerCharges") then
		output.PowerCharges = modDB:Override(nil, "PowerCharges") or output.PowerChargesMax
	end
	if modDB:Flag(nil, "PowerChargesConvertToAbsorptionCharges") then
		-- we max with possible Power Charge Override from Config since Absorption Charges won't have their own config entry
		-- and are converted from Power Charges
		output.AbsorptionCharges = m_max(output.PowerCharges, m_min(output.AbsorptionChargesMax, output.AbsorptionChargesMin))
		output.PowerCharges = 0
	else
		output.PowerCharges = m_max(output.PowerCharges, m_min(output.PowerChargesMax, output.PowerChargesMin))
	end
	local removablePowerCharges = m_max(output.PowerCharges - output.PowerChargesMin, 0)
	local extraConsumablePowerCharges = removablePowerCharges > 0 and modDB:Sum("BASE", actor.mainSkill.skillCfg, "Multiplier:ExtraConsumablePowerCharges") or 0
	output.RemovablePowerCharges = removablePowerCharges + extraConsumablePowerCharges
	if modDB:Flag(nil, "Condition:UseFrenzyCharges") then
		output.FrenzyCharges = modDB:Override(nil, "FrenzyCharges") or output.FrenzyChargesMax
	end
	if modDB:Flag(nil, "FrenzyChargesConvertToAfflictionCharges") then
		-- we max with possible Power Charge Override from Config since Absorption Charges won't have their own config entry
		-- and are converted from Power Charges
		output.AfflictionCharges = m_max(output.FrenzyCharges, m_min(output.AfflictionChargesMax, output.AfflictionChargesMin))
		output.FrenzyCharges = 0
	else
		output.FrenzyCharges = m_max(output.FrenzyCharges, m_min(output.FrenzyChargesMax, output.FrenzyChargesMin))
	end
	output.RemovableFrenzyCharges = m_max(output.FrenzyCharges - output.FrenzyChargesMin, 0)
	if modDB:Flag(nil, "Condition:UseEnduranceCharges") then
		output.EnduranceCharges = modDB:Override(nil, "EnduranceCharges") or output.EnduranceChargesMax
	end
	if modDB:Flag(nil, "EnduranceChargesConvertToBrutalCharges") then
		-- we max with possible Endurance Charge Override from Config since Brutal Charges won't have their own config entry
		-- and are converted from Endurance Charges
		output.BrutalCharges = m_max(output.EnduranceCharges, m_min(output.BrutalChargesMax, output.BrutalChargesMin))
		output.EnduranceCharges = 0
	else
		output.EnduranceCharges = m_max(output.EnduranceCharges, m_min(output.EnduranceChargesMax, output.EnduranceChargesMin))
	end
	output.RemovableEnduranceCharges = m_max(output.EnduranceCharges - output.EnduranceChargesMin, 0)
	if modDB:Flag(nil, "UseSiphoningCharges") then
		output.SiphoningCharges = modDB:Override(nil, "SiphoningCharges") or output.SiphoningChargesMax
	end
	if modDB:Flag(nil, "UseChallengerCharges") then
		output.ChallengerCharges = modDB:Override(nil, "ChallengerCharges") or output.ChallengerChargesMax
	end
	if modDB:Flag(nil, "UseBlitzCharges") then
		output.BlitzCharges = modDB:Override(nil, "BlitzCharges") or output.BlitzChargesMax
	end
	if actor == env.player then
		output.InspirationCharges = modDB:Override(nil, "InspirationCharges") or output.InspirationChargesMax
	end
	if modDB:Flag(nil, "UseGhostShrouds") then
		output.GhostShrouds = modDB:Override(nil, "GhostShrouds") or 3
	end
	output.BloodCharges = m_min(modDB:Override(nil, "BloodCharges") or output.BloodChargesMax, output.BloodChargesMax)
	output.SpiritCharges = m_min(modDB:Override(nil, "SpiritCharges") or 0, output.SpiritChargesMax)

	output.CrabBarriers = m_min(modDB:Override(nil, "CrabBarriers") or output.CrabBarriersMax, output.CrabBarriersMax)
	if modDB:Flag(nil, "HaveMaximumPowerCharges") then
		output.PowerCharges = output.PowerChargesMax
	end
	if modDB:Flag(nil, "HaveMaximumFrenzyCharges") then
		output.FrenzyCharges = output.FrenzyChargesMax
	end
	if modDB:Flag(nil, "HaveMaximumEnduranceCharges") then
		output.EnduranceCharges = output.EnduranceChargesMax
	end
	output.TotalCharges = output.PowerCharges + output.FrenzyCharges + output.EnduranceCharges
	output.RemovableTotalCharges = output.RemovableEnduranceCharges + output.RemovableFrenzyCharges + output.RemovablePowerCharges
	modDB.multipliers["PowerCharge"] = output.PowerCharges
	modDB.multipliers["PowerChargeMax"] = output.PowerChargesMax
	modDB.multipliers["RemovablePowerCharge"] = output.RemovablePowerCharges
	modDB.multipliers["FrenzyCharge"] = output.FrenzyCharges
	modDB.multipliers["RemovableFrenzyCharge"] = output.RemovableFrenzyCharges
	modDB.multipliers["EnduranceCharge"] = output.EnduranceCharges
	modDB.multipliers["RemovableEnduranceCharge"] = output.RemovableEnduranceCharges
	modDB.multipliers["TotalCharges"] = output.TotalCharges
	modDB.multipliers["RemovableTotalCharges"] = output.RemovableTotalCharges
	modDB.multipliers["SiphoningCharge"] = output.SiphoningCharges
	modDB.multipliers["ChallengerCharge"] = output.ChallengerCharges
	modDB.multipliers["BlitzCharge"] = output.BlitzCharges
	modDB.multipliers["InspirationCharge"] = output.InspirationCharges
	modDB.multipliers["GhostShroud"] = output.GhostShrouds
	modDB.multipliers["CrabBarrier"] = output.CrabBarriers
	modDB.multipliers["BrutalCharge"] = output.BrutalCharges
	modDB.multipliers["AbsorptionCharge"] = output.AbsorptionCharges
	modDB.multipliers["AfflictionCharge"] = output.AfflictionCharges
	modDB.multipliers["BloodCharge"] = output.BloodCharges
	modDB.multipliers["SpiritCharge"] = output.SpiritCharges
end


---@param actor Actor
---@return number
function calcs.actionSpeedMod(actor)
	local modDB = actor.modDB
	local minimumActionSpeed = modDB:Max(nil, "MinimumActionSpeed") or 0
	local maximumActionSpeedReduction = modDB:Max(nil, "MaximumActionSpeedReduction")
	local actionSpeedSum
    local tempChainsSum

    -- if we are unaffected by slows, only count the positive modifiers to action speed
    if modDB:Flag(nil, "UnaffectedBySlows") then
        actionSpeedSum = modDB:SumPositiveValues("INC", nil, "ActionSpeed")
        tempChainsSum = modDB:SumPositiveValues("INC", nil, "TemporalChainsActionSpeed")
    else
        actionSpeedSum = modDB:Sum("INC", nil, "ActionSpeed")
        tempChainsSum =  modDB:Sum("INC", nil, "TemporalChainsActionSpeed")
    end

    local actionSpeedMod = 1 + (m_max(-data.misc.TemporalChainsEffectCap, tempChainsSum) + actionSpeedSum) / 100
	actionSpeedMod = m_max(minimumActionSpeed / 100, actionSpeedMod)
	if maximumActionSpeedReduction then
		actionSpeedMod = m_min((100 - maximumActionSpeedReduction) / 100, actionSpeedMod)
	end
	return actionSpeedMod
end

-- Initialises a minion's modifier database with its base stats (life, defences, resists),
-- monster type mods, tamed beast mods and player-granted mods, for the given owning skill
---@param env Env
---@param activeSkill ActiveSkill
local function initMinionModDB(env, activeSkill)
	local skillFlags
	if env.mode == "CALCS" then
		skillFlags = activeSkill.activeEffect.statSetCalcs.skillFlags
	else
		skillFlags = activeSkill.activeEffect.statSet.skillFlags
	end
	local modDB = env.modDB
	local minion = activeSkill.minion
	minion.modDB.multipliers["Level"] = minion.level
	calcs.initModDB(env, minion.modDB)
	local baseLife = minion.lifeTable[minion.level] * minion.minionData.life
	if minion.hostile then
		baseLife = baseLife * (env.data.mapLevelLifeMult[env.enemyLevel] or 1)
	end
	minion.modDB:NewMod("Life", "BASE", m_floor(baseLife), "Base")
	if minion.minionData.energyShield then
		minion.modDB:NewMod("LifeConvertToEnergyShield", "BASE", minion.minionData.energyShield * 100, "Base")
	end
	--Armour formula is math.floor((10 + 2 * level) * 1.067 ^ level)
	minion.modDB:NewMod("Armour", "BASE", round(env.data.monsterArmourTable[minion.level] * (minion.minionData.armour or 1)), "Base")
	--Evasion formula is math.floor((50 + 16 * level + 16 * level * (MonsterType.Evasion / 100)) * (1.0212 ^ level)
	minion.modDB:NewMod("Evasion", "BASE", round(env.data.monsterEvasionTable[minion.level] * (minion.minionData.evasion or 1)), "Base")
	if modDB:Flag(nil, "MinionAccuracyEqualsAccuracy") then
		minion.modDB:NewMod("Accuracy", "BASE", calcLib.val(modDB, "Accuracy") + calcLib.val(modDB, "Dex") * (modDB:Override(nil, "DexAccBonusOverride") or data.misc.AccuracyPerDexBase), "Player")
	else
		-- Minions no longer need Accuracy as of patch 0.3.0
		minion.modDB:NewMod("CannotBeEvaded", "FLAG", 1, "Minion Attacks always hit")
	end
	minion.modDB:NewMod("CritMultiplier", "BASE", env.data.monsterConstants["base_critical_hit_damage_bonus"] + env.data.playerMinionIntrinsicStats["base_critical_hit_damage_bonus"], "Base")
	if skillFlags.summonBeast then
		minion.modDB:NewMod("FireResist", "BASE", minion.minionData.companionFireResist, "Base")
		minion.modDB:NewMod("ColdResist", "BASE", minion.minionData.companionColdResist, "Base")
		minion.modDB:NewMod("LightningResist", "BASE", minion.minionData.companionLightningResist, "Base")
		minion.modDB:NewMod("ChaosResist", "BASE", minion.minionData.companionChaosResist, "Base")
	else
		minion.modDB:NewMod("FireResist", "BASE", minion.minionData.fireResist, "Base")
		minion.modDB:NewMod("ColdResist", "BASE", minion.minionData.coldResist, "Base")
		minion.modDB:NewMod("LightningResist", "BASE", minion.minionData.lightningResist, "Base")
		minion.modDB:NewMod("ChaosResist", "BASE", minion.minionData.chaosResist, "Base")
	end
	minion.modDB:NewMod("ProjectileCount", "BASE", 1, "Base")
	minion.modDB:NewMod("PhysicalHeavyStunBuildup", "MORE", data.monsterConstants["physical_hit_damage_stun_multiplier_+%_final_from_ot"], "Physical Damage")
	minion.modDB:NewMod("EnemyHeavyStunBuildup", "MORE", data.monsterConstants["melee_hit_damage_stun_multiplier_+%_final_from_ot"], "Melee Damage", ModFlag.Melee)
	minion.modDB:NewMod("Damage", "MORE", minion.hiddenDamageFixup * 100, "Hidden Level Scaling")
	for _, mod in ipairs(minion.minionData.modList) do
		minion.modDB:AddMod(mod)
	end
	for _, mod in ipairs(activeSkill.extraSkillModList) do
		minion.modDB:AddMod(mod)
	end
	if env.talismanModList then
		-- Adding mods provided by "Necromantic Talisman"
		minion.modDB:AddList(env.talismanModList)
	end
	if env.theIronMass and minion.type == "RaisedSkeleton" then
		minion.modDB:AddList(env.theIronMass)
	end
	if activeSkill.skillData.minionUseBowAndQuiver then
		if env.player.weaponData1.type == "Bow" then
			minion.modDB:AddList(env.player.itemList["Weapon 1"].slotModList[1])
		end
		if env.player.itemList["Weapon 2"] and env.player.itemList["Weapon 2"].type == "Quiver" then
			local quiverEffectMod = env.player.modDB:Sum("INC", nil, "EffectOfBonusesFromQuiver") / 100
			if quiverEffectMod > 0 then
				for _, mod in ipairs(env.player.itemList["Weapon 2"].modList) do
					local modCopy = copyTable(mod)
					modCopy.source = "Many Sources:" .. tostring(quiverEffectMod * 100) .. "% Quiver Bonus Effect"
					minion.modDB:ScaleAddMod(modCopy, quiverEffectMod)
				end
			end
		end
	end
	if minion.itemSet or minion.uses then
		for slotName, slot in pairs(env.build.itemsTab.slots) do
			if minion.uses[slotName] then
				local item
				if minion.itemSet then
					if slot.weaponSet == 1 and minion.itemSet.useSecondWeaponSet then
						slotName = slotName .. " Swap"
					end
					item = env.build.itemsTab.items[minion.itemSet[slotName].selItemId]
				else
					item = env.player.itemList[slotName]
				end
				if item then
					minion.itemList[slotName] = item
					minion.modDB:AddList(item.modList or item.slotModList[slot.slotNum])
				end
			end
		end
	end
	if modDB:Flag(nil, "StrengthAddedToMinions") then
		minion.modDB:NewMod("Str", "BASE", round(calcLib.val(modDB, "Str")), "Player")
	end
	if modDB:Flag(nil, "StrengthAddedToCompanions") and activeSkill.skillTypes[SkillType.Companion] then
		minion.modDB:NewMod("Str", "BASE", round(calcLib.val(modDB, "Str")), "Sturdy Ally")
	end
	if modDB:Flag(nil, "HalfStrengthAddedToMinions") then
		minion.modDB:NewMod("Str", "BASE", round(calcLib.val(modDB, "Str") * 0.5), "Player")
	end
	if modDB:Flag(nil, "DexterityAddedToMinions") then
		minion.modDB:NewMod("Dex", "BASE", round(calcLib.val(modDB, "Dex")), "Dead can Dance")
	end
	if modDB:Flag(nil, "DexterityAddedToCompanions") and activeSkill.skillTypes[SkillType.Companion] then
		minion.modDB:NewMod("Dex", "BASE", round(calcLib.val(modDB, "Dex")), "Tandem Assault")
	end
end

---@param modList ModList
---@param skillCfg ModCfg
---@param minion Actor
local function addMinionModifiers(modList, skillCfg, minion)
	for _, value in ipairs(modList:List(skillCfg, "MinionModifier")) do
		if not value.type or minion.type == value.type then
			minion.modDB:AddMod(value.mod)
		end
	end
end

local function setSpectreSource(modList, sourceSkill, activeSkill, castingMinion)
	if activeSkill.skillFlags.spectre then
		local source = "Spectre:"
		if sourceSkill then
			source = source .. sourceSkill .. " - " .. castingMinion.minionData.name
		else
			source = source .. castingMinion.minionData.name
		end
		for i = 1, #modList do
			modList[i].source = source
		end
	end
end
-- Finalises the environment and performs the stat calculations:
-- 1. Merges keystone modifiers
-- 2. Initialises minion skills
-- 3. Initialises the main skill's minion, if present
-- 4. Merges flask effects
-- 5. Sets conditions and calculates attributes (doActorAttribsConditions)
-- 6. Processes buffs and debuffs
-- 7. Processes charges and misc buffs (doActorCharges, doActorMisc)
-- 8. Calculates defence and offence stats (calcs.defence, calcs.offence)
---@param env Env
---@param skipEHP? boolean
function calcs.perform(env, skipEHP)
	---@type ModDB
	local modDB = env.modDB
	---@type ModDB
	local enemyDB = env.enemyDB

	-- Merge keystone modifiers
	env.keystonesAdded = { }
	mergeKeystones(env)

	-- Build minion skills
	for _, activeSkill in ipairs(env.player.activeSkillList) do
		activeSkill.skillModList = new("ModList"):ModList(activeSkill.baseSkillModList)
		if activeSkill.minion then
			activeSkill.minion.modDB = new("ModDB"):ModDB()
			activeSkill.minion.modDB.actor = activeSkill.minion
			calcs.createMinionSkills(env, activeSkill)
			activeSkill.skillPartName = activeSkill.minion.mainSkill.activeEffect.grantedEffect.name
		end
	end

	env.player.output = { }
	env.enemy.output = {}
	---@class Output
	local output = env.player.output

	env.partyMembers = env.build.partyTab.actor
	env.player.partyMembers = env.partyMembers
	local partyTabEnableExportBuffs = env.build.partyTab.enableExportBuffs and env.mode ~= "CALCULATOR"

	env.minion = env.player.mainSkill.minion
	if env.minion then
		-- Initialise minion modifier database
		output.Minion = { }
		env.minion.output = output.Minion
		initMinionModDB(env, env.player.mainSkill)
	end
	if env.talismanModList then
		-- Accounting for "Necromantic Talisman"
		env.player.itemList["Amulet"] = nil
	end
	if modDB:Flag(nil, "AlchemistsGenius") then
		local effectMod = 1 + modDB:Sum("INC", nil, "BuffEffectOnSelf") / 100
		modDB:NewMod("FlaskEffect", "INC", m_floor(10 * effectMod), "Alchemist's Genius")
		modDB:NewMod("FlaskChargesGained", "INC", m_floor(20 * effectMod), "Alchemist's Genius")
	end

	local hasGuaranteedBonechill = false

	-- Banners
	if modDB:Flag(nil,"Condition:BannerPlanted") then
		local max = modDB:Sum("BASE", nil, "MaximumValour")
		local stacks = modDB:Sum("BASE", nil, "Multiplier:ValourStacks")
		modDB:NewMod("Multiplier:BannerValour", "BASE", m_min(stacks, max), "Base")
	end

	if modDB:Flag(nil, "CryWolfMinimumPower") and modDB:Sum("BASE", nil, "WarcryPower") < 10 then
		modDB:NewMod("WarcryPower", "OVERRIDE", 10, "Minimum Warcry Power from CryWolf")
	end
	if modDB:Flag(nil, "WarcryInfinitePower") then
		modDB:NewMod("WarcryPower", "OVERRIDE", 999999, "Warcries have infinite power")
	end
	output.WarcryPower = modDB:Override(nil, "WarcryPower") or modDB:Sum("BASE", nil, "WarcryPower") or 0
	modDB.multipliers["WarcryPower"] = output.WarcryPower

	applyEnemyModifiers(env.player, true)
	if env.minion then
		applyEnemyModifiers(env.minion, true)
	end
	applyEnemyModifiers(env.enemy, true)

	if enemyDB:Flag(env.player.mainSkill.skillCfg, "AbyssalWasted") then
		local conditions = modDB:List(nil, "AbyssalWastingImpliesCondition")
		for _, v in ipairs(conditions) do
			local conditionName = string.format("Condition:%s", v.condition)
			if v.applyToEnemy then
				enemyDB:NewMod(v.condition, "FLAG", true)
				enemyDB:NewMod(conditionName, "FLAG", true)
			else
				modDB:NewMod(v.condition, "FLAG", true)
				modDB:NewMod(conditionName, "FLAG", true)
			end
		end
	end

	local minionTypeCount, ammoTypeCount, grenadeTypeCount = 0, 0, 0
	local minionCount, minionType, ammoType, grenadeType = { }, { }, { }, { }
	local maxPurpleFlameChaosGain = 0
	for _, activeSkill in ipairs(env.player.activeSkillList) do
		local skillFlags
		if env.mode == "CALCS" then
			skillFlags = activeSkill.activeEffect.statSetCalcs.skillFlags
		else
			skillFlags = activeSkill.activeEffect.statSet.skillFlags
		end
		if skillFlags.brand then
			local attachLimit = activeSkill.skillModList:Sum("BASE", activeSkill.skillCfg, "BrandsAttachedLimit")
			local attached = modDB:Sum("BASE", nil, "Multiplier:ConfigBrandsAttachedToEnemy")
			local activeBrands = modDB:Sum("BASE", nil, "Multiplier:ConfigActiveBrands")
			local actual = m_min(attachLimit, attached)
			-- Cap the number of active brands by the limit, which is 3 by default
			modDB.multipliers["ActiveBrand"] = m_min(activeBrands, modDB:Sum("BASE", nil, "ActiveBrandLimit"))
			modDB.multipliers["BrandsAttachedToEnemy"] = m_max(actual, modDB.multipliers["BrandsAttachedToEnemy"] or 0)
			enemyDB.multipliers["BrandsAttached"] = m_max(actual, enemyDB.multipliers["BrandsAttached"] or 0)
		end
		if skillFlags.totem then
			local override = env.player.mainSkill.skillModList:Override(env.player.mainSkill.skillCfg, "ActiveTotemLimit", "ActiveBallistaLimit" )
			local limit = override or env.player.mainSkill.skillModList:Sum("BASE", env.player.mainSkill.skillCfg, "ActiveTotemLimit", "ActiveBallistaLimit" )
			output.ActiveTotemLimit = m_max(limit, output.ActiveTotemLimit or 0)
			output.TotemsSummoned = modDB:Override(nil, "TotemsSummoned") or output.ActiveTotemLimit
			enemyDB.multipliers["TotemsSummoned"] = m_max(output.TotemsSummoned or 0, enemyDB.multipliers["TotemsSummoned"] or 0)
		end
		-- The actual hexes as opposed to hex related skills all have the curse flag. TotemCastsWhenNotDetached is to remove blasphemy
		-- Note that this doesn't work for triggers yet, insufficient support
		if skillFlags.hex and skillFlags.curse and not activeSkill.skillTypes[SkillType.TotemCastsWhenNotDetached] and activeSkill.skillModList:Sum("BASE", nil, "MaxDoom") then
			local hexDoom = modDB:Sum("BASE", nil, "Multiplier:HexDoomStack")
			local maxDoom = activeSkill.skillModList:Sum("BASE", nil, "MaxDoom")
			local doomEffect = activeSkill.skillModList:More(nil, "DoomEffect")
			-- Update the max doom limit
			output.HexDoomLimit = m_max(maxDoom, output.HexDoomLimit or 0)
			-- Update the Hex Doom to apply
			activeSkill.skillModList:NewMod("CurseEffect", "INC", m_min(hexDoom, maxDoom) * doomEffect, "Doom")
			modDB.multipliers["HexDoom"] =  m_min(m_max(hexDoom, modDB.multipliers["HexDoom"] or 0), output.HexDoomLimit)
		end
		if (activeSkill.activeEffect.grantedEffect.name == "Vaal Lightning Trap" or activeSkill.activeEffect.grantedEffect.name == "Shock Ground") then
			-- Shock effect applies to shocked ground
			local effect = activeSkill.skillModList:Sum("BASE", nil, "ShockedGroundEffect") * (1 + activeSkill.skillModList:Sum("INC", nil, "EnemyShockMagnitude") / 100)
			modDB:NewMod("ShockOverride", "BASE", effect, "Shocked Ground", { type = "ActorCondition", actor = "enemy", var = "OnShockedGround" } )
		end
		if activeSkill.skillData.supportBonechill and (activeSkill.skillTypes[SkillType.ChillingArea] or activeSkill.skillTypes[SkillType.NonHitChill] or not activeSkill.skillModList:Flag(nil, "CannotChill")) then
			output.HasBonechill = true
		end
		if activeSkill.activeEffect.grantedEffect.name == "Summon Skitterbots" then
			if not activeSkill.skillModList:Flag(nil, "SkitterbotsCannotShock") then
				local effect = data.nonDamagingAilment.Shock.default * (1 + activeSkill.skillModList:Sum("INC", { source = "Skill" }, "EnemyShockMagnitude") / 100)
				modDB:NewMod("ShockOverride", "BASE", effect, activeSkill.activeEffect.grantedEffect.name)
				enemyDB:NewMod("Condition:Shocked", "FLAG", true, activeSkill.activeEffect.grantedEffect.name)
			end
			if not activeSkill.skillModList:Flag(nil, "SkitterbotsCannotChill") then
				local effect = data.nonDamagingAilment.Chill.default * (1 + activeSkill.skillModList:Sum("INC", { source = "Skill" }, "EnemyChillMagnitude") / 100)
				modDB:NewMod("ChillOverride", "BASE", effect, activeSkill.activeEffect.grantedEffect.name)
				enemyDB:NewMod("Condition:Chilled", "FLAG", true, activeSkill.activeEffect.grantedEffect.name)
				if activeSkill.skillData.supportBonechill then
					hasGuaranteedBonechill = true
				end
			end
		elseif activeSkill.skillTypes[SkillType.ChillingArea] or (activeSkill.skillTypes[SkillType.NonHitChill] and not activeSkill.skillModList:Flag(nil, "CannotChill")) then
			local effect = data.nonDamagingAilment.Chill.default * calcLib.mod(activeSkill.skillModList, activeSkill.skillCfg, "EnemyChillMagnitude")
			modDB:NewMod("ChillOverride", "BASE", effect, activeSkill.activeEffect.grantedEffect.name)
			enemyDB:NewMod("Condition:Chilled", "FLAG", true, activeSkill.activeEffect.grantedEffect.name)
			if activeSkill.skillData.supportBonechill then
				hasGuaranteedBonechill = true
			end
		end
		if activeSkill.minion and activeSkill.minion.minionData and activeSkill.minion.minionData.limit then
			local limit = activeSkill.skillModList:Sum("BASE", nil, activeSkill.minion.minionData.limit)
			output[activeSkill.minion.minionData.limit] = m_max(limit, output[activeSkill.minion.minionData.limit] or 0)
		end
		if activeSkill.minion and activeSkill.minion.minionData and activeSkill.minion.minionData.limit then
			local limit = m_floor(modDB:Override(nil, activeSkill.minion.minionData.limit) or (calcLib.val(activeSkill.skillModList, activeSkill.minion.minionData.limit) * activeSkill.skillModList:More(activeSkill.skillCfg, "ActiveMinionLimit")))
			output[activeSkill.minion.minionData.limit] = m_max(limit, output[activeSkill.minion.minionData.limit] or 0)
			if not minionCount[activeSkill.minion.minionData.limit] then
				env.player.modDB:NewMod("Multiplier:SummonedMinion", "BASE", output[activeSkill.minion.minionData.limit], "Config", { type = "Condition", var = "Combat" })
				env.player.modDB:NewMod("Multiplier:MinionPresenceCount", "BASE", output[activeSkill.minion.minionData.limit], "Config", { type = "Condition", var = "Combat" })
				minionCount[activeSkill.minion.minionData.limit] = true
				t_insert(minionCount, activeSkill.minion.minionData.limit)
			end
			if modDB:Flag(nil, "UmbralWell") then --todo get buffs from file
				local variantId = activeSkill.activeEffect.gemData.variantId
				local buffValue = activeSkill.skillModList:Sum("BASE", env.player.mainSkill.skillCfg, "UmbralWellBuffValue")
				if buffValue > 0 then
					activeSkill.infoMessage = "Disabled by Umbral Well"
					activeSkill.minion.modDB:NewMod("DealNoDamage", "FLAG", 1, "Umbral Well")

					local count = calcs.getActiveSkillCount(activeSkill)
					local minionName = activeSkill.activeEffect.gemData.name
					local sourceName = "Umbral Well"
					if variantId == "SkeletalWarrior" then
						modDB:NewMod("Damage", "INC", buffValue * count, sourceName.." - ".. buffValue .."% per "..minionName, ModFlag.Attack, nil, { type = "GlobalEffect", effectType = "Buff" })
					elseif variantId == "SkeletalSniper" then
						modDB:NewMod("ProjectileSpeed", "INC", buffValue * count, sourceName.." - ".. buffValue .."% per "..minionName, { type = "GlobalEffect", effectType = "Buff" })
					elseif variantId == "SkeletalCleric" then
						modDB:NewMod("EnergyShieldRecharge", "INC", buffValue * count, sourceName.." - ".. buffValue .."% per "..minionName, { type = "GlobalEffect", effectType = "Buff" })
					elseif variantId == "SkeletalArsonist" then
						modDB:NewMod("AreaOfEffect", "INC", buffValue * count, sourceName.." - ".. buffValue .."% per "..minionName, { type = "GlobalEffect", effectType = "Buff" })
					elseif variantId == "SkeletalStormMage" then
						modDB:NewMod("Damage", "INC", buffValue * count, sourceName.." - ".. buffValue .."% per "..minionName, ModFlag.Spell, nil, { type = "GlobalEffect", effectType = "Buff" })
					elseif variantId == "SkeletalFrostMage" then
						modDB:NewMod("EnergyShield", "INC", buffValue * count, sourceName.." - ".. buffValue .."% per "..minionName, { type = "GlobalEffect", effectType = "Buff"})
					elseif variantId == "SkeletalBrute" then
						modDB:NewMod("EnemyHeavyStunBuildup", "INC", buffValue * count, sourceName.." - ".. buffValue .."% per "..minionName, { type = "GlobalEffect", effectType = "Buff" })
					elseif variantId == "SkeletalReaver" then
						modDB:NewMod("Speed", "INC", buffValue * count, sourceName.." - ".. buffValue .."% per "..minionName, { type = "GlobalEffect", effectType = "Buff" })
						modDB:NewMod("WarcrySpeed", "INC", buffValue * count, sourceName.." - ".. buffValue .."% per "..minionName, { type = "GlobalEffect", effectType = "Buff" })
						modDB:NewMod("TotemPlacementSpeed", "INC", buffValue * count, sourceName.." - ".. buffValue .."% per "..minionName, { type = "GlobalEffect", effectType = "Buff" })
						modDB:NewMod("ReloadSpeed", "INC", buffValue * count, sourceName.." - ".. buffValue .."% per "..minionName, { type = "GlobalEffect", effectType = "Buff" })
					end
				end
			end
		end
		if activeSkill.activeEffect.grantedEffect and activeSkill.skillTypes[SkillType.Minion] and activeSkill.skillTypes[SkillType.Persistent] and not minionType[activeSkill.activeEffect.grantedEffect.id] then
			minionTypeCount = minionTypeCount + 1
			minionType[activeSkill.activeEffect.grantedEffect.id] = true
		end
		env.modDB.multipliers["PersistentMinionTypes"] = minionTypeCount
		if activeSkill.skillTypes[SkillType.CrossbowAmmoSkill] and not ammoType[activeSkill.activeEffect.grantedEffect.id] then
			ammoTypeCount = ammoTypeCount + 1
			ammoType[activeSkill.activeEffect.grantedEffect.id] = true
		end
		env.modDB.multipliers["AmmoTypes"] = ammoTypeCount
		if activeSkill.skillTypes[SkillType.Grenade] and not grenadeType[activeSkill.activeEffect.grantedEffect.id] then
			grenadeTypeCount = grenadeTypeCount + 1
			grenadeType[activeSkill.activeEffect.grantedEffect.id] = true
		end
		env.modDB.multipliers["GrenadeTypes"] = grenadeTypeCount
		if activeSkill.activeEffect.grantedEffect and activeSkill.skillTypes[SkillType.CreatesCompanion] then
			modDB:NewMod("Condition:HaveCompanion", "FLAG", true, activeSkill.activeEffect.grantedEffect.name)
		end
		if env.mode_buffs and skillFlags.warcry then
			if activeSkill.activeEffect.grantedEffect.name == "Infernal Cry" and not modDB:Flag(nil, "InfernalActive") then
				env.player.modDB:NewMod("InfernalExtraFireDamage", "BASE", activeSkill.skillModList:Sum("BASE", env.player.mainSkill.skillCfg, "InfernalExtraFireDamageMultiplier"))
				modDB:NewMod("InfernalActive", "FLAG", true) -- Prevents effect from applying multiple times
			end
		end
		if activeSkill.skillData.triggeredOnDeath and not skillFlags.minion then
			activeSkill.skillData.triggered = true
			for _, value in ipairs(activeSkill.skillModList:Tabulate("INC", env.player.mainSkill.skillCfg, "TriggeredDamage")) do
				activeSkill.skillModList:NewMod("Damage", "INC", value.mod.value, value.mod.source, value.mod.flags, value.mod.keywordFlags, unpack(value.mod))
			end
			for _, value in ipairs(activeSkill.skillModList:Tabulate("MORE", env.player.mainSkill.skillCfg, "TriggeredDamage")) do
				activeSkill.skillModList:NewMod("Damage", "MORE", value.mod.value, value.mod.source, value.mod.flags, value.mod.keywordFlags, unpack(value.mod))
			end
			-- Set trigger time to 1 min in ms ( == 6000 ). Technically any large value would do.
			activeSkill.skillData.triggerTime = 60 * 1000
		end
		-- Into the Breach: only purple flames get calculated
		if activeSkill.activeEffect.grantedEffect.name == "Into the Breach" and not modDB:Flag(nil, "BreachFlameOnlyRed") and not modDB:Flag(nil, "BreachFlameOnlyBlue") then
			local baseChaosGain = activeSkill.skillModList:Sum("BASE", nil, "BreachFlameChaosGain")
			if baseChaosGain > 0 then
				local remnantEffectMod = calcLib.mod(activeSkill.skillModList, nil, "RemnantEffect")
				local doubled = modDB:Flag(nil, "BreachFlameEffectDoubled") and 2 or 1
				local chaosGainPerFlame = m_floor(baseChaosGain * remnantEffectMod * doubled)
				maxPurpleFlameChaosGain = m_max(maxPurpleFlameChaosGain, chaosGainPerFlame)
			end
		end
		-- The Saviour
		if activeSkill.activeEffect.grantedEffect.name == "Reflection" or activeSkill.skillData.triggeredBySaviour then
			activeSkill.infoMessage = "Triggered by a Crit from The Saviour"
			activeSkill.infoTrigger = "Saviour"
		end
	end
	local purpleFlameCount = modDB:Sum("BASE", nil, "Multiplier:PurpleFlamesCount")
	if purpleFlameCount > 0 and maxPurpleFlameChaosGain > 0 then
		modDB:NewMod("DamageGainAsChaos", "BASE", maxPurpleFlameChaosGain * purpleFlameCount, "Into the Breach", { type = "GlobalEffect", effectType = "Buff", effectName = "Into the Breach" })
	end

	-- Stat sorting category calcs
	output.EffectiveLootRarityMod = calcLib.mod(modDB, nil, "LootRarity")
	output.Spirit = m_floor(calcLib.val(modDB, nil, "Spirit"))

	if #minionCount == 1 then
		modDB.conditions["OnlyMinion"] = true
	end

	-- Special Rarity / Quantity Calc for Bisco's
	local lootQuantityNormalEnemies = modDB:Sum("INC", nil, "LootQuantityNormalEnemies")
	output.LootQuantityNormalEnemies = (lootQuantityNormalEnemies > 0) and lootQuantityNormalEnemies + modDB:Sum("INC", nil, "LootQuantity") or 0
	local lootRarityMagicEnemies = modDB:Sum("INC", nil, "LootRarityMagicEnemies")
	output.LootRarityMagicEnemies = (lootRarityMagicEnemies > 0) and lootRarityMagicEnemies + modDB:Sum("INC", nil, "LootRarity") or 0

	local breakdown = nil
	if env.buildBreakdown then
		-- Initialise breakdown module
		breakdown = LoadModule(calcs.breakdownModule)(modDB, output, env.player)
		env.player.breakdown = breakdown
		if env.minion then
			env.minion.breakdown = LoadModule(calcs.breakdownModule)(env.minion.modDB, env.minion.output, env.minion)
		end
	end

	if modDB:Flag(nil, "ConvertArmourESToLife") then
		local energyShieldBase
		local tempTable1 = { }
		local slotCfg = wipeTable(tempTable1)
		for _, slot in pairs({"Helmet","Gloves","Boots","Body Armour","Weapon 2","Weapon 3"}) do
			local item = env.player.itemList[slot]
			local armourData = item and item.armourData
			if armourData then
				slotCfg.slotName = slot
				energyShieldBase = item:GetArmourDataValue("EnergyShield", env.player.level)
				if energyShieldBase > 0 then
					modDB:NewMod("Life", "BASE", energyShieldBase, slot.." ES to Life Conversion")
				end
			end
		end
	end

	for slot, item in pairs(env.player.itemList) do
		local slotEffectMod = modDB:Sum("INC", nil, "EffectOfBonusesFrom" .. slot) / 100
		if slotEffectMod > 0 and slot ~= "Amulet" then
			if item.name:match("Kalandra's Touch") then
				if slot == "Ring 2" then
					item = env.player.itemList["Ring 1"]
				elseif slot == "Ring 1" then
					item = env.player.itemList["Ring 2"]
				end
			end
			if item then
				local groupedMods = { }
				local groupedModOrder = { }
				local slotEffectSource = "Many Sources:".. colorCodes.SOURCE .. tostring(slotEffectMod * 100) .. "% " .. slot .. " Bonus Effect"
				for _, mod in ipairs(item.modList or item.slotModList[2]) do
					-- Filter out SocketedIn type mods
					for _, tag in ipairs(mod) do
						if tag.type == "SocketedIn" then
							goto skip_mod
						end
					end

					if type(mod.value) == "number" and (mod.type == "BASE" or mod.type == "INC") then
						local key = modLib.formatModParams(mod)
						local modCopy = groupedMods[key]
						if not modCopy then
							modCopy = copyTable(mod)
							modCopy.source = slotEffectSource
							groupedMods[key] = modCopy
							t_insert(groupedModOrder, modCopy)
						else
							modCopy.value = modCopy.value + mod.value
						end
					else
						local modCopy = copyTable(mod)
						modCopy.source = slotEffectSource
						modDB:ScaleAddMod(modCopy, slotEffectMod)
					end

					::skip_mod::
				end

				for _, mod in ipairs(groupedModOrder) do
					modDB:ScaleAddMod(mod, slotEffectMod)
				end
			end
		end
	end

	if modDB:Flag(nil, "ConvertBodyArmourArmourEvasionToWard") then
		local ward
		local item = env.player.itemList["Body Armour"]
		if item and item.armourData then
			ward = item:GetArmourDataValue("Evasion", env.player.level) + item:GetArmourDataValue("Armour", env.player.level)
			if ward > 0 then
				local wardMult = ((modDB:Sum("BASE", nil,"BodyArmourArmourEvasionToWardPercent") or 0) / 100)
				modDB:NewMod("Ward", "BASE", ward * wardMult , "Body Armour Armour And Evasion Rating to Ward Conversion")
			end
		end
	end

	if modDB:Flag(nil, "MagebloodEquipped") then
		local legacyCountByName = {}
		local foundLegacies = false
		for name, def in pairs(legacies) do
			local stacks = modDB:Sum("BASE", nil, name) or 0
			if stacks > 0 then
				legacyCountByName[name] = stacks
				foundLegacies = true
			end
		end
		if foundLegacies then
			local totalDuplicates = 0
			for _, stacks in pairs(legacyCountByName) do
				if stacks > 1 then
					totalDuplicates = totalDuplicates + (stacks - 1)
				end
			end
			local effectPerDupe = modDB:Sum("INC", nil, "MagesLegacyEffect")
			local globalEffect = 1 + totalDuplicates * (effectPerDupe / 100)
			for name, stacks in pairs(legacyCountByName) do
				local def = legacies[name]
				for _, entry in ipairs(def.effects) do
					local value = m_floor(globalEffect * entry.value)
					modDB:NewMod(entry.stat, entry.type, value, "Mageblood")
				end
			end
		end
	end

	local effectInc = modDB:Sum("INC", {actor = "player"}, "FlaskEffect")
	local effectIncMagic = modDB:Sum("INC", {actor = "player"}, "MagicUtilityFlaskEffect")
	local effectIncNonPlayer = modDB:Sum("INC", nil, "FlaskEffect")
	local effectIncMagicNonPlayer = modDB:Sum("INC", nil, "MagicUtilityFlaskEffect")
	local flasksApplyToMinion = env.minion and modDB:Flag(env.player.mainSkill.skillCfg, "FlasksApplyToMinion")
	local quickSilverAppliesToAllies = env.minion and modDB:Flag(env.player.mainSkill.skillCfg, "QuickSilverAppliesToAllies")
	local nonUniqueFlasksApplyToMinion = env.minion and env.minion.modDB:Flag(nil, "ParentNonUniqueFlasksAppliedToYou")
	local flaskTotalRateInc = modDB:Sum("INC", nil, "FlaskRecoveryRate")
	local flaskDurInc = modDB:Sum("INC", nil, "FlaskDuration")

	-- flask breakdown
	if breakdown then
		local chargesGenerated = modDB:Sum("BASE", nil, "FlaskChargesGenerated")
		local utilityChargesGenerated = modDB:Sum("BASE", nil, "UtilityFlaskChargesGenerated")
		local lifeChargesGenerated = modDB:Sum("BASE", nil, "LifeFlaskChargesGenerated")
		local manaChargesGenerated = modDB:Sum("BASE", nil, "ManaFlaskChargesGenerated")

		output.FlaskEffect = effectInc
		output.FlaskChargeGen = chargesGenerated
		output.LifeFlaskChargeGen = chargesGenerated + lifeChargesGenerated
		output.ManaFlaskChargeGen = chargesGenerated + manaChargesGenerated
		output.UtilityFlaskChargeGen = chargesGenerated + utilityChargesGenerated
	end

	-- Merge flask modifiers
	local function calcFlaskRecovery(type, item)
		local out = {}
		local lType = type:lower()

		if not item.flaskData[lType.."EffectNotRemoved"] and not modDB:Flag(nil, type.."FlaskEffectNotRemoved") then
			return out
		end

		local name = item.name
		local base = item.flaskData[lType.."Base"]
		local dur = item.flaskData.duration
		local instPerc = item.flaskData.instantPerc
		local flaskRecInc = modDB:Sum("INC", nil, "Flask"..type.."Recovery")
		local flaskRecMore = modDB:More(nil, "Flask"..type.."Recovery")
		local flaskRateInc = modDB:Sum("INC", nil, "Flask"..type.."RecoveryRate")
		local flaskTotal = base * (1 - instPerc / 100) * (1 + flaskRecInc / 100) * flaskRecMore * (1 + flaskDurInc / 100)
		local flaskDur = dur * (1 + flaskDurInc / 100) / (1 + flaskTotalRateInc / 100) / (1 + flaskRateInc / 100)

		-- More life recovery while on low life is not affected by flask effect (verified ingame).
		-- Since this will be multiplied by the flask effect value below we have to counteract this by removing the flask effect from the value beforehand.
		-- This is also the reason why this value needs a separate multiplier and cannot just be calculated into FlaskLifeRecovery.
		local lowLifeFlaskRecMore = modDB:More(nil, "FlaskLifeRecoveryLowLife")
		if lowLifeFlaskRecMore > 1 then
			flaskTotal = flaskTotal * (lType == "life" and ((lowLifeFlaskRecMore - 1) / (1 + (effectInc) / 100)) + 1 or 1)
		end

		if not (modDB:Flag(nil, type.."FlaskDoesNotApply")) then
			t_insert(out, modLib.createMod(type.."Recovery", "BASE", flaskTotal / flaskDur, name))
		end

		if (modDB:Flag(nil, type.."FlaskAppliesToEnergyShield")) then
			t_insert(out, modLib.createMod("EnergyShieldRecovery", "BASE", flaskTotal / flaskDur, name))
		end

		if (modDB:Flag(nil, type.."FlaskAppliesToLife")) then
			t_insert(out, modLib.createMod("LifeRecovery", "BASE", flaskTotal / flaskDur, name))
		end
		local wardRecoveryPercent = type == "Life" and modDB:Sum("BASE", nil, "LifeFlaskRecoveryAppliesToWard") or 0
		if wardRecoveryPercent > 0 then
			t_insert(out, modLib.createMod("WardRecovery", "BASE", flaskTotal / flaskDur * wardRecoveryPercent / 100, name))
		end

		return out
	end


	local function calcFlaskMods(item, baseName, buffModList, modList, onlyMinion, flaskBuffs, flaskBuffsPerBase, onlyRecovery, checkNonRecoveryFlasksForMinions, flaskBuffsNonPlayer, flaskBuffsPerBaseNonPlayer)
			local flaskEffectInc = effectInc + item.flaskData.effectInc
			local flaskEffectIncNonPlayer = effectIncNonPlayer + item.flaskData.effectInc
			if item.rarity == "MAGIC" and not (item.base.flask.life or item.base.flask.mana) then
				flaskEffectInc = flaskEffectInc + effectIncMagic
				flaskEffectIncNonPlayer = flaskEffectIncNonPlayer + effectIncMagicNonPlayer
			end
			local effectMod = 1 + (flaskEffectInc) / 100
			local effectModNonPlayer = 1 + (flaskEffectIncNonPlayer) / 100

			-- Avert thine eyes, lest they be forever scarred
			-- I have no idea how to determine which buff is applied by a given flask,
			-- so utility flasks are grouped by base, unique flasks are grouped by name, and magic flasks by their modifiers
			if buffModList[1] then
				if not onlyMinion then
					local srcList = new("ModList"):ModList()
					srcList:ScaleAddList(buffModList, effectMod)
					mergeBuff(srcList, flaskBuffs, baseName)
					mergeBuff(srcList, flaskBuffsPerBase[item.baseName], baseName)
				end
				if (not onlyRecovery or checkNonRecoveryFlasksForMinions) and (flasksApplyToMinion or quickSilverAppliesToAllies or (nonUniqueFlasksApplyToMinion and item.rarity ~= "UNIQUE" and item.rarity ~= "RELIC")) then
				local srcList = new("ModList"):ModList()
					srcList:ScaleAddList(buffModList, effectModNonPlayer)
					mergeBuff(srcList, flaskBuffsNonPlayer, baseName)
					mergeBuff(srcList, flaskBuffsPerBaseNonPlayer[item.baseName], baseName)
				end
			end

			if modList[1] then
				local srcList = new("ModList"):ModList()
				srcList:ScaleAddList(modList, effectMod)
				local key
				if item.rarity == "UNIQUE" or item.rarity == "RELIC" then
					key = item.title
				else
					key = ""
					for _, mod in ipairs(modList) do
						key = key .. modLib.formatModParams(mod) .. "&"
					end
				end
				if not onlyRecovery then
					mergeBuff(srcList, flaskBuffs, key)
					mergeBuff(srcList, flaskBuffsPerBase[item.baseName], key)
				end
				if (not onlyRecovery or checkNonRecoveryFlasksForMinions) and (flasksApplyToMinion or quickSilverAppliesToAllies or (nonUniqueFlasksApplyToMinion and item.rarity ~= "UNIQUE" and item.rarity ~= "RELIC")) then
					srcList = new("ModList"):ModList()
					srcList:ScaleAddList(modList, effectModNonPlayer)
					mergeBuff(srcList, flaskBuffsNonPlayer, key)
					mergeBuff(srcList, flaskBuffsPerBaseNonPlayer[item.baseName], key)
				end
			end
		end
	local function mergeFlasks(flasks, onlyRecovery, checkNonRecoveryFlasksForMinions)
		local flaskBuffs = {}
		local flaskConditions = {}
		local flaskBuffsPerBase = {}
		local flaskBuffsNonPlayer = {}
		local flaskBuffsPerBaseNonPlayer = {}

		for item in pairs(flasks) do
			flaskBuffsPerBase[item.baseName] = flaskBuffsPerBase[item.baseName] or {}
			flaskBuffsPerBaseNonPlayer[item.baseName] = flaskBuffsPerBaseNonPlayer[item.baseName] or {}
			flaskConditions["UsingFlask"] = true
			flaskConditions["Using"..item.baseName:gsub("%s+", "")] = true
			if item.base.flask.life and not modDB:Flag(nil, "CannotRecoverLifeOutsideLeech") then
				flaskConditions["UsingLifeFlask"] = true
			end
			if item.base.flask.mana then
				flaskConditions["UsingManaFlask"] = true
			end

			if onlyRecovery then
				if item.base.flask.life and not modDB:Flag(nil, "CannotRecoverLifeOutsideLeech") then
					calcFlaskMods(item, "LifeFlask", calcFlaskRecovery("Life", item), {}, nil, flaskBuffs, flaskBuffsPerBase, onlyRecovery, checkNonRecoveryFlasksForMinions, flaskBuffsNonPlayer, flaskBuffsPerBaseNonPlayer)
				end
				if item.base.flask.mana then
					calcFlaskMods(item, "ManaFlask", calcFlaskRecovery("Mana", item), {}, nil, flaskBuffs, flaskBuffsPerBase, onlyRecovery, checkNonRecoveryFlasksForMinions, flaskBuffsNonPlayer, flaskBuffsPerBaseNonPlayer)
				end
				if checkNonRecoveryFlasksForMinions then
					calcFlaskMods(item, item.baseName, item.buffModList, item.modList, true, flaskBuffs, flaskBuffsPerBase, onlyRecovery, checkNonRecoveryFlasksForMinions, flaskBuffsNonPlayer, flaskBuffsPerBaseNonPlayer)
				end
			else
				calcFlaskMods(item, item.baseName, item.buffModList, item.modList, nil, flaskBuffs, flaskBuffsPerBase, onlyRecovery, checkNonRecoveryFlasksForMinions, flaskBuffsNonPlayer, flaskBuffsPerBaseNonPlayer)
			end
		end
		if not modDB:Flag(nil, "FlasksDoNotApplyToPlayer") then
			for flaskCond, status in pairs(flaskConditions) do
				modDB.conditions[flaskCond] = status
			end
			for _, buffModList in pairs(flaskBuffs) do
				modDB:AddList(buffModList)
			end
		end
		if env.minion then
			if flasksApplyToMinion or nonUniqueFlasksApplyToMinion then -- nonUniqueAlreadyFiltered
				local minionModDB = env.minion.modDB
				for flaskCond, status in pairs(flaskConditions) do
					minionModDB.conditions[flaskCond] = status
				end
				for _, buffModList in pairs(flaskBuffsNonPlayer) do
					minionModDB:AddList(buffModList)
				end
			else -- Not all flasks apply to minions. Check if some flasks need to be selectively applied
				if quickSilverAppliesToAllies and flaskBuffsPerBaseNonPlayer["Quicksilver Flask"] then
					local minionModDB = env.minion.modDB
					minionModDB.conditions["UsingQuicksilverFlask"] = flaskConditions["UsingQuicksilverFlask"]
					minionModDB.conditions["UsingFlask"] = flaskConditions["UsingFlask"]
					for _, buffModList in pairs(flaskBuffsPerBaseNonPlayer["Quicksilver Flask"]) do
						minionModDB:AddList(buffModList)
					end
				end
			end
		end
	end

	local effectInc = modDB:Sum("INC", {actor = "player"}, "CharmEffect")
	local effectIncMagic = modDB:Sum("INC", {actor = "player"}, "MagicCharmEffect")
	local charmLimit = m_min(modDB:Override(nil, "CharmLimit") or modDB:Sum("BASE", nil, "CharmLimit"), 3)

	-- charm breakdown
	if breakdown then
		output.CharmEffect = effectInc
		output.CharmLimit = charmLimit
	end


	local function calcCharmMods(item, baseName, buffModList, modList, charmBuffs, charmBuffsPerBase)
			local charmEffectInc = effectInc + item.charmData.effectInc
			if item.rarity == "MAGIC" then
				charmEffectInc = charmEffectInc + effectIncMagic
			end
			local effectMod = 1 + (charmEffectInc) / 100

			-- same deal as flasks, go look at the comment there
			if buffModList[1] then
				local srcList = new("ModList"):ModList()
				srcList:ScaleAddList(buffModList, effectMod)
				mergeBuff(srcList, charmBuffs, baseName)
				mergeBuff(srcList, charmBuffsPerBase[item.baseName], baseName)
			end

			if modList[1] then
				local srcList = new("ModList"):ModList()
				srcList:ScaleAddList(modList, effectMod)
				local key
				if item.rarity == "UNIQUE" or item.rarity == "RELIC" then
					key = item.title
				else
					key = ""
					for _, mod in ipairs(modList) do
						key = key .. modLib.formatModParams(mod) .. "&"
					end
				end
				mergeBuff(srcList, charmBuffs, key)
				mergeBuff(srcList, charmBuffsPerBase[item.baseName], key)
			end
		end
	local function mergeCharms(charms)
		local charmBuffs = {}
		local charmConditions = {}
		local charmBuffsPerBase = {}

		for item in pairs(charms) do
			if charmLimit <= 0 then
				break
			end
			charmLimit = charmLimit - 1
			charmBuffsPerBase[item.baseName] = charmBuffsPerBase[item.baseName] or {}
			charmConditions["UsingCharm"] = true
			charmConditions["Using"..item.baseName:gsub("%s+", "")] = true
			calcCharmMods(item, item.baseName, item.buffModList, item.modList, charmBuffs, charmBuffsPerBase)
		end
		output.EmptyCharms = charmLimit
		for charmCond, status in pairs(charmConditions) do
			modDB.conditions[charmCond] = status
		end
		for _, buffModList in pairs(charmBuffs) do
			modDB:AddList(buffModList)
		end
	end

	if env.mode_combat then
		-- This needs to be done in 2 steps to account for effects affecting life recovery from flasks
		-- For example Sorrow of the Divine and buffs (like flask recovery watchers eye)
		mergeFlasks(env.flasks, false, true)
		mergeCharms(env.charms)

		-- Merge keystones again to catch any that were added by flasks
		mergeKeystones(env)
	end

	-- Calculate attributes
	doActorAttribsConditions(env, env.player)
	if env.minion then
		if env.minion.hostile then
			for _, value in ipairs(env.modDB:Tabulate(nil, nil, "EnemyModifier")) do
				local mod = value.value and value.value.mod
				if mod then
					local copy = copyTable(mod, true)
					env.minion.modDB:AddMod(modLib.setSource(copy, mod.source or value.mod.source))
				end
			end
		else
			addMinionModifiers(env.player.mainSkill.skillModList, env.player.mainSkill.skillCfg, env.minion)
			for _, name in ipairs(env.minion.modDB:List(nil, "Keystone")) do
				if env.spec.tree.keystoneMap[name] then
					env.minion.modDB:AddList(env.spec.tree.keystoneMap[name].modList)
				end
			end
		end
		doActorAttribsConditions(env, env.minion)
	end

	-- Process attribute requirements
	local function getSourceNameTooltipFunc(item, reqSource)
		return function(tooltip)
			env.build.itemsTab:AddItemTooltip(tooltip, item, reqSource.sourceSlot)
		end
	end
	do
		local reqMultItem = calcLib.mod(modDB, nil, "GlobalAttributeRequirements", "GlobalItemAttributeRequirements")
		local reqMultGem = calcLib.mod(modDB, nil, "GlobalAttributeRequirements", "GlobalGemAttributeRequirements")
		local reqMultWeapon = calcLib.mod(modDB, nil, "GlobalAttributeRequirements", "GlobalItemAttributeRequirements", "GlobalWeaponAttributeRequirements")
		output.GlobalItemAttributeRequirements = reqMultItem
		output.GlobalGemAttributeRequirements = reqMultGem
		output.GlobalWeaponAttributeRequirements = reqMultWeapon
		local gemAttributeRequirementsSatisfiedByHighestAttribute = modDB:Flag(nil, "GemAttributeRequirementsSatisfiedByHighestAttribute")
		local attrTable = {"Str","Dex","Int"}
		local highestAttributeValue = 0
		if gemAttributeRequirementsSatisfiedByHighestAttribute then
			-- find highest attribute
			for _, attr in ipairs(attrTable) do
				local checkedAttributeValue = output[attr] or 0
				if checkedAttributeValue > highestAttributeValue then
					highestAttributeValue = checkedAttributeValue
				end
			end
		end
		local ignoreAttrReq = modDB:Flag(nil, "IgnoreAttributeRequirements")
		local strengthSatisfiesMeleeFlag = modDB:Flag(nil, "StrengthSatisfiesMeleeWeaponsAndSkills")
		for _, attr in ipairs(attrTable) do
			local breakdownAttr = attr
			if breakdown then
				breakdown["Req"..attr] = {
					source = "",
					rowList = { },
					colList = {
						{ label = attr, key = "req" },
						{ label = "Source", key = "source" },
						{ label = "Source Name", key = "sourceName" },
					}
				}
			end
			local out = {val = 0, source = nil}
			for _, reqSource in ipairs(env.requirementsTable) do
				if reqSource[attr] and reqSource[attr] > 0 then
					local req = 0
					if reqSource.source == "Item" then
						if reqSource.sourceItem.base.weapon then
							req = m_floor(reqSource[attr] * reqMultWeapon)
						else
							req = m_floor(reqSource[attr] * reqMultItem)
						end
						output[attr.."RequirementsOn"..reqSource.sourceSlot] = req;
					elseif reqSource.source == "Gem" then
						req = m_floor(reqSource[attr] * reqMultGem)
					elseif reqSource.source == "Support Gems" then
						req = m_floor(reqSource[attr])
					end
					-- Jarngreipr // if it's a melee weapon or melee skill gem and your Strength is greater than or equal to the Dex/Int requirement
					local strengthSatisfiesMelee = strengthSatisfiesMeleeFlag
						and ((reqSource.source == "Item" and reqSource.sourceItem.base.weapon and env.data.weaponTypeInfo[reqSource.sourceItem.base.type].melee)
						or (reqSource.source == "Gem" and reqSource.sourceGem.gemData.tags.melee))
					local satisfyingAttributeValue = gemAttributeRequirementsSatisfiedByHighestAttribute and reqSource.source == "Gem" and highestAttributeValue or out.val
					if req > (strengthSatisfiesMelee and attr ~= "Str" and m_max(satisfyingAttributeValue, output["Str"]) or satisfyingAttributeValue) then
						out.val = req
						out.source = reqSource
					end
					if breakdown then
						local breakdownAttributeValue = gemAttributeRequirementsSatisfiedByHighestAttribute and reqSource.source == "Gem" and highestAttributeValue or output[breakdownAttr]
						local reqBool = req > (strengthSatisfiesMelee and breakdownAttr ~= "Str" and m_max(breakdownAttributeValue, output["Str"]) or breakdownAttributeValue)
						local row = {
							req = reqBool and colorCodes.NEGATIVE..req or req,
							reqNum = req,
							source = reqSource.source,
						}
						if reqSource.source == "Item" then
							local item = reqSource.sourceItem
							row.sourceName = colorCodes[item.rarity] .. item.name
							row.sourceNameTooltip = getSourceNameTooltipFunc(item, reqSource)
						elseif reqSource.source == "Gem" then
							row.sourceName = s_format("%s%s ^7%d/%d", reqSource.sourceGem.color, reqSource.sourceGem.nameSpec, reqSource.sourceGem.level, reqSource.sourceGem.quality)
						elseif reqSource.source == "Support Gems" then
							local attrName = ({Str="Strength",Dex="Dexterity",Int="Intelligence"})[attr]
							row.sourceName = (reqSource[attr]/5).." "..colorCodes[string.upper(attrName)]..attrName.." Support Gems"
						end
						t_insert(breakdown["Req"..breakdownAttr].rowList, row)
					end
				end
			end
			if ignoreAttrReq then
				out.val = 0
			end
			output["Req"..attr.."String"] = 0
			local checkedAttributeStr = "Req"..breakdownAttr
			local checkedAttributeValue = output[breakdownAttr] or 0
			if out.val > (output[checkedAttributeStr] or 0) then
				output[checkedAttributeStr.."String"] = out.val
				output[checkedAttributeStr] = out.val
				output[checkedAttributeStr.."Item"] = out.source
				if breakdown then
					output[checkedAttributeStr.."String"] = out.val > (gemAttributeRequirementsSatisfiedByHighestAttribute and out.source == "Gem" and highestAttributeValue or checkedAttributeValue) and colorCodes.NEGATIVE..(out.val) or out.val
				end
			end
		end
	end

	-- Calculate number of active heralds and auras affecting self
	if env.mode_buffs then
		local heraldList = { }
		local auraList = { }
		for _, activeSkill in ipairs(env.player.activeSkillList) do
			if activeSkill.skillTypes[SkillType.Herald] and not heraldList[activeSkill.skillCfg.skillName] then
				heraldList[activeSkill.skillCfg.skillName] = true
				modDB.multipliers["Herald"] = (modDB.multipliers["Herald"] or 0) + 1
				modDB.conditions["AffectedByHerald"] = true
			elseif activeSkill.skillTypes[SkillType.Aura] and not activeSkill.skillTypes[SkillType.AuraAffectsEnemies] and not activeSkill.skillData.auraCannotAffectSelf and not auraList[activeSkill.skillCfg.skillName] then
				auraList[activeSkill.skillCfg.skillName] = true
				modDB.multipliers["AuraAffectingSelf"] = (modDB.multipliers["AuraAffectingSelf"] or 0) + 1
			end
		end
	end

	-- Deal with Consecrated Ground
	if modDB:Flag(nil, "Condition:OnConsecratedGround") then
		local effect = 1 + modDB:Sum("INC", nil, "ConsecratedGroundEffect") / 100
		modDB:NewMod("LifeRegenPercent", "BASE", 5 * effect, "Consecrated Ground")
		modDB:NewMod("CurseEffectOnSelf", "INC", -50 * effect, "Consecrated Ground")
	end

	if modDB:Flag(nil, "ManaAppliesToShockEffect") then
		-- Maximum Mana conversion from Lightning Mastery
		local multiplier = (modDB:Max(nil, "ImprovedManaAppliesToShockEffect") or 100) / 100
		for _, value in ipairs(modDB:Tabulate("INC", nil, "Mana")) do
			local mod = value.mod
			local modifiers = calcLib.getConvertedModTags(mod, multiplier)
			modDB:NewMod("EnemyShockMagnitude", "INC", m_floor(mod.value * multiplier), mod.source, mod.flags, mod.keywordFlags, unpack(modifiers))
		end
	end
	if modDB:Flag(nil, "ManaRegenAppliesToRageRegen") then
		-- Furious Wellspring
		for i, value in ipairs(modDB:Tabulate("INC",  nil, "ManaRegen")) do
			local mod = value.mod
			modDB:NewMod("RageRegen", "INC", mod.value, mod.source, mod.flags, mod.keywordFlags, unpack(mod))
		end
	end

	-- Combine buffs/debuffs
	local buffs = { }
	env.buffs = buffs
	local guards = { }
	local minionBuffs = { }
	env.minionBuffs = minionBuffs
	local debuffs = { }
	env.debuffs = debuffs
	local curses = { }
	local minionCurses = {
		limit = 1,
	}
	local linkSkills = { }
	local allyBuffs = env.partyMembers["Aura"]
	local buffExports = { Aura = {}, Curse = {}, Warcry = {}, Link = {}, EnemyMods = {}, EnemyConditions = {}, PlayerMods = {} }
	local hasActiveSpectreSkill = false
	for _, activeSkill in ipairs(env.player.activeSkillList) do
		local skillFlags = activeSkill.activeEffect.statSet and activeSkill.activeEffect.statSet.skillFlags
		if env.mode == "CALCS" then
			skillFlags = activeSkill.activeEffect.statSetCalcs and activeSkill.activeEffect.statSetCalcs.skillFlags
		end
		if not (skillFlags and skillFlags.disable) then
			local skillId = activeSkill.activeEffect.grantedEffect.id
			if skillId and skillId:match("^SummonSpectre") then
				hasActiveSpectreSkill = true
				break
			end
		end
	end
	if hasActiveSpectreSkill then
		for spectreId = 1, #env.spec.build.spectreList do
			local spectreData = data.minions[env.spec.build.spectreList[spectreId]]
			for modId = 1, #spectreData.modList do
				local modData = spectreData.modList[modId]
				if modData.name == "EnemyCurseLimit" or modData.name == "EnemyMarkLimit" then
					minionCurses.limit = modData.value + 1
					break
				elseif modData.name == "AllyModifier" and modData.type == "LIST" then
					buffs["Spectre"] = buffs["Spectre"] or new("ModList"):ModList()
					minionBuffs["Spectre"] = minionBuffs["Spectre"] or new("ModList"):ModList()
					for _, modValue in pairs(modData.value) do
						local copyModValue = copyTable(modValue)
						copyModValue.source = "Spectre:"..spectreData.name
						t_insert(minionBuffs["Spectre"], copyModValue)
						t_insert(buffs["Spectre"], copyModValue)
					end
				elseif modData.name == "MinionModifier" and modData.type == "LIST" then
					minionBuffs["Spectre"] = minionBuffs["Spectre"] or new("ModList"):ModList()
					for _, modValue in pairs(modData.value) do
						local copyModValue = copyTable(modValue)
						copyModValue.source = "Spectre:"..spectreData.name
						t_insert(minionBuffs["Spectre"], copyModValue)
					end
				elseif modData.name == "PlayerModifier" and modData.type == "LIST" then
					buffs["Spectre"] = buffs["Spectre"] or new("ModList"):ModList()
					for _, modValue in pairs(modData.value) do
						local copyModValue = copyTable(modValue)
						copyModValue.source = "Spectre:"..spectreData.name
						t_insert(buffs["Spectre"], copyModValue)
					end
				end
			end
		end
	end

	-- To support maximum sustainable stages for the following skills we need to get the data from already
	-- computed cached versions to satisfy the order of operations.
	-- See: https://github.com/PathOfBuildingCommunity/PathOfBuilding/pull/5164
	for _, activeSkill in ipairs(env.player.activeSkillList) do
		local disabledFlag
		if env.mode == "CALCS" then
			disabledFlag = activeSkill.activeEffect.statSetCalcs.skillFlags.disable
		else
			disabledFlag = activeSkill.activeEffect.statSet.skillFlags.disable
		end
		if not disabledFlag and not (env.limitedSkills and env.limitedSkills[cacheSkillUUID(activeSkill, env)]) then
			if (activeSkill.activeEffect.grantedEffect.name == "Blight" or activeSkill.activeEffect.grantedEffect.name == "Blight of Contagion" or activeSkill.activeEffect.grantedEffect.name == "Blight of Atrophy") and activeSkill.skillPart == 2 then
				local rate, duration = getCachedOutputValue(env, activeSkill, "Speed", "Duration")
				local baseMaxStages = activeSkill.skillModList:Sum("BASE", env.player.mainSkill.skillCfg, "BlightBaseMaxStages")
				local maximum = m_min((m_floor(rate * duration) - 1), baseMaxStages - 1)
				activeSkill.skillModList:NewMod("Multiplier:"..activeSkill.activeEffect.grantedEffect.name:gsub("%s+", "").."MaxStages", "BASE", maximum, "Base")
				activeSkill.skillModList:NewMod("Multiplier:"..activeSkill.activeEffect.grantedEffect.name:gsub("%s+", "").."StageAfterFirst", "BASE", maximum, "Base")
			end
			if activeSkill.activeEffect.grantedEffect.name == "Penance Brand of Dissipation" and activeSkill.skillPart == 2 then
				local activation_frequency, duration = getCachedOutputValue(env, activeSkill, "HitSpeed", "Duration") -- HitSpeed is the brand activation frequency
				local ticks = m_max(m_min((m_floor((activation_frequency or 0) * duration) - 1), 19), 0)
				activeSkill.skillModList:NewMod("Multiplier:PenanceBrandofDissipationMaxStages", "BASE", ticks, "Base")
				activeSkill.skillModList:NewMod("Multiplier:PenanceBrandofDissipationStageAfterFirst", "BASE", ticks, "Base")
			end
			if (activeSkill.activeEffect.grantedEffect.name == "Scorching Ray" or activeSkill.activeEffect.grantedEffect.name == "Scorching Ray of Immolation") and activeSkill.skillPart == 2 then
				local maximum = 7
				activeSkill.skillModList:NewMod("Multiplier:"..activeSkill.activeEffect.grantedEffect.name:gsub("%s+", "").."MaxStages", "BASE", maximum, "Base")
				activeSkill.skillModList:NewMod("Multiplier:"..activeSkill.activeEffect.grantedEffect.name:gsub("%s+", "").."StageAfterFirst", "BASE", maximum, "Base")
			end
			if (activeSkill.activeEffect.grantedEffect.name == "Earthquake of Amplification")  and activeSkill.skillPart == 2 then
				local duration = getCachedOutputValue(env, activeSkill, "Duration")
				local durationMulti = m_floor(duration * 10)
				activeSkill.skillModList:NewMod("Multiplier:100msEarthquakeDuration", "BASE", durationMulti, "Skill:EarthquakeAltX")
			end
		end
	end

	local appliedCombustion = false
	local warcryList = { }
	for _, activeSkill in ipairs(env.player.activeSkillList) do
		local skillFlags
		if env.mode == "CALCS" then
			skillFlags = activeSkill.activeEffect.statSetCalcs.skillFlags
		else
			skillFlags = activeSkill.activeEffect.statSet.skillFlags
		end
		local skillModList = activeSkill.skillModList
		local skillCfg = activeSkill.skillCfg
		for _, buff in ipairs(activeSkill.buffList) do
			if buff.cond and not skillModList:GetCondition(buff.cond, skillCfg) then
				-- Nothing!
			elseif buff.enemyCond and not enemyDB:GetCondition(buff.enemyCond) then
				-- Also nothing :/
			elseif buff.type == "Buff" then
				if env.mode_buffs and (not skillFlags.totem or buff.allowTotemBuff) then
					local skillCfg = buff.activeSkillBuff and skillCfg
					local modStore = buff.activeSkillBuff and skillModList or modDB
				 	if not buff.applyNotPlayer then
						activeSkill.buffSkill = true
						modDB.conditions["AffectedBy"..buff.name:gsub(" ","")] = true
						local srcList = new("ModList"):ModList()
						local inc = modStore:Sum("INC", skillCfg, "BuffEffect", "BuffEffectOnSelf", "BuffEffectOnPlayer") + skillModList:Sum("INC", skillCfg, buff.name:gsub(" ", "").."Effect")
						local more = modStore:More(skillCfg, "BuffEffect", "BuffEffectOnSelf") * calcLib.mod(modStore, skillCfg, "Magnitude")
						srcList:ScaleAddList(buff.modList, (1 + inc / 100) * more)
						mergeBuff(srcList, buffs, buff.name)
						if activeSkill.skillData.thisIsNotABuff then
							buffs[buff.name].notBuff = true
						end
					end
					if env.minion and not env.minion.hostile and (buff.applyMinions or buff.applyAllies or skillModList:Flag(nil, "BuffAppliesToAllies") and not env.minion.modDB:Flag(nil, "HiddenMonster")) then
						activeSkill.minionBuffSkill = true
						env.minion.modDB.conditions["AffectedBy"..buff.name:gsub(" ","")] = true
						local srcList = new("ModList"):ModList()
						local inc = modStore:Sum("INC", skillCfg, "BuffEffect") + env.minion.modDB:Sum("INC", nil, "BuffEffectOnSelf")
						local more = modStore:More(skillCfg, "BuffEffect") * env.minion.modDB:More(nil, "BuffEffectOnSelf") * calcLib.mod(modStore, skillCfg, "Magnitude")
						srcList:ScaleAddList(buff.modList, (1 + inc / 100) * more)
						mergeBuff(srcList, minionBuffs, buff.name)
					end
					if partyTabEnableExportBuffs and (buff.applyAllies or skillModList:Flag(nil, "BuffAppliesToAllies") or skillModList:Flag(nil, "BuffAppliesToPartyMembers")) then
						local inc = modStore:Sum("INC", skillCfg, "BuffEffect") + skillModList:Sum("INC", skillCfg, buff.name:gsub(" ", "").."Effect")
						local more = modStore:More(skillCfg, "BuffEffect") * calcLib.mod(modStore, skillCfg, "Magnitude")
						buffExports["Aura"]["otherEffects"] = buffExports["Aura"]["otherEffects"] or { }
						buffExports["Aura"]["otherEffects"][buff.name] =  { effectMult = (1 + inc / 100) * more, modList = buff.modList }
					end
				end
			elseif buff.type == "Guard" then
				if env.mode_buffs and (not skillFlags.totem or buff.allowTotemBuff) then
					local skillCfg = buff.activeSkillBuff and skillCfg
					local modStore = buff.activeSkillBuff and skillModList or modDB
				 	if not buff.applyNotPlayer then
						activeSkill.buffSkill = true
						local srcList = new("ModList"):ModList()
						local inc = modStore:Sum("INC", skillCfg, "BuffEffect", "BuffEffectOnSelf", "BuffEffectOnPlayer")
						local more = modStore:More(skillCfg, "BuffEffect", "BuffEffectOnSelf") * calcLib.mod(modStore, skillCfg, "Magnitude")
						srcList:ScaleAddList(buff.modList, (1 + inc / 100) * more)
						mergeBuff(srcList, guards, buff.name)
					end
				end
			elseif buff.type == "Warcry" then
				if env.mode_buffs then
					local skillCfg = skillCfg
					local modStore = skillModList or modDB
					local warcryPower = modDB:Override(nil, "WarcryPower") or m_max((modDB:Sum("BASE", nil, "WarcryPower") or 0) * (1 + (modDB:Sum("INC", nil, "WarcryPower") or 0)/100), (modDB:Sum("BASE", nil, "MinimumWarcryPower") or 0))
					local powerCap = skillModList:Sum("BASE", nil, "WarcryPowerCap")
					local powerPer = skillModList:Sum("BASE", nil, "WarcryPowerPer")
					local baseEmpowers = m_floor(m_min(warcryPower, powerCap) / powerPer)
					local warcryName = buff.name:gsub(" Cry", ""):gsub("'s",""):gsub(" ","")
					local baseEmpowers = modStore:Sum("BASE", env.player.mainSkill.skillCfg, warcryName.."EmpoweredAttacks") + baseEmpowers
					if baseEmpowers > 0 then
						local extraEmpowers = modStore:Sum("BASE", nil, "ExtraEmpoweredAttacks") or 0
						local EmpowerMultiplier = modStore:More(nil, "ExtraEmpoweredAttacks")
						local totalEmpowers = (baseEmpowers + extraEmpowers) * EmpowerMultiplier
						env.player.modDB:NewMod("Num"..warcryName.."Empowers", "BASE", totalEmpowers)
						if not warcryList[buff.name] then
							env.player.modDB:NewMod("Multiplier:EmpoweringWarcryCount", "BASE", 1, buff.name)
							warcryList[buff.name] = true
						end
						if breakdown then
							breakdown[warcryName.."EmpoweringWarcryCount"] = {
								s_format("(%d / %d) ^8(Power / per = base)", m_min(warcryPower, powerCap), powerPer),
								s_format("= ((%.2f + %.2f) x %.2f) ^8((base + extra) x more)", baseEmpowers, extraEmpowers, EmpowerMultiplier),
								s_format("= %.2f", totalEmpowers),
							}
						end
					end
					if not activeSkill.skillModList:Flag(nil, "CannotShareWarcryBuffs") then
						for _, warcryBuff in ipairs(buff.modList) do
							if warcryBuff[1] and warcryBuff[1].effectType == "Warcry" and warcryBuff[1].div then
								warcryBuff[1].warcryPowerBonus = m_floor((warcryBuff[1].limit and m_min(warcryPower, warcryBuff[1].limit) or warcryPower) / warcryBuff[1].div)
							end
						end
						local full_duration = calcSkillDuration(modStore, skillCfg, activeSkill.skillData, env, enemyDB)
						local actual_cooldown = calcSkillCooldown(modStore, skillCfg, activeSkill.skillData)
						local uptime = modDB:Flag(nil, "Condition:WarcryMaxHit") and 1 or m_min(full_duration / actual_cooldown, 1)
						local extraWarcryModList = activeSkill.activeEffect.grantedEffect.name == "Rallying Cry" and new("ModList"):ModList() or {}
						if not modDB:Flag(nil, "CannotGainWarcryBuffs") then
							if not buff.applyNotPlayer then
								activeSkill.buffSkill = true
								modDB.conditions["AffectedBy"..warcryName] = true
								local srcList = new("ModList"):ModList()
								local inc = modStore:Sum("INC", skillCfg, "BuffEffect", "BuffEffectOnSelf", "BuffEffectOnPlayer")
								local more = modStore:More(skillCfg, "BuffEffect", "BuffEffectOnSelf") * calcLib.mod(modStore, skillCfg, "Magnitude")
								for _, warcryBuff in ipairs(buff.modList) do
									local mult = (1 + inc / 100) * more * (warcryBuff[1].warcryPowerBonus or 1) * uptime
									srcList:ScaleAddList({warcryBuff}, mult)
								end
								mergeBuff(srcList, buffs, buff.name)
							end
						end
						if env.minion and not env.minion.modDB:Flag(nil, "HiddenMonster") then
							activeSkill.minionBuffSkill = true
							env.minion.modDB.conditions["AffectedBy"..warcryName] = true
							local srcList = new("ModList"):ModList()
							local inc = skillModList:Sum("INC", skillCfg, "BuffEffect") + env.minion.modDB:Sum("INC", skillCfg, "BuffEffectOnSelf")
							local more = skillModList:More(skillCfg, "BuffEffect") * env.minion.modDB:More(skillCfg, "BuffEffectOnSelf") * calcLib.mod(skillModList, skillCfg, "Magnitude")
							for _, warcryBuff in ipairs(buff.modList) do
								local mult = (1 + inc / 100) * more * (warcryBuff[1].warcryPowerBonus or 1) * uptime
								srcList:ScaleAddList({warcryBuff}, mult)
							end
							-- Special handling for the minion side to add the flat damage bonus
							if activeSkill.activeEffect.grantedEffect.name == "Rallying Cry" then
								local warcryPowerBonus = m_floor((m_min(warcryPower, 30)) / 5)
								local rallyingWeaponEffect = m_floor(activeSkill.skillModList:Sum("BASE", env.player.mainSkill.skillCfg, "RallyingCryAllyDamageBonusPer5Power") * warcryPowerBonus)
								local inc = modStore:Sum("INC", skillCfg, "BuffEffect") + env.minion.modDB:Sum("INC", skillCfg, "BuffEffectOnSelf")
								local rallyingBonusMoreMultiplier = 1 + (activeSkill.skillModList:Sum("BASE", env.player.mainSkill.skillCfg, "RallyingCryMinionDamageBonusMultiplier") or 0)
								-- Add all damage types
								local dmgTypeList = {"Physical", "Lightning", "Cold", "Fire", "Chaos"}
								for _, damageType in ipairs(dmgTypeList) do
									if env.player.weaponData1[damageType.."Min"] then
										extraWarcryModList:NewMod(damageType.."Min", "BASE", (env.player.weaponData1[damageType.."Min"] * rallyingWeaponEffect / 100), "Rallying Cry", 0, KeywordFlag.Attack, { type = "GlobalEffect", effectType = "Warcry", div = 5, limit = 30 })
									end
									if env.player.weaponData1[damageType.."Max"] then
										extraWarcryModList:NewMod(damageType.."Max", "BASE", (env.player.weaponData1[damageType.."Max"] * rallyingWeaponEffect / 100), "Rallying Cry", 0, KeywordFlag.Attack, { type = "GlobalEffect", effectType = "Warcry", div = 5, limit = 30 })
									end
								end
								srcList:ScaleAddList(extraWarcryModList, (1 + inc / 100) * rallyingBonusMoreMultiplier * uptime)
							end
							mergeBuff(srcList, minionBuffs, buff.name)
						end
						if partyTabEnableExportBuffs then
							local newModList = new("ModList"):ModList()
							local inc = skillModList:Sum("INC", skillCfg, "BuffEffect")
							local more = skillModList:More(skillCfg, "BuffEffect") * calcLib.mod(skillModList, skillCfg, "Magnitude")
							newModList:AddList(buff.modList)
							newModList:AddList(extraWarcryModList)
							buffExports["Warcry"][buff.name] = { effectMult = (1 + inc / 100) * more * uptime, modList = newModList }
						end
					end
				end
			elseif buff.type == "Aura" then
				if env.mode_buffs then
					-- Check for extra modifiers to apply to aura skills
					local extraAuraModList = { }
					for _, value in ipairs(modDB:List(skillCfg, "ExtraAuraEffect")) do
						local add = true
						for _, mod in ipairs(extraAuraModList) do
							if modLib.compareModParams(mod, value.mod) then
								mod.value = mod.value + value.mod.value
								add = false
								break
							end
						end
						if add then
							t_insert(extraAuraModList, copyTable(value.mod, true))
						end
					end
					if not activeSkill.skillData.auraCannotAffectSelf then
						local inc = skillModList:Sum("INC", skillCfg, "AuraEffect", "BuffEffect", "BuffEffectOnSelf", "AuraEffectOnSelf", "AuraBuffEffect", "SkillAuraEffectOnSelf")
						local more = skillModList:More(skillCfg, "AuraEffect", "BuffEffect", "BuffEffectOnSelf", "AuraEffectOnSelf", "AuraBuffEffect", "SkillAuraEffectOnSelf") * calcLib.mod(skillModList, skillCfg, "Magnitude")
						local mult = (1 + inc / 100) * more
						if modDB:Flag(nil, "AlliesAurasCannotAffectSelf") or not allyBuffs["Aura"] or not allyBuffs["Aura"][buff.name] or allyBuffs["Aura"][buff.name].effectMult / 100 <= mult then
							activeSkill.buffSkill = true
							modDB.conditions["AffectedByAura"] = true
							if buff.name:sub(1,4) == "Vaal" then
								modDB.conditions["AffectedBy"..buff.name:sub(6):gsub(" ","")] = true
							end
							modDB.conditions["AffectedBy"..buff.name:gsub(" ","")] = true
							local srcList = new("ModList"):ModList()
							srcList:ScaleAddList(buff.modList, mult)
							srcList:ScaleAddList(extraAuraModList, mult)
							mergeBuff(srcList, buffs, buff.name)
						end
					end
					if not (modDB:Flag(nil, "SelfAurasCannotAffectAllies") or modDB:Flag(nil, "SelfAurasOnlyAffectYou") or modDB:Flag(nil, "SelfAuraSkillsCannotAffectAllies")) then
						if env.minion and (not env.minion.hostile or modDB:Flag(nil, "AurasAffectEnemies")) and not env.minion.modDB:Flag(nil, "HiddenMonster") then
							local inc = skillModList:Sum("INC", skillCfg, "AuraEffect", "BuffEffect") + env.minion.modDB:Sum("INC", skillCfg, "BuffEffectOnSelf", "AuraEffectOnSelf")
							local more = skillModList:More(skillCfg, "AuraEffect", "BuffEffect") * env.minion.modDB:More(skillCfg, "BuffEffectOnSelf", "AuraEffectOnSelf") * calcLib.mod(skillModList, skillCfg, "Magnitude")
							local mult = (1 + inc / 100) * more
							if not allyBuffs["Aura"] or  not allyBuffs["Aura"][buff.name] or allyBuffs["Aura"][buff.name].effectMult / 100 <= mult then
								activeSkill.minionBuffSkill = true
								env.minion.modDB.conditions["AffectedBy"..buff.name:gsub(" ","")] = true
								env.minion.modDB.conditions["AffectedByAura"] = true
								local srcList = new("ModList"):ModList()
								srcList:ScaleAddList(buff.modList, mult)
								srcList:ScaleAddList(extraAuraModList, mult)
								mergeBuff(srcList, minionBuffs, buff.name)
							end
						end
						local inc = skillModList:Sum("INC", skillCfg, "AuraEffect", "BuffEffect")
						local more = skillModList:More(skillCfg, "AuraEffect", "BuffEffect") * calcLib.mod(skillModList, skillCfg, "Magnitude")
						local mult = (1 + inc / 100) * more
						local newModList = new("ModList"):ModList()
						newModList:AddList(buff.modList)
						newModList:AddList(extraAuraModList)
						if buffExports["Aura"][buff.name] then
							buffExports["Aura"][buff.name.."_Debuff"] = buffExports["Aura"][buff.name]
						end
						buffExports["Aura"][buff.name] = { effectMult = mult, modList = newModList }
					end
					local totemFlag
					if env.mode == "CALCS" then
						totemFlag = env.player.mainSkill.activeEffect.statSetCalcs.skillFlags.totem
					else
						totemFlag = env.player.mainSkill.activeEffect.statSet.skillFlags.totem
					end
					if totemFlag and not (modDB:Flag(nil, "SelfAurasCannotAffectAllies") or modDB:Flag(nil, "SelfAuraSkillsCannotAffectAllies")) then
						activeSkill.totemBuffSkill = true
						env.player.mainSkill.skillModList.conditions["AffectedBy"..buff.name:gsub(" ","")] = true
						env.player.mainSkill.skillModList.conditions["AffectedByAura"] = true

						local srcList = new("ModList"):ModList()
						local inc = skillModList:Sum("INC", skillCfg, "AuraEffect", "BuffEffect", "AuraBuffEffect")
						local more = skillModList:More(skillCfg, "AuraEffect", "BuffEffect", "AuraBuffEffect") * calcLib.mod(skillModList, skillCfg, "Magnitude")
						local lists = {extraAuraModList, buff.modList}
						local scale = (1 + inc / 100) * more
						scale = m_max(scale, 0)

						for _, modList in ipairs(lists) do
							for _, mod in ipairs(modList) do
								if mod.name == "EnergyShield" or mod.name == "Armour" or mod.name == "Evasion" or mod.name:match("Resist?M?a?x?$") then
									local totemMod = copyTable(mod)
									totemMod.name = "Totem"..totemMod.name
									if scale ~= 1 then
										if type(totemMod.value) == "number" then
											totemMod.value = (m_floor(totemMod.value) == totemMod.value) and m_modf(round(totemMod.value * scale, 2)) or totemMod.value * scale
										elseif type(totemMod.value) == "table" and totemMod.value.mod then
											totemMod.value.mod.value = (m_floor(totemMod.value.mod.value) == totemMod.value.mod.value) and m_modf(round(totemMod.value.mod.value * scale, 2)) or totemMod.value.mod.value * scale
										end
									end
									srcList:AddMod(totemMod)
								end
							end
						end
						mergeBuff(srcList, buffs, "Totem "..buff.name)
					end
					-- check if aura has a debuff added to it, but does not have an auraDebuff
					if env.mode_effective and #modDB:List(skillCfg, "ExtraAuraDebuffEffect") > 0 and not modDB:Flag(nil, "SelfAurasOnlyAffectYou") then
						local auraDebuffFound = false
						for _, buff in ipairs(activeSkill.buffList) do
							if buff.type == "AuraDebuff" then
								auraDebuffFound = true
								break
							end
						end
						if not auraDebuffFound then
							activeSkill.debuffSkill = true
							local extraAuraModList = { }
							for _, value in ipairs(modDB:List(skillCfg, "ExtraAuraDebuffEffect")) do
								local add = true
								for _, mod in ipairs(extraAuraModList) do
									if modLib.compareModParams(mod, value.mod) then
										mod.value = mod.value + value.mod.value
										add = false
										break
									end
								end
								if add then
									t_insert(extraAuraModList, copyTable(value.mod, true))
								end
							end
							local inc = skillModList:Sum("INC", skillCfg, "AuraEffect", "BuffEffect", "DebuffEffect")
							local more = skillModList:More(skillCfg, "AuraEffect", "BuffEffect", "DebuffEffect") * calcLib.mod(skillModList, skillCfg, "Magnitude")
							local mult = (1 + inc / 100) * more
							local newModList = new("ModList"):ModList()
							newModList:AddList(extraAuraModList)
							buffExports["Aura"][buff.name..(buffExports["Aura"][buff.name] and "_Debuff" or "")] = { effectMult = mult, modList = newModList }
							if allyBuffs["AuraDebuff"] and allyBuffs["AuraDebuff"][buff.name] and allyBuffs["AuraDebuff"][buff.name].effectMult / 100 > mult then
								mult = 0
							end
							mergeBuff(newModList, debuffs, buff.name)
						end
					end
				end
			elseif buff.type == "Debuff" or buff.type == "AuraDebuff" then
				local stackCount
				if buff.stackVar then
					stackCount = skillModList:Sum("BASE", skillCfg, "Multiplier:"..buff.stackVar)
					if buff.stackLimit then
						stackCount = m_min(stackCount, buff.stackLimit)
					elseif buff.stackLimitVar then
						stackCount = m_min(stackCount, skillModList:Sum("BASE", skillCfg, "Multiplier:"..buff.stackLimitVar))
					end
				else
					stackCount = activeSkill.skillData.stackCount or 1
				end
				if env.mode_effective and stackCount > 0 then
					activeSkill.debuffSkill = true
					enemyDB.conditions["AffectedBy"..buff.name:gsub(" ","")] = true
					modDB.conditions["AffectedBy"..buff.name:gsub(" ","")] = true
					local srcList = new("ModList"):ModList()
					local mult = 1
					local extraAuraModList = { }
					if buff.type == "AuraDebuff" then
						for _, value in ipairs(modDB:List(skillCfg, "ExtraAuraDebuffEffect")) do
							local add = true
							for _, mod in ipairs(extraAuraModList) do
								if modLib.compareModParams(mod, value.mod) then
									mod.value = mod.value + value.mod.value
									add = false
									break
								end
							end
							if add then
								t_insert(extraAuraModList, copyTable(value.mod, true))
							end
						end
						mult = 0
						if not modDB:Flag(nil, "SelfAurasOnlyAffectYou") then
							local inc = skillModList:Sum("INC", skillCfg, "AuraEffect", "BuffEffect", "DebuffEffect")
							local more = skillModList:More(skillCfg, "AuraEffect", "BuffEffect", "DebuffEffect") * calcLib.mod(skillModList, skillCfg, "Magnitude")
							mult = (1 + inc / 100) * more
							local newModList = {}
							for _, mod in ipairs(buff.modList) do
								t_insert(newModList, mod)
							end
							for _, mod in ipairs(extraAuraModList) do
								t_insert(newModList, mod)
							end
							-- A full modlist causes issues with copy table for mine auras
							--local newModList = new("ModList"):ModList()
							--newModList:AddList(buff.modList)
							--newModList:AddList(extraAuraModList)
							buffExports["Aura"][buff.name..(buffExports["Aura"][buff.name] and "_Debuff" or "")] = { effectMult = mult, modList = newModList }
							if allyBuffs["AuraDebuff"] and allyBuffs["AuraDebuff"][buff.name] and allyBuffs["AuraDebuff"][buff.name].effectMult / 100 > mult then
								mult = 0
							end
						end
					end
					if buff.type == "Debuff" then
						local specificDebuffMult = calcLib.mod(skillModList, skillCfg, buff.name:gsub(" ", "").."Magnitude") -- non-skill mods specific to that debuff type
						local skillMagnitudeMult = calcLib.mod(skillModList, skillCfg, "Magnitude")
						local inc = skillModList:Sum("INC", skillCfg, "DebuffEffect")
						local more = skillModList:More(skillCfg, "DebuffEffect") * skillMagnitudeMult * specificDebuffMult
						mult = (1 + inc / 100) * more
					end
					srcList:ScaleAddList(buff.modList, mult * stackCount)
					srcList:ScaleAddList(extraAuraModList, mult * stackCount)
					if activeSkill.skillData.stackCount or buff.stackVar then
						srcList:NewMod("Multiplier:"..buff.name.."Stack", "BASE", stackCount, buff.name)
					end
					mergeBuff(srcList, debuffs, buff.name)
				end
			elseif buff.type == "Curse" or buff.type == "CurseBuff" then
				local mark = activeSkill.skillTypes[SkillType.Mark]
				modDB.conditions["SelfCast"..buff.name:gsub(" ","")] = not (activeSkill.skillTypes[SkillType.Triggered] or activeSkill.skillTypes[SkillType.Aura])
				if env.mode_effective and (not enemyDB:Flag(nil, "Hexproof") or modDB:Flag(nil, "CursesIgnoreHexproof") or activeSkill.skillData.ignoreCurseLimit or activeSkill.skillData.ignoreHexproof) or mark then
					local curse = {
						name = buff.name,
						fromPlayer = true,
						priority = determineCursePriority(buff.name, activeSkill),
						isMark = mark,
						ignoreCurseLimit = (modDB:Flag(activeSkill.skillCfg, "CursesIgnoreCurseLimit") or activeSkill.skillData.ignoreCurseLimit or activeSkill.skillModList:Flag(nil, "CursesIgnoreCurseLimit")) and not mark or false,
						socketedCursesHexLimit = modDB:Flag(activeSkill.skillCfg, "SocketedCursesAdditionalLimit")
					}
					local inc = skillModList:Sum("INC", skillCfg, "CurseEffect") + enemyDB:Sum("INC", nil, "CurseEffectOnSelf")
					if activeSkill.skillTypes[SkillType.Aura] then
						inc = inc + skillModList:Sum("INC", skillCfg, "AuraEffect")
					end
					local more = skillModList:More(skillCfg, "CurseEffect") * calcLib.mod(skillModList, skillCfg, "Magnitude")
					local moreMark = more
					-- This is non-ideal, but the only More for enemy is the boss effect
					if not curse.isMark then
						more = more * enemyDB:More(nil, "CurseEffectOnSelf")
					end
					local mult = 0
					if not (modDB:Flag(nil, "SelfAurasOnlyAffectYou") and activeSkill.skillTypes[SkillType.Aura]) then --If your aura only effect you blasphemy does nothing
						mult = (1 + inc / 100) * more
					end
					if buff.type == "Curse" then
						curse.modList = new("ModList"):ModList()
						curse.modList:ScaleAddList(buff.modList, mult, true)
						if partyTabEnableExportBuffs then
							buffExports["Curse"][buff.name] = { isMark = curse.isMark, effectMult = curse.isMark and mult or (1 + inc / 100) * moreMark, modList = buff.modList }
						end
					else
						-- Curse applies a buff; scale by curse effect, then buff effect
						local temp = new("ModList"):ModList()
						temp:ScaleAddList(buff.modList, mult, true)
						curse.buffModList = new("ModList"):ModList()
						local buffInc = modDB:Sum("INC", skillCfg, "BuffEffectOnSelf")
						local buffMore = modDB:More(skillCfg, "BuffEffectOnSelf")
						curse.buffModList:ScaleAddList(temp, (1 + buffInc / 100) * buffMore, true)
						if env.minion then
							curse.minionBuffModList = new("ModList"):ModList()
							local buffInc = env.minion.modDB:Sum("INC", nil, "BuffEffectOnSelf")
							local buffMore = env.minion.modDB:More(nil, "BuffEffectOnSelf")
							curse.minionBuffModList:ScaleAddList(temp, (1 + buffInc / 100) * buffMore, true)
						end
					end
					t_insert(curses, curse)
				end
			elseif buff.type == "Link" then
				local linksApplyToMinions = env.minion and not env.minion.modDB:Flag(nil, "HiddenMonster") and modDB:Flag(nil, "Condition:CanLinkToMinions") and modDB:Flag(nil, "Condition:LinkedToMinion")
						and not env.minion.modDB:Flag(nil, "Condition:CannotBeDamaged") and not env.minion.mainSkill.summonSkill.skillTypes[SkillType.MinionsAreUndamageable]
				if env.mode_buffs and (#linkSkills < 1) and (partyTabEnableExportBuffs or linksApplyToMinions) then
					-- Check for extra modifiers to apply to link skills
					local extraLinkModList = { }
					for _, value in ipairs(modDB:List(skillCfg, "ExtraLinkEffect")) do
						local add = true
						for _, mod in ipairs(extraLinkModList) do
							if modLib.compareModParams(mod, value.mod) then
								mod.value = mod.value + value.mod.value
								add = false
								break
							end
						end
						if add then
							t_insert(extraLinkModList, copyTable(value.mod, true))
							-- special handling to add this early
							if value.mod.name == "ParentNonUniqueFlasksAppliedToYou" then
								nonUniqueFlasksApplyToMinion = true
							end
						end
					end
					local inc = skillModList:Sum("INC", skillCfg, "LinkEffect", "BuffEffect")
					local more = skillModList:More(skillCfg, "LinkEffect", "BuffEffect") * calcLib.mod(skillModList, skillCfg, "Magnitude")
					local mult = (1 + inc / 100) * more
					if partyTabEnableExportBuffs then
						local newModList = new("ModList"):ModList()
						newModList:AddList(buff.modList)
						newModList:AddList(extraLinkModList)
						buffExports["Link"][buff.name] = { effectMult = mult, modList = newModList }
					end
					if linksApplyToMinions then
						activeSkill.minionBuffSkill = true
						env.minion.modDB.conditions["AffectedBy"..buff.name:gsub(" ","")] = true
						env.minion.modDB.conditions["AffectedByLink"] = true
						local srcList = new("ModList"):ModList()
						inc = inc + env.minion.modDB:Sum("INC", nil, "BuffEffectOnSelf", "LinkEffectOnSelf")
						more = more * env.minion.modDB:More(nil, "BuffEffectOnSelf", "LinkEffectOnSelf")
						mult = (1 + inc / 100) * more
						srcList:ScaleAddList(buff.modList, mult)
						srcList:ScaleAddList(extraLinkModList, mult)
						mergeBuff(srcList, minionBuffs, buff.name)
						linkSkills[1] = buff.name
					end
				end
			end
		end
		if activeSkill.skillModList:Flag(nil, "Condition:CanWither") or (activeSkill.minion and env.minion and env.minion.modDB:Flag(nil, "Condition:CanWither")) then
			local effect = activeSkill.minion and 5 or m_floor(5 * (1 + modDB:Sum("INC", nil, "WitherEffect") / 100))
			modDB:NewMod("WitherEffectStack", "MAX", effect)
		end
		if activeSkill.skillModList:Flag(nil, "ApplyCriticalWeakness") then
			modDB:NewMod("ApplyCriticalWeakness", "FLAG", true)
		end
		if activeSkill.skillModList:Flag(nil, "CanParry") then
			modDB:NewMod("CanParry", "FLAG", true)
		end
		--Handle combustion
		if enemyDB:Flag(nil, "Condition:Ignited") and (activeSkill.skillTypes[SkillType.Damage] or activeSkill.skillTypes[SkillType.Attack]) and not appliedCombustion then
			for _, support in ipairs(activeSkill.supportList) do
				if support.grantedEffect.name == "Combustion" then
					if not activeSkill.skillModList:Flag(activeSkill.skillCfg, "CannotIgnite") then
						local value = activeSkill.skillModList:Sum("BASE", activeSkill.skillCfg, "CombustionFireResist")
						enemyDB:NewMod("FireResist", "BASE", value, "Combustion", { type = "GlobalEffect", effectType = "Debuff", effectName = "Combustion" }, { type = "Condition", var = "Ignited" })
						appliedCombustion = true
					end
					break
				end
			end
		end
		if activeSkill.minion and activeSkill.minion.activeSkillList then
			local castingMinion = activeSkill.minion
			for _, activeMinionSkill in ipairs(activeSkill.minion.activeSkillList) do
				local skillModList = activeMinionSkill.skillModList
				local skillCfg = activeMinionSkill.skillCfg
				for _, buff in ipairs(activeMinionSkill.buffList) do
					if buff.type == "Buff" then
						if env.mode_buffs and activeMinionSkill.skillData.enable then
							local skillCfg = buff.activeSkillBuff and skillCfg
							local modStore = buff.activeSkillBuff and skillModList or castingMinion.modDB
							if buff.applyAllies then
								activeMinionSkill.buffSkill = true
								modDB.conditions["AffectedBy"..buff.name:gsub(" ","")] = true
								local srcList = new("ModList"):ModList()
								local inc = modStore:Sum("INC", skillCfg, "BuffEffect", "BuffEffectOnPlayer") + modDB:Sum("INC", nil, "BuffEffectOnSelf")
								local more = modStore:More(skillCfg, "BuffEffect", "BuffEffectOnPlayer") * modDB:More(nil, "BuffEffectOnSelf") * calcLib.mod(skillModList, skillCfg, "Magnitude")
								srcList:ScaleAddList(buff.modList, (1 + inc / 100) * more)
								mergeBuff(srcList, buffs, buff.name)
								mergeBuff(buff.modList, buffs, buff.name)
								if activeMinionSkill.skillData.thisIsNotABuff then
									buffs[buff.name].notBuff = true
								end
								if partyTabEnableExportBuffs then
									local inc = modStore:Sum("INC", skillCfg, "BuffEffect")
									local more = modStore:More(skillCfg, "BuffEffect")
									buffExports["Aura"]["otherEffects"] = buffExports["Aura"]["otherEffects"] or { }
									buffExports["Aura"]["otherEffects"][buff.name] =  { effectMult = (1 + inc / 100) * more, modList = buff.modList }
								end
							end
							local envMinionCheck = (env.minion and not env.minion.modDB:Flag(nil, "HiddenMonster") and (env.minion == castingMinion or buff.applyAllies))
							if buff.applyMinions or envMinionCheck then
								activeMinionSkill.minionBuffSkill = true
								if envMinionCheck then
									env.minion.modDB.conditions["AffectedBy"..buff.name:gsub(" ","")] = true
								else
									activeSkill.minion.modDB.conditions["AffectedBy"..buff.name:gsub(" ","")] = true
								end
								local srcList = new("ModList"):ModList()
								local inc = modStore:Sum("INC", skillCfg, "BuffEffect", (env.minion == castingMinion) and "BuffEffectOnSelf" or nil)
								local more = modStore:More(skillCfg, "BuffEffect", (env.minion == castingMinion) and "BuffEffectOnSelf" or nil) * calcLib.mod(modStore, skillCfg, "Magnitude")
								srcList:ScaleAddList(buff.modList, (1 + inc / 100) * more)
								mergeBuff(srcList, minionBuffs, buff.name)
								mergeBuff(buff.modList, minionBuffs, buff.name)
								if activeMinionSkill.skillData.thisIsNotABuff then
									buffs[buff.name].notBuff = true
								end
							end
						end
					elseif buff.type == "Aura" then
						if env.mode_buffs and activeMinionSkill.skillData.enable then
							-- Check for extra modifiers to apply to aura skills
							local extraAuraModList = { }
							for _, value in ipairs(activeSkill.minion.modDB:List(skillCfg, "ExtraAuraEffect")) do
								local add = true
								for _, mod in ipairs(extraAuraModList) do
									if modLib.compareModParams(mod, value.mod) then
										mod.value = mod.value + value.mod.value
										add = false
										break
									end
								end
								if add then
									t_insert(extraAuraModList, copyTable(value.mod, true))
								end
							end
							if not (activeSkill.minion.modDB:Flag(nil, "SelfAurasCannotAffectAllies") or activeSkill.minion.modDB:Flag(nil, "SelfAurasOnlyAffectYou") or activeSkill.minion.modDB:Flag(nil, "SelfAuraSkillsCannotAffectAllies")) then
								if not modDB:Flag(nil, "AlliesAurasCannotAffectSelf") and not modDB.conditions["AffectedBy"..buff.name:gsub(" ","")] then
									local inc = skillModList:Sum("INC", skillCfg, "AuraEffect", "BuffEffect", "BuffEffectOnPlayer", "AuraBuffEffect") + modDB:Sum("INC", skillCfg, "BuffEffectOnSelf", "AuraEffectOnSelf")
									local more = skillModList:More(skillCfg, "AuraEffect", "BuffEffect", "AuraBuffEffect") * modDB:More(skillCfg, "BuffEffectOnSelf", "AuraEffectOnSelf") * calcLib.mod(skillModList, skillCfg, "Magnitude")
									local mult = (1 + inc / 100) * more
									if not allyBuffs["Aura"] or not allyBuffs["Aura"][buff.name] or allyBuffs["Aura"][buff.name].effectMult / 100 <= mult then
										activeMinionSkill.buffSkill = true
										modDB.conditions["AffectedByAura"] = true
										if buff.name:sub(1,4) == "Vaal" then
											modDB.conditions["AffectedBy"..buff.name:sub(6):gsub(" ","")] = true
										end
										modDB.conditions["AffectedBy"..buff.name:gsub(" ","")] = true
										local srcList = new("ModList"):ModList()
										srcList:ScaleAddList(buff.modList, mult)
										srcList:ScaleAddList(extraAuraModList, mult)
										setSpectreSource(srcList, buff.name, activeSkill, castingMinion)
										mergeBuff(srcList, buffs, buff.name)
									end
								end
								if env.minion and not env.minion.modDB:Flag(nil, "HiddenMonster") and not env.minion.modDB.conditions["AffectedBy"..buff.name:gsub(" ","")] and (env.minion ~= activeSkill.minion or not activeSkill.skillData.auraCannotAffectSelf)  then
									local inc = skillModList:Sum("INC", skillCfg, "AuraEffect", "BuffEffect") + env.minion.modDB:Sum("INC", skillCfg, "BuffEffectOnSelf", "AuraEffectOnSelf")
									local more = skillModList:More(skillCfg, "AuraEffect", "BuffEffect") * env.minion.modDB:More(skillCfg, "BuffEffectOnSelf", "AuraEffectOnSelf") * calcLib.mod(skillModList, skillCfg, "Magnitude")
									local mult = (1 + inc / 100) * more
									if not allyBuffs["Aura"] or  not allyBuffs["Aura"][buff.name] or allyBuffs["Aura"][buff.name].effectMult / 100 <= mult then
										activeMinionSkill.minionBuffSkill = true
										env.minion.modDB.conditions["AffectedBy"..buff.name:gsub(" ","")] = true
										env.minion.modDB.conditions["AffectedByAura"] = true
										local srcList = new("ModList"):ModList()
										srcList:ScaleAddList(buff.modList, mult)
										srcList:ScaleAddList(extraAuraModList, mult)
										setSpectreSource(srcList, buff.name, activeSkill, castingMinion)
										mergeBuff(srcList, minionBuffs, buff.name)
									end
								end
								local inc = skillModList:Sum("INC", skillCfg, "AuraEffect", "BuffEffect")
								local more = skillModList:More(skillCfg, "AuraEffect", "BuffEffect") * calcLib.mod(skillModList, skillCfg, "Magnitude")
								local mult = (1 + inc / 100) * more
								local newModList = new("ModList"):ModList()
								newModList:AddList(buff.modList)
								newModList:AddList(extraAuraModList)
								setSpectreSource(newModList, buff.name, activeSkill, castingMinion)
								if buffExports["Aura"][buff.name] then
									buffExports["Aura"][buff.name.."_Debuff"] = buffExports["Aura"][buff.name]
								end
								buffExports["Aura"][buff.name] = { effectMult = mult, modList = newModList }
								local totemFlag
								if env.mode == "CALCS" then
									totemFlag = env.player.mainSkill.activeEffect.statSetCalcs.skillFlags.totem
								else
									totemFlag = env.player.mainSkill.activeEffect.statSet.skillFlags.totem
								end
								if totemFlag and not env.player.mainSkill.skillModList.conditions["AffectedBy"..buff.name:gsub(" ","")] then
									activeMinionSkill.totemBuffSkill = true
									env.player.mainSkill.skillModList.conditions["AffectedBy"..buff.name:gsub(" ","")] = true
									env.player.mainSkill.skillModList.conditions["AffectedByAura"] = true

									local srcList = new("ModList"):ModList()
									local inc = skillModList:Sum("INC", skillCfg, "AuraEffect", "BuffEffect", "AuraBuffEffect")
									local more = skillModList:More(skillCfg, "AuraEffect", "BuffEffect", "AuraBuffEffect") * calcLib.mod(skillModList, skillCfg, "Magnitude")
									local lists = {extraAuraModList, buff.modList}
									local scale = (1 + inc / 100) * more
									scale = m_max(scale, 0)

									for _, modList in ipairs(lists) do
										for _, mod in ipairs(modList) do
											if mod.name == "EnergyShield" or mod.name == "Armour" or mod.name == "Evasion" or mod.name:match("Resist?M?a?x?$") then
												local totemMod = copyTable(mod)
												totemMod.name = "Totem"..totemMod.name
												if scale ~= 1 then
													if type(totemMod.value) == "number" then
														totemMod.value = (m_floor(totemMod.value) == totemMod.value) and m_modf(round(totemMod.value * scale, 2)) or totemMod.value * scale
													elseif type(totemMod.value) == "table" and totemMod.value.mod then
														totemMod.value.mod.value = (m_floor(totemMod.value.mod.value) == totemMod.value.mod.value) and m_modf(round(totemMod.value.mod.value * scale, 2)) or totemMod.value.mod.value * scale
													end
												end
												srcList:AddMod(totemMod)
											end
										end
									end
									setSpectreSource(srcList, nil, activeSkill, castingMinion)
									mergeBuff(srcList, buffs, "Totem "..buff.name)
								end
							end
						end
					elseif buff.type == "Curse" then
						if env.mode_effective and activeMinionSkill.skillData.enable and (not enemyDB:Flag(nil, "Hexproof") or activeMinionSkill.skillTypes[SkillType.Mark]) then
							local curse = {
								name = buff.name,
								priority = determineCursePriority(buff.name, activeMinionSkill),
							}
							local inc = skillModList:Sum("INC", skillCfg, "CurseEffect") + enemyDB:Sum("INC", nil, "CurseEffectOnSelf")
							local more = skillModList:More(skillCfg, "CurseEffect") * enemyDB:More(nil, "CurseEffectOnSelf") * calcLib.mod(skillModList, skillCfg, "Magnitude")
							curse.modList = new("ModList"):ModList()
							curse.modList:ScaleAddList(buff.modList, (1 + inc / 100) * more)
							t_insert(minionCurses, curse)
						end
					elseif buff.type == "Debuff" or buff.type == "AuraDebuff" then
						local stackCount
						if buff.stackVar then
							stackCount = skillModList:Sum("BASE", skillCfg, "Multiplier:"..buff.stackVar)
							if buff.stackLimit then
								stackCount = m_min(stackCount, buff.stackLimit)
							elseif buff.stackLimitVar then
								stackCount = m_min(stackCount, skillModList:Sum("BASE", skillCfg, "Multiplier:"..buff.stackLimitVar))
							end
						else
							stackCount = activeMinionSkill.skillData.stackCount or 1
						end
						if env.mode_effective and stackCount > 0 then
							activeMinionSkill.debuffSkill = true
							local srcList = new("ModList"):ModList()
							local mult = 1
							if buff.type == "AuraDebuff" then
								mult = 0
								if not skillModList:Flag(nil, "SelfAurasOnlyAffectYou") then
									local inc = skillModList:Sum("INC", skillCfg, "AuraEffect", "BuffEffect", "DebuffEffect")
									local more = skillModList:More(skillCfg, "AuraEffect", "BuffEffect", "DebuffEffect") * calcLib.mod(skillModList, skillCfg, "Magnitude")
									mult = (1 + inc / 100) * more
									if not enemyDB.conditions["AffectedBy"..buff.name:gsub(" ","")] then
										buffExports["Aura"][buff.name..(buffExports["Aura"][buff.name] and "_Debuff" or "")] = { effectMult = mult, modList = buff.modList }
										if allyBuffs["AuraDebuff"] and allyBuffs["AuraDebuff"][buff.name] and allyBuffs["AuraDebuff"][buff.name].effectMult / 100 > mult then
											mult = 0
										end
									else
										mult = 0
									end
								end
							end
							enemyDB.conditions["AffectedBy"..buff.name:gsub(" ","")] = true
							if env.minion and not env.minion.modDB:Flag(nil, "HiddenMonster") and env.minion == activeSkill.minion then
								env.minion.modDB.conditions["AffectedBy"..buff.name:gsub(" ","")] = true
							end
							if buff.type == "Debuff" then
								local inc = skillModList:Sum("INC", skillCfg, "DebuffEffect")
								local more = skillModList:More(skillCfg, "DebuffEffect")
								mult = (1 + inc / 100) * more
							end
							srcList:ScaleAddList(buff.modList, mult * stackCount)
							if activeMinionSkill.skillData.stackCount or buff.stackVar then
								srcList:NewMod("Multiplier:"..buff.name.."Stack", "BASE", activeMinionSkill.skillData.stackCount, buff.name)
							end
							mergeBuff(srcList, debuffs, buff.name)
						end
					end
				end
			end
		end
	end
	if allyBuffs["otherEffects"] then
		for buffName, buff in pairs(allyBuffs["otherEffects"]) do
			modDB.conditions["AffectedBy"..buffName:gsub(" ","")] = true
			local inc = modDB:Sum("INC", nil, "BuffEffectOnSelf", "AuraEffectOnSelf")
			local more = modDB:More(nil, "BuffEffectOnSelf", "AuraEffectOnSelf")
			local srcList = new("ModList"):ModList()
			srcList:ScaleAddList(buff.modList, (buff.effectMult + inc) / 100 * more)
			mergeBuff(srcList, buffs, buffName)
			if env.minion and not env.minion.modDB:Flag(nil, "HiddenMonster") then
				env.minion.modDB.conditions["AffectedBy"..buffName:gsub(" ","")] = true
				local inc = env.minion.modDB:Sum("INC", nil, "BuffEffectOnSelf", "AuraEffectOnSelf")
				local more = env.minion.modDB:More(nil, "BuffEffectOnSelf", "AuraEffectOnSelf")
				local srcList = new("ModList"):ModList()
				srcList:ScaleAddList(buff.modList, (buff.effectMult + inc) / 100 * more)
				mergeBuff(srcList, minionBuffs, buffName)
			end
		end
	end
	if allyBuffs["Aura"] then
		for auraName, aura in pairs(allyBuffs["Aura"]) do
			if auraName ~= "Vaal" then
				local auraNameCompressed = auraName:gsub(" ","")
				if not modDB:Flag(nil, "AlliesAurasCannotAffectSelf") and not modDB.conditions["AffectedBy"..auraNameCompressed] then
					modDB.conditions["AffectedByAura"] = true
					modDB.conditions["AffectedBy"..auraNameCompressed] = true
					local srcList = new("ModList"):ModList()
					srcList:ScaleAddList(aura.modList, aura.effectMult / 100)
					mergeBuff(srcList, buffs, auraName)
				end
				if env.minion and not env.minion.modDB:Flag(nil, "HiddenMonster") and not env.minion.modDB.conditions["AffectedBy"..auraNameCompressed] then
					env.minion.modDB.conditions["AffectedByAura"] = true
					env.minion.modDB.conditions["AffectedBy"..auraNameCompressed] = true
					local srcList = new("ModList"):ModList()
					srcList:ScaleAddList(aura.modList, aura.effectMult / 100)
					mergeBuff(srcList, minionBuffs, auraName)
				end
			end
		end
		if allyBuffs["Aura"]["Vaal"] then
			for auraName, aura in pairs(allyBuffs["Aura"]["Vaal"]) do
				local auraNameCompressed = auraName:gsub(" ","")
				if not modDB:Flag(nil, "AlliesAurasCannotAffectSelf") and not modDB.conditions["AffectedBy"..auraNameCompressed] then
					modDB.conditions["AffectedByAura"] = true
					modDB.conditions["AffectedBy"..auraName:sub(6):gsub(" ","")] = true
					modDB.conditions["AffectedBy"..auraNameCompressed] = true
					local srcList = new("ModList"):ModList()
					srcList:ScaleAddList(aura.modList, aura.effectMult / 100)
					mergeBuff(srcList, buffs, auraName)
				end
				if env.minion and not env.minion.modDB:Flag(nil, "HiddenMonster") and not env.minion.modDB.conditions["AffectedBy"..auraNameCompressed] then
					env.minion.modDB.conditions["AffectedByAura"] = true
					env.minion.modDB.conditions["AffectedBy"..auraNameCompressed] = true
					local srcList = new("ModList"):ModList()
					srcList:ScaleAddList(aura.modList, aura.effectMult / 100)
					mergeBuff(srcList, minionBuffs, auraName)
				end
			end
		end
	end
	if allyBuffs["AuraDebuff"] and env.mode_effective then
		for auraName, aura in pairs(allyBuffs["AuraDebuff"]) do
			if auraName ~= "Vaal" then
				local auraNameCompressed = auraName:gsub(" ","")
				if not enemyDB.conditions["AffectedBy"..auraNameCompressed] then
					enemyDB.conditions["AffectedBy"..auraNameCompressed] = true
					modDB.conditions["AffectedBy"..auraNameCompressed] = true
					local srcList = new("ModList"):ModList()
					srcList:ScaleAddList(aura.modList, aura.effectMult / 100)
					mergeBuff(srcList, debuffs, auraName)
				end
			end
		end
		if allyBuffs["AuraDebuff"]["Vaal"] then
			for auraName, aura in pairs(allyBuffs["AuraDebuff"]["Vaal"]) do
				local auraNameCompressed = auraName:gsub(" ","")
				if not enemyDB.conditions["AffectedBy"..auraNameCompressed] then
					enemyDB.conditions["AffectedBy"..auraNameCompressed] = true
					modDB.conditions["AffectedBy"..auraNameCompressed] = true
					local srcList = new("ModList"):ModList()
					srcList:ScaleAddList(aura.modList, aura.effectMult / 100)
					mergeBuff(srcList, debuffs, auraName)
				end
			end
		end
	end
	if env.partyMembers["Warcry"] and env.partyMembers["Warcry"]["Warcry"] then
		for warcryName, warcry in pairs(env.partyMembers["Warcry"]["Warcry"]) do
			local warcryNameCompressed = warcryName:gsub(" ","")
			if not modDB.conditions["AffectedBy"..warcryNameCompressed] then
				modDB.conditions["AffectedByWarcry"] = true
				modDB.conditions["AffectedBy"..warcryNameCompressed] = true
				local srcList = new("ModList"):ModList()
				for _, warcryBuff in ipairs(warcry.modList) do
					srcList:ScaleAddList({warcryBuff}, (warcry.effectMult or 100) / 100 * (warcryBuff[1].warcryPowerBonus or 1))
				end
				mergeBuff(srcList, buffs, warcryName)
			end
			if env.minion and not env.minion.modDB:Flag(nil, "HiddenMonster") and not env.minion.modDB.conditions["AffectedBy"..warcryNameCompressed] then
				env.minion.modDB.conditions["AffectedByWarcry"] = true
				env.minion.modDB.conditions["AffectedBy"..warcryNameCompressed] = true
				local srcList = new("ModList"):ModList()
				for _, warcryBuff in ipairs(warcry.modList) do
					srcList:ScaleAddList({warcryBuff}, (warcry.effectMult or 100) / 100 * (warcryBuff[1].warcryPowerBonus or 1))
				end
				mergeBuff(srcList, minionBuffs, warcryName)
			end
		end
	end
	if env.partyMembers["Link"] and env.partyMembers["Link"]["Link"] then
		for linkName, link in pairs(env.partyMembers["Link"]["Link"]) do
			local linkNameCompressed = linkName:gsub(" ","")
			if not modDB.conditions["AffectedBy"..linkNameCompressed] then
				modDB.conditions["AffectedByLink"] = true
				modDB.conditions["AffectedBy"..linkNameCompressed] = true
				local srcList = new("ModList"):ModList()
				srcList:ScaleAddList(link.modList, (link.effectMult or 100) / 100)
				mergeBuff(srcList, buffs, linkName)
			end
		end
	end

	if env.mode_combat then
		-- This needs to be done in 2 steps to account for effects affecting life recovery from flasks
		-- For example Sorrow of the Divine and buffs (like flask recovery watchers eye)
		mergeFlasks(env.flasks, true, nonUniqueFlasksApplyToMinion)
	end

	-- Calculate charges early to enable usage of stats that depend on charge count
	doActorCharges(env, env.player)

	-- Process stats from alternate charges
	-- None currently in PoE 2

	-- Check for extra curses
	for dest, modDB in pairs({[curses] = modDB, [minionCurses] = env.minion and env.minion.modDB}) do
		for _, value in ipairs(modDB:List(nil, "ExtraCurse")) do
			local gemModList = new("ModList"):ModList()
			local grantedEffect = env.data.skills[value.skillId]
			if grantedEffect then
				calcs.mergeSkillInstanceMods(env, gemModList, {
					grantedEffect = grantedEffect,
					level = value.level,
					quality = 0,
				})
				local curseModList = { }
				for _, mod in ipairs(gemModList) do
					for _, tag in ipairs(mod) do
						if tag.type == "GlobalEffect" and tag.effectType == "Curse" then
							t_insert(curseModList, mod)
							break
						end
					end
				end
				if value.applyToPlayer then
					-- Sources for curses on the player don't usually respect any kind of limit, so there's little point bothering with slots
					if modDB:Sum("BASE", nil, "AvoidCurse") < 100 then
						modDB.conditions["Cursed"] = true
						modDB.multipliers["CurseOnSelf"] = (modDB.multipliers["CurseOnSelf"] or 0) + 1
						modDB.conditions["AffectedBy"..grantedEffect.name:gsub(" ","")] = true
						local cfg = { skillName = grantedEffect.name }
						local inc = modDB:Sum("INC", cfg, "CurseEffectOnSelf") + gemModList:Sum("INC", nil, "CurseEffectAgainstPlayer")
						local more = modDB:More(cfg, "CurseEffectOnSelf") * gemModList:More(nil, "CurseEffectAgainstPlayer")
						modDB:ScaleAddList(curseModList, m_max((1 + inc / 100) * more, 0), true)
					end
				elseif not enemyDB:Flag(nil, "Hexproof") or modDB:Flag(nil, "CursesIgnoreHexproof") then
					local curse = {
						name = grantedEffect.name,
						fromPlayer = (dest == curses),
						priority = determineCursePriority(grantedEffect.name),
					}
					curse.modList = new("ModList"):ModList()
					curse.modList:ScaleAddList(curseModList, (1 + enemyDB:Sum("INC", nil, "CurseEffectOnSelf") / 100) * enemyDB:More(nil, "CurseEffectOnSelf"), true)
					t_insert(dest, curse)
				end
			end
		end
	end
	local allyCurses = {}
	local allyPartyCurses = env.partyMembers["Curse"]
	if allyPartyCurses["Curse"] then
		allyCurses.limit = allyPartyCurses.limit
	else
		allyPartyCurses = { Curse = {} }
	end
	for curseName, curse in pairs(allyPartyCurses["Curse"]) do
		local newCurse = {
			name = curseName,
			priority = 0,
			modList = new("ModList"):ModList()
		}
		local mult = curse.effectMult / 100
		if curse.isMark then
			newCurse.isMark = true
		else
			mult = mult * enemyDB:More(nil, "CurseEffectOnSelf")
		end
		newCurse.modList:ScaleAddList(curse.modList, mult, true)
		t_insert(allyCurses, newCurse)
	end

	-- Set curse limit
	output.EnemyCurseLimit = modDB:Flag(nil, "CurseLimitIsMaximumPowerCharges") and output.PowerChargesMax or modDB:Sum("BASE", nil, "EnemyCurseLimit")
	output.EnemyMarkLimit = modDB:Sum("BASE", nil, "EnemyMarkLimit")
	curses.limit = output.EnemyCurseLimit + output.EnemyMarkLimit
	buffExports["CurseLimit"] = curses.limit
	-- Temp different mark and curse slots to handle limits and priorities of both
	local debuffSlots = { curseSlots = { }, markSlots = { } }
	for _, source in ipairs({curses, minionCurses, allyCurses}) do
		for _, curse in ipairs(source) do
			-- Calculate curses that ignore hex limit after
			if not curse.ignoreCurseLimit and not curse.socketedCursesHexLimit then
				local slot
				local skipAddingCurse = false
				-- Check if we need to disable a certain curse aura.
				for _, activeSkill in ipairs(env.player.activeSkillList) do
					if (activeSkill.buffList[1] and curse.name == activeSkill.buffList[1].name and activeSkill.skillTypes[SkillType.Aura]) then
						if modDB:Flag(nil, "SelfAurasOnlyAffectYou") then
							skipAddingCurse = true
						end
						break
					end
				end

				local currentSlots = curse.isMark and debuffSlots.markSlots or debuffSlots.curseSlots
				for i = 1, curse.isMark and output.EnemyMarkLimit or output.EnemyCurseLimit do
					if not currentSlots[i] then
						slot = i
						break
					elseif currentSlots[i].name == curse.name then
						if currentSlots[i].priority < curse.priority then
							slot = i
						else
							slot = nil
						end
						break
					else
						if currentSlots[i].priority < curse.priority then
							slot = i
						end
					end
				end
				if slot and not skipAddingCurse then
					currentSlots[slot] = curse
				end
			end
		end
	end

	-- Merge curse and mark slots as we now process curse ignoring hex limit
	curseSlots = tableConcat(debuffSlots.curseSlots, debuffSlots.markSlots)
	env.curseSlots = curseSlots

	for _, source in ipairs({curses, minionCurses}) do
		for _, curse in ipairs(source) do
			if curse.ignoreCurseLimit then
				local skipAddingCurse = false
				for i = 1, #curseSlots do
					if curseSlots[i].name == curse.name then
						-- if curse is higher priority, replace current curse with it, otherwise if same or lower priority skip it entirely
						if curseSlots[i].priority < curse.priority then
							curseSlots[i] = curse
						end
						skipAddingCurse = true
						break
					end
				end
				if not skipAddingCurse then
					curseSlots[#curseSlots + 1] = curse
				end
			end
			if curse.socketedCursesHexLimit then
				local socketedCursesHexLimitValue = modDB:Sum("BASE", nil, "SocketedCursesHexLimitValue")
				local skipAddingCurse = false
				for i = 1, #curseSlots do
					if curseSlots[i].name == curse.name then
						-- if curse is higher priority, replace current curse with it, otherwise if same or lower priority skip it entirely
						if curseSlots[i].priority < curse.priority then
							curseSlots[i] = curse
						end
						skipAddingCurse = true
						break
					end
					if i >= socketedCursesHexLimitValue then
						skipAddingCurse = true
					end
				end
				if not skipAddingCurse then
					curseSlots[#curseSlots + 1] = curse
				end
			end
		end
	end

	-- Process guard buffs
	local guardSlots = { }
	local nonVaal = false
	for name, modList in pairs(guards) do
		if name == "Vaal Molten Shell" then
			wipeTable(guardSlots)
			nonVaal = false
			t_insert(guardSlots, { name = name, modList = modList })
			break
		elseif name:match("^Vaal") then
			t_insert(guardSlots, { name = name, modList = modList })
		elseif not nonVaal then
			t_insert(guardSlots, { name = name, modList = modList })
			nonVaal = true
		end
	end
	if nonVaal then
		modDB.conditions["AffectedByNonVaalGuardSkill"] = true
	end
	for _, guard in ipairs(guardSlots) do
		modDB.conditions["AffectedByGuardSkill"] = true
		modDB.conditions["AffectedBy"..guard.name:gsub(" ","")] = true
		mergeBuff(guard.modList, buffs, guard.name)
	end

	-- Apply buff/debuff modifiers
	for _, modList in pairs(buffs) do
		modDB:AddList(modList)
		if not modList.notBuff then
			modDB.multipliers["BuffOnSelf"] = (modDB.multipliers["BuffOnSelf"] or 0) + 1
		end
		if env.minion then
			addMinionModifiers(modList, env.player.mainSkill.skillCfg, env.minion)
		end
	end
	if env.minion then
		for _, modList in pairs(minionBuffs) do
			env.minion.modDB:AddList(modList)
		end
	end
	for _, modList in pairs(debuffs) do
		enemyDB:AddList(modList)
	end
	local cursesInCurseSlots = {}
	for _, slot in ipairs(curseSlots) do
		if not slot.isMark then
			table.insert(cursesInCurseSlots, slot)
		end
	end
	modDB.multipliers["CurseOnEnemy"] = #cursesInCurseSlots
	for _, slot in ipairs(curseSlots) do
		enemyDB.conditions["Cursed"] = true
		if slot.isMark then
			enemyDB.conditions["Marked"] = true
		end
		if slot.modList then
			enemyDB:AddList(slot.modList)
		end
		if slot.buffModList then
			modDB:AddList(slot.buffModList)
		end
		if slot.minionBuffModList then
			env.minion.modDB:AddList(slot.minionBuffModList)
		end
	end

	-- Fix the configured impale stacks on the enemy
	-- 		If the config is missing (blank), then use the maximum number of stacks
	--		If the config is larger than the maximum number of stacks, replace it with the correct maximum
	local maxImpaleStacks = modDB:Sum("BASE", nil, "ImpaleStacksMax") * (1 + modDB:Sum("BASE", nil, "ImpaleAdditionalDurationChance") / 100)
	if not enemyDB:HasMod("BASE", nil, "Multiplier:ImpaleStacks") then
		enemyDB:NewMod("Multiplier:ImpaleStacks", "BASE", maxImpaleStacks, "Config", { type = "Condition", var = "Combat" })
	elseif enemyDB:Sum("BASE", nil, "Multiplier:ImpaleStacks") > maxImpaleStacks then
		enemyDB:ReplaceMod("Multiplier:ImpaleStacks", "BASE", maxImpaleStacks, "Config", { type = "Condition", var = "Combat" })
	end

	-- Check for extra auras
	buffExports["Aura"]["extraAura"] = { effectMult = 1, modList = new("ModList"):ModList() }
	for _, value in ipairs(modDB:List(nil, "ExtraAura")) do
		local modList = { value.mod }
		if not value.onlyAllies then
			local inc = modDB:Sum("INC", nil, "BuffEffectOnSelf", "AuraEffectOnSelf")
			local more = modDB:More(nil, "BuffEffectOnSelf", "AuraEffectOnSelf")
			modDB:ScaleAddList(modList, (1 + inc / 100) * more)
			if not value.notBuff then
				modDB.multipliers["BuffOnSelf"] = (modDB.multipliers["BuffOnSelf"] or 0) + 1
			end
		end
		if not modDB:Flag(nil, "SelfAurasCannotAffectAllies") then
			if env.minion and not env.minion.modDB:Flag(nil, "HiddenMonster") then
				local inc = env.minion.modDB:Sum("INC", nil, "BuffEffectOnSelf", "AuraEffectOnSelf")
				local more = env.minion.modDB:More(nil, "BuffEffectOnSelf", "AuraEffectOnSelf")
				env.minion.modDB:ScaleAddList(modList, (1 + inc / 100) * more)
			end
			buffExports["Aura"]["extraAura"].modList:AddMod(value.mod)
			local totemModBlacklist = value.mod.name and (value.mod.name == "Speed" or value.mod.name == "CritMultiplier" or value.mod.name == "CritChance")
			local totemFlag
			if env.mode == "CALCS" then
				totemFlag = env.player.mainSkill.activeEffect.statSetCalcs.skillFlags.totem
			else
				totemFlag = env.player.mainSkill.activeEffect.statSet.skillFlags.totem
			end
			if totemFlag and not totemModBlacklist then
				local totemMod = copyTable(value.mod)
				local totemModName, matches = totemMod.name:gsub("Condition:", "Condition:Totem")
				if matches < 1 then
					totemModName = "Totem" .. totemMod.name
				end
				totemMod.name = totemModName
				modDB:AddMod(totemMod)
			end
		end
	end
	if allyBuffs["extraAura"] then
		for _, buff in pairs(allyBuffs["extraAura"]) do
			local modList = buff.modList
			local inc = modDB:Sum("INC", nil, "BuffEffectOnSelf", "AuraEffectOnSelf")
			local more = modDB:More(nil, "BuffEffectOnSelf", "AuraEffectOnSelf")
			modDB:ScaleAddList(modList, (1 + inc / 100) * more)
			if env.minion and not env.minion.modDB:Flag(nil, "HiddenMonster") then
				local inc = env.minion.modDB:Sum("INC", nil, "BuffEffectOnSelf", "AuraEffectOnSelf")
				local more = env.minion.modDB:More(nil, "BuffEffectOnSelf", "AuraEffectOnSelf")
				env.minion.modDB:ScaleAddList(modList, (1 + inc / 100) * more)
			end
		end
	end

	-- Check for modifiers to apply to actors affected by player auras or curses
	for _, value in ipairs(modDB:List(nil, "AffectedByAuraMod")) do
		for actor in pairs(affectedByAura) do
			actor.modDB:AddMod(value.mod)
		end
	end

	-- Merge keystones again to catch any that were added by buffs
	mergeKeystones(env)

	-- Special handling for Dancing Dervish
	if modDB:Flag(nil, "DisableWeapons") then
		env.player.weaponData1 = copyTable(env.data.unarmedWeaponData[env.classId])
		modDB.conditions["Unarmed"] = true
		if not env.player.Gloves or env.player.Gloves == "None" then
			modDB.conditions["Unencumbered"] = true
		end
	elseif env.weaponModList1 then
		modDB:AddList(env.weaponModList1)
	end

	-- Process misc buffs/modifiers
	doActorCharges(env, env.player)
	doActorMisc(env, env.player)
	if env.minion then
		doActorCharges(env, env.minion)
		doActorMisc(env, env.minion)
	end

	-- Calculate maximum and apply the strongest non-damaging ailments
	local ailmentData = data.nonDamagingAilment
	local ailments = {
		["Chill"] = {
			condition = "Chilled",
			mods = function(num)
				local mods = {  }

				if modDB:Flag(nil, "ChillCanStack") then
					output["CurrentChill"] = num * m_min(enemyDB:Sum("BASE", nil, "Multiplier:ChillStacks"), modDB:Override(nil, "ChillStacksMax") or modDB:Sum("BASE", nil, "ChillStacksMax"))
					if breakdown then
						t_insert(mods, modLib.createMod("ActionSpeed", "INC", -num, "Chill Stacks", { type = "Condition", var = "Chilled" }, { type = "Multiplier", var = "ShockStacks", limit = modDB:Override(nil, "ShockStacksMax") or modDB:Sum("BASE", nil, "ShockStacksMax")}))
					end
				else
					t_insert(mods, modLib.createMod("ActionSpeed", "INC", -num, "Chill", { type = "Condition", var = "Chilled" }))
				end

				if output.HasBonechill and (hasGuaranteedBonechill or enemyDB:Sum("BASE", nil, "ChillVal") > 0) then
					t_insert(mods, modLib.createMod("ColdDamageTaken", "INC", num, "Bonechill", { type = "Condition", var = "Chilled" }))
				end
				if modDB:Flag(nil, "ChillEffectIncDamageTaken") then
					t_insert(mods, modLib.createMod("DamageTaken", "INC", num, "Asphyxia's Wrath", { type = "Condition", var = "Chilled" }))
				end
				return mods
			end
		},
		["Shock"] = {
			condition = "Shocked",
			mods = function(num)
				local mods = { }
				if modDB:Flag(nil, "ShockCanStack") then
					output.ShockStackCount = m_min(enemyDB:Sum("BASE", nil, "Multiplier:ShockStacks"), modDB:Override(nil, "ShockStacksMax") or modDB:Sum("BASE", nil, "ShockStacksMax"))
					t_insert(mods, modLib.createMod("DamageTaken", "INC", num, "Shock", { type = "Condition", var = "Shocked" }, { type = "Multiplier", var = "ShockStacks", limit = modDB:Override(nil, "ShockStacksMax") or modDB:Sum("BASE", nil, "ShockStacksMax")}))
					output["CurrentShock"] = num * m_min(enemyDB:Sum("BASE", nil, "Multiplier:ShockStacks"), modDB:Override(nil, "ShockStacksMax") or modDB:Sum("BASE", nil, "ShockStacksMax"))
					if breakdown then
						t_insert(mods, modLib.createMod("DamageTakenByShock", "INC", num, "Shock Stacks", { type = "Condition", var = "Shocked" }, { type = "Multiplier", var = "ShockStacks", limit = modDB:Override(nil, "ShockStacksMax") or modDB:Sum("BASE", nil, "ShockStacksMax")}))
					end
				else
					t_insert(mods, modLib.createMod("DamageTaken", "INC", num, "Shock", { type = "Condition", var = "Shocked" }))
				end
				return mods
			end
		},
	}

	-- precalculate life for rathpith Spells have 3% increased Magnitude of Ailments per 100 maximum
	-- Life cultivated mod
	calcs.doActorLifeManaSpirit(env.player, true)
	local hitFlag
	if env.mode == "CALCS" then
		hitFlag = env.player.mainSkill.activeEffect.statSetCalcs.skillFlags.hit
	else
		hitFlag = env.player.mainSkill.activeEffect.statSet.skillFlags.hit
	end
	for ailment, val in pairs(ailments) do
		if (enemyDB:Sum("BASE", nil, ailment.."Val") > 0
		or modDB:Sum("BASE", nil, ailment.."Base", ailment.."Override", ailment.."Minimum"))
		and not enemyDB:Flag(nil, "Condition:Already"..val.condition) then
			local override = 0
			local minimum = 0
			for _, value in ipairs(modDB:Tabulate("BASE", nil, ailment.."Base", ailment.."Override", ailment.."Minimum")) do
				local mod = value.mod
				local effect = mod.value
				if mod.name == ailment.."Override" then
					enemyDB:NewMod("Condition:"..val.condition, "FLAG", true, mod.source)
				end
				if mod.name == ailment.."Base" or mod.name == ailment.."Minimum" then
					-- If the main skill can inflict the ailment, the ailment is inflicted with a hit, and we have a node allocated that checks what our highest damage is, then
					-- use the skill's ailment modifiers
					-- if not, use the generic modifiers
					-- Scorch/Sap/Brittle do not have guaranteed sources from hits, and therefore will only end up in this bit of code if it's not supposed to apply the skillModList, which is bad
					if ailment ~= "Scorch" and ailment ~= "Sap" and ailment ~= "Brittle" and not env.player.mainSkill.skillModList:Flag(nil, "Cannot"..ailment) and hitFlag and modDB:Flag(nil, "ChecksHighestDamage") then
						effect = effect * calcLib.mod(env.player.mainSkill.skillModList, env.player.mainSkill.skillCfg, "Enemy" .. ailment .. "Magnitude", "AilmentMagnitude") * calcLib.mod(enemyDB, nil, "Self" .. ailment .. "Magnitude", "AilmentMagnitude")
					else
						effect = effect * calcLib.mod(env.player.mainSkill.skillModList, env.player.mainSkill.skillCfg, "Enemy" .. ailment .. "Magnitude", "AilmentMagnitude") * calcLib.mod(enemyDB, nil, "Self" .. ailment .. "Magnitude", "AilmentMagnitude")
					end
					modDB:NewMod(ailment.."Override", "BASE", effect, mod.source, mod.flags, mod.keywordFlags, unpack(mod))
					if mod.name == ailment.."Minimum" then
						minimum = minimum + effect
					end
				end
				override = m_max(m_max(override, effect or 0), minimum)
			end
			local maxAilment = modDB:Override(nil, ailment.."Max") or 0
			if not modDB:Override(nil, ailment.."Max") then
				for _, skill in ipairs(env.player.activeSkillList) do
					local skillMax = modDB:Override(nil, ailment.."Max") or (ailmentData[ailment].max + skill.baseSkillModList:Sum("BASE", nil, ailment.."Max"))
					maxAilment = skillMax > maxAilment and skillMax or maxAilment
				end
			end
			output["Maximum"..ailment] = maxAilment
			output["Current"..ailment] = m_floor(m_min(m_max(override, enemyDB:Sum("BASE", nil, ailment.."Val")), output["Maximum"..ailment]) * (10 ^ ailmentData[ailment].precision)) / (10 ^ ailmentData[ailment].precision)
			for _, mod in ipairs(val.mods(output["Current"..ailment])) do
				enemyDB:AddMod(mod)
			end
			enemyDB:NewMod("Condition:Already"..val.condition, "FLAG", true, { type = "Condition", var = val.condition } ) -- Prevents ailment from applying doubly for minions
		end
	end

	-- Update chill and shock multipliers
	local chillEffectMultiplier = enemyDB:Sum("BASE", nil, "Multiplier:ChillEffect")
	if chillEffectMultiplier < output["CurrentChill"] then
		enemyDB:NewMod("Multiplier:ChillEffect", "BASE", output["CurrentChill"] - chillEffectMultiplier, "")
	end
	local shockEffectMultiplier = enemyDB:Sum("BASE", nil, "Multiplier:ShockEffect")
	if shockEffectMultiplier < output["CurrentShock"] then
		enemyDB:NewMod("Multiplier:ShockEffect", "BASE", output["CurrentShock"] - shockEffectMultiplier, "")
	end

	doActorCharges(env, env.enemy)
	doActorMisc(env, env.enemy)

	-- Handle consecrated ground effects on enemies
	if enemyDB:Flag(nil, "Condition:OnConsecratedGround") then
		local effect = 1 + modDB:Sum("INC", nil, "ConsecratedGroundEffect") / 100
		enemyDB:NewMod("DamageTaken", "INC", enemyDB:Sum("INC", nil, "DamageTakenConsecratedGround") * effect, "Consecrated Ground")
	end

	local function calcMinionLifePool(env, buffs, includeSkill)
		local totalLife = 0
		local lifeList = { }
		local seenMinions = { }
		for _, activeSkill in ipairs(env.player.activeSkillList) do
			local skillFlags = env.mode == "CALCS" and activeSkill.activeEffect.statSetCalcs.skillFlags or activeSkill.activeEffect.statSet.skillFlags
			local minion = activeSkill.minion
			if minion and not seenMinions[minion] and not skillFlags.disable and includeSkill(activeSkill, skillFlags) then
				seenMinions[minion] = true
				if minion ~= env.minion then
					minion.output = minion.output or { }
					initMinionModDB(env, activeSkill)
					addMinionModifiers(activeSkill.skillModList, activeSkill.skillCfg, minion)
					for _, name in ipairs(minion.modDB:List(nil, "Keystone")) do
						if env.spec.tree.keystoneMap[name] then
							minion.modDB:AddList(env.spec.tree.keystoneMap[name].modList)
						end
					end
					for _, modList in pairs(buffs) do
						addMinionModifiers(modList, activeSkill.skillCfg, minion)
					end
					doActorAttribsConditions(env, minion)
				end
				calcs.doActorLifeManaSpirit(minion, true)
				totalLife = totalLife + minion.output.Life
				t_insert(lifeList, { name = minion.minionData and minion.minionData.name or activeSkill.activeEffect.grantedEffect.name, life = minion.output.Life })
			end
		end
		return totalLife, lifeList
	end

	-- Total life of spectres, for "% of Damage from Hits is taken from your Spectres' Life before you"
	if modDB:HasMod("BASE", nil, "TakenFromSpectresBeforeYou") and not modDB:Override(nil, "TotalSpectreLife") then
		local totalSpectreLife, spectreLifeList = calcMinionLifePool(env, buffs, function(activeSkill, skillFlags)
			return skillFlags.spectre and not activeSkill.skillTypes[SkillType.MinionsAreUndamagable]
		end)
		modDB:NewMod("TotalSpectreLife", "BASE", totalSpectreLife, "Spectres")
		env.player.spectreLifeList = spectreLifeList
	end

	-- Total life of damageable companions, for "% of Damage from Hits is taken from your Companion's Life before you"
	if modDB:HasMod("BASE", nil, "TakenFromCompanionBeforeYou", "TakenFromCompanionBeforeYouFromDeflected") and not modDB:Override(nil, "TotalCompanionLife") then
		local totalCompanionLife, companionLifeList = calcMinionLifePool(env, buffs, function(activeSkill)
			return activeSkill.skillTypes[SkillType.Companion] and not activeSkill.skillTypes[SkillType.MinionsAreUndamagable]
		end)
		modDB:NewMod("TotalCompanionLife", "BASE", totalCompanionLife, "Companions")
		env.player.companionLifeList = companionLifeList
	end

	if enemyDB:Flag(env.player.mainSkill.skillCfg, "AbyssalWasted") then
		local effect = 1 + modDB:Sum("INC", nil, "AbyssalWastingEffect") / 100
		local mods = modDB:List(nil, "AbyssalWastingAlsoGrants")
		for _, v in ipairs(mods) do
			local mod = copyTable(v.mod)
			if not v.unscalable then
				mod.value = m_modf(round(mod.value * effect, 2))
			end
			if v.applyToEnemy then
				enemyDB:AddMod(mod)
			else
				modDB:AddMod(mod)
			end
		end
	end
	-- Defence/offence calculations
	calcs.defence(env, env.player)
	local function getSkillExposureEffect(source, element)
		local effect = 0
		for _, activeSkill in ipairs(env.player.activeSkillList) do
			if source == "Config" then
				-- Config exposure is a generic 20% exposure, so use any active skill that can apply this exposure as the source for skill-specific exposure effect.
				if activeSkill.skillModList:HasMod("BASE", activeSkill.skillCfg, element.."ExposureChance") or activeSkill.skillModList:HasMod("FLAG", activeSkill.skillCfg, "InflictExposure") then
					effect = m_max(effect, activeSkill.skillModList:Sum("INC", { source = "Skill" }, element.."ExposureEffect"))
				end
			else
				-- Direct skill exposure keeps the source from the active/support skill that created the exposure mod.
				for _, skillEffect in ipairs(activeSkill.effectList or { }) do
					if skillEffect.grantedEffect.modSource == source then
						effect = m_max(effect, activeSkill.skillModList:Sum("INC", { source = "Skill" }, element.."ExposureEffect"))
						break
					end
				end
			end
		end
		return effect
	end

	for _, element in ipairs({ "Fire", "Cold", "Lightning" }) do
		if not modDB:Flag(nil, "ElementalEquilibrium") -- if Elemental Equilibrium isn't active we just process Exposure normally
			or element == "Fire" and not enemyDB:Flag(nil, "Condition:HitByFireDamage")
			or element == "Cold" and not enemyDB:Flag(nil, "Condition:HitByColdDamage")
			or element == "Lightning" and not enemyDB:Flag(nil, "Condition:HitByLightningDamage") then
			local magnitude = 0
			local source = ""
			local extraExposure = modDB:Sum("BASE", nil, "ExtraExposure", "Extra"..element.."Exposure")
			local globalExposureEffect = modDB:Sum("INC", nil, element.."ExposureEffect")
			local exposureEffectOnSelf = enemyDB:More(nil, "ExposureEffectOnSelf")
			for _, mod in ipairs(enemyDB:Tabulate("BASE", nil, element .. "Exposure")) do
				local skillExposureEffect = getSkillExposureEffect(mod.mod.source, element)
				-- Resolve each exposure source independently so skill-specific effect only scales the exposure from that skill.
				local value = mod.value
				value = m_floor((value + extraExposure) * ((globalExposureEffect + skillExposureEffect) / 100 + 1) * exposureEffectOnSelf)
				if value > magnitude then
					magnitude = value
					source = mod.mod.source
				end
			end
			if magnitude > 0 then
				local exposureMin = modDB:Override(nil, "ExposureMin")
				if exposureMin then
					magnitude = m_max(magnitude, exposureMin)
				end
				enemyDB:NewMod("Condition:Has"..element.."Exposure", "FLAG", true, "")
				enemyDB:NewMod("Condition:HasExposure", "FLAG", true, "")
				enemyDB:NewMod(element.."Resist", "BASE", -magnitude, source)
				modDB:NewMod("Condition:AppliedExposureRecently", "FLAG", true, "")
			end
		end
	end
	if not skipEHP then
		calcs.buildDefenceEstimations(env, env.player)
	end

	-- TURNING OFF CALC TRIGGERS AND MIRAGES FOR TIME BEING
	--calcs.triggers(env, env.player)
	--if not calcs.mirages(env) then
		calcs.offence(env, env.player, env.player.mainSkill)
	--end

	if env.minion then
		calcs.defence(env, env.minion)
		if not skipEHP then -- main.build.calcsTab.input.showMinion and -- should be disabled unless "calcsTab.input.showMinion" is true
			calcs.buildDefenceEstimations(env, env.minion)
		end
		calcs.triggers(env, env.minion)
		calcs.offence(env, env.minion, env.minion.mainSkill)
	end

	 -- Export modifiers to enemy conditions and stats for party tab
	if partyTabEnableExportBuffs then
        for k, mod in pairs(enemyDB.mods) do
            if k:find("Condition") and not k:find("Party") then
                buffExports["EnemyConditions"][k] = true
            elseif (k:find("Resist") and not k:find("Totem") and not k:find("Max")) or k:find("Damage") or k:find("ActionSpeed") or k:find("SelfCrit") or (k:find("Multiplier") and not k:find("Max") and not k:find("Impale")) then
                for _, v in ipairs(mod) do
                    if not v.party and v.value ~= 0 and v.source ~= "EnemyConfig" and v.source ~= "Base" and not v.source:find("Delirious") and not v.source:find("^Party") then
						local skipValue = false
						for _, tag in ipairs(v) do
							if tag.effectType == "Curse" or tag.effectType == "AuraDebuff" then
								skipValue = true
								break
							end
						end
                        if not skipValue and (not v[1] or (
								(v[1].type ~= "Condition" or (v[1].var and (enemyDB.mods["Condition:"..v[1].var] and enemyDB.mods["Condition:"..v[1].var][1].value) or v[1].varList and (enemyDB.mods["Condition:"..v[1].varList[1]] and enemyDB.mods["Condition:"..v[1].varList[1]][1].value)))
								and (v[1].type ~= "Multiplier" or (enemyDB.mods["Multiplier:"..v[1].var] and enemyDB.mods["Multiplier:"..v[1].var][1].value)))) then
                            if buffExports["EnemyMods"][k] then
								if not buffExports["EnemyMods"][k].MultiStat then
									buffExports["EnemyMods"][k] = { MultiStat = true, buffExports["EnemyMods"][k] }
								end
								t_insert(buffExports["EnemyMods"][k], v)
							else
								buffExports["EnemyMods"][k] = v
							end
                        end
                    end
                end
            end
        end

		for _, damageType in ipairs({"Physical", "Lightning", "Cold", "Fire", "Chaos"}) do
			if env.modDB:Flag(nil, "Enemy"..damageType.."ResistEqualToYours") and output[damageType.."Resist"] then
				buffExports.PlayerMods["Enemy"..damageType.."ResistEqualToYours"] = true
				buffExports.PlayerMods[damageType.."Resist="..tostring(output[damageType.."Resist"])] = true
			end
		end
		if env.modDB:Flag(nil, "PartyMemberMaximumEnduranceChargesEqualToYours") and output["EnduranceChargesMax"] then
			buffExports.PlayerMods["PartyMemberMaximumEnduranceChargesEqualToYours"] = true
			buffExports.PlayerMods["EnduranceChargesMax="..tostring(output["EnduranceChargesMax"])] = true
		end

		buffExports.PlayerMods["MovementSpeedMod|percent|max="..tostring(output["MovementSpeedMod"] * 100)] = true

		for _, mod in ipairs(buffExports["Aura"]["extraAura"].modList) do
			-- leaving comment to make it easier for future similar mods
			--if mod.name:match("Parent") then
			--	ConPrintTable(mod)
			--end
			if mod.name == "YourFortifyEqualToParent" then
				buffExports.PlayerMods["PartyMemberFortifyEqualToYours"] = true
				buffExports.PlayerMods["FortificationStacks="..tostring(output.FortificationStacks or 0)] = true
			end
		end

		-- preStack Mine auras
		for auraName, aura in pairs(buffExports["Aura"]) do
			if auraName:match("Mine") and not auraName:match(" Limit") then
				buffExports["Aura"][auraName] = copyTable(buffExports["Aura"][auraName])
				aura = buffExports["Aura"][auraName]
				local stackCount = buffExports["EnemyMods"]["Multiplier:"..auraName.."Stack"] and buffExports["EnemyMods"]["Multiplier:"..auraName.."Stack"].value or 0
				buffExports["EnemyMods"]["Multiplier:"..auraName.."Stack"] = nil
				if stackCount == 0 then
					buffExports["Aura"][auraName] = nil
				else
					for _, mod in ipairs(aura.modList) do
						for _, tag in ipairs(mod) do
							if (tag.effectStackVar or "") == "ActiveMineCount" then
								tag.effectStackVar = nil
								mod.value = mod.value * stackCount
								break
							end
						end
					end
				end
				if buffExports["Aura"][auraName.." Limit"] then
					buffExports["Aura"][auraName.." Limit"] = copyTable(buffExports["Aura"][auraName.." Limit"])
					aura = buffExports["Aura"][auraName.." Limit"]
					if stackCount == 0 then
						buffExports["Aura"][auraName.." Limit"] = nil
					else
						for _, mod in ipairs(aura.modList) do
							for _, tag in ipairs(mod) do
								if (tag.effectStackVar or "") == "ActiveMineCount" then
									tag.effectStackVar = nil
									mod.value = mod.value * stackCount
									break
								end
							end
						end
					end
				end
			end
		end

		for linkName, link in pairs(buffExports["Link"]) do
			if linkName == "Flame Link" then
				buffExports.PlayerMods["Life="..tostring(output["Life"])] = true
			end
			for _, mod in ipairs(link.modList) do
				if mod.name:match("Parent") then
					if mod.name == "MaximumBlockAttackChanceIsEqualToParent" then
						buffExports.PlayerMods["BlockChanceMax="..tostring(output["BlockChanceMax"])] = true
					elseif mod.name == "BlockAttackChanceIsEqualToParent" then
						buffExports.PlayerMods["BlockChance="..tostring(output["BlockChance"])] = true
					elseif mod.name == "MaximumLifeLeechIsEqualToPartyMember" then
						buffExports.PlayerMods["MaxLifeLeechRatePercent="..tostring(output["MaxLifeLeechRatePercent"])] = true
					elseif mod.name == "TakenFromParentESBeforeYou" then
						buffExports.PlayerMods["EnergyShieldRecoveryCap="..tostring(output["EnergyShieldRecoveryCap"])] = true
					elseif mod.name == "MainHandCritIsEqualToParent" then
						if output.MainHand then
							buffExports.PlayerMods["MainHand.CritChance="..tostring(output["MainHand"]["CritChance"])] = true
						elseif env.player.weaponData1 then
							buffExports.PlayerMods["MainHand.CritChance="..tostring(env.player.weaponData1.CritChance)] = true
						end
					end
				end
			end
		end
		env.build.partyTab:setBuffExports(buffExports)
	end

	-- calculate Gem Level of MainSkill
	if env.player.mainSkill then
		local mainSkill = env.player.mainSkill
		if mainSkill.activeEffect and mainSkill.activeEffect.level and mainSkill.activeEffect.srcInstance then
			local baseLevel = mainSkill.skillModList:Sum("BASE", mainSkill.skillCfg, "GemLevel")
			local totalItemLevel = mainSkill.skillModList:Sum("BASE", mainSkill.skillCfg, "GemItemLevel")
			local totalSupportLevel = mainSkill.skillModList:Sum("BASE", mainSkill.skillCfg, "GemSupportLevel")
			local totalCorruptionLevel = mainSkill.skillModList:Sum("BASE", mainSkill.skillCfg, "GemCorruptionLevel")

			output.GemHasLevel = true
			output.GemLevel = m_max(baseLevel + totalSupportLevel + totalItemLevel + totalCorruptionLevel, 1)

			if env.player.breakdown then
				env.player.breakdown.GemLevel = {}
				t_insert(env.player.breakdown.GemLevel, s_format("%d ^8(level from gem)", baseLevel))
				if totalSupportLevel > 0 then
					t_insert(env.player.breakdown.GemLevel, s_format("+ %d ^8(level from support)", totalSupportLevel))
				end
				if totalItemLevel > 0 then
					t_insert(env.player.breakdown.GemLevel, s_format("+ %d ^8(level from items)", totalItemLevel))
				end
				if totalCorruptionLevel > 0 then
					t_insert(env.player.breakdown.GemLevel, s_format("+ %d ^8(level from corruption)", totalCorruptionLevel))
				elseif totalCorruptionLevel < 0 then
					t_insert(env.player.breakdown.GemLevel, s_format("%d ^8(level from corruption)", totalCorruptionLevel))
				end
				t_insert(env.player.breakdown.GemLevel, s_format("= %d", output.GemLevel))
			end
		end
	end

	-- check for warnings to add
	for gemName, gemInfo in pairs(GlobalGemAssignments) do
		if gemName == "GemGroupCount" then
			local allowedGemGroups = env.modDB:Sum("BASE", nil, "SkillSlots")
			if gemInfo > allowedGemGroups then
				env.itemWarnings.gemGroupCountWarning = env.itemWarnings.gemGroupCountWarning or { }
				t_insert(env.itemWarnings.gemGroupCountWarning, { allowedGemGroups, gemInfo })
			end
		else
			local maxLineageCount = modDB:Sum("BASE", nil, "MaxLineageCount")
			if gemInfo.support and gemInfo.lineage and gemInfo.count > maxLineageCount then
				env.itemWarnings.lineageSupportGemLimitWarning = env.itemWarnings.lineageSupportGemLimitWarning or { }
				t_insert(env.itemWarnings.lineageSupportGemLimitWarning, { gemName, maxLineageCount, gemInfo.groups })
			end
		end
	end

	-- Cache skill data
	cacheData(cacheSkillUUID(env.player.mainSkill, env), env)
end

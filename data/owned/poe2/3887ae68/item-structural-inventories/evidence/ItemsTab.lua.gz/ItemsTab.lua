-- Path of Building
--
-- Module: Items Tab
-- Items tab for the current build.
--
local pairs = pairs
local ipairs = ipairs
local next = next
local t_insert = table.insert
local t_remove = table.remove
local s_format = string.format
local m_max = math.max
local m_min = math.min
local m_ceil = math.ceil
local m_floor = math.floor
local m_modf = math.modf
local buySimilar = LoadModule("Classes/CompareBuySimilar")

local gemTooltip = LoadModule("Classes/GemTooltip")
local rarityDropList = {
	{ label = colorCodes.NORMAL.."Normal", rarity = "NORMAL" },
	{ label = colorCodes.MAGIC.."Magic", rarity = "MAGIC" },
	{ label = colorCodes.RARE.."Rare", rarity = "RARE" },
	{ label = colorCodes.UNIQUE.."Unique", rarity = "UNIQUE" },
	{ label = colorCodes.RELIC.."Relic", rarity = "RELIC" }
}

local socketDropList = {
	{ label = colorCodes.SCION.."S", color = "W" }
}

local baseSlots = { "Weapon 1", "Weapon 2", "Helmet", "Body Armour", "Gloves", "Boots", "Amulet", "Ring 1", "Ring 2", "Ring 3","Belt", "Charm 1", "Charm 2", "Charm 3", "Flask 1", "Flask 2", "Arm 1", "Arm 2", "Leg 1", "Leg 2" }

local characterRuneSlotList = {
	{ "Helmet Rune #1", "helmet", "Helmet Rune 1" },
	{ "Body Armour Rune #1", "body armour", "Body Rune 1" },
	{ "Body Armour Rune #2", "body armour", "Body Rune 2" },
	{ "Gloves Rune #1", "gloves", "Gloves Rune 1" },
	{ "Boots Rune #1", "boots", "Boots Rune 1" },
}

local runeModLines

local catalystQualityFormat = {
	"^x7F7F7FQuality (Life Modifiers): "..colorCodes.MAGIC.."+%d%% (augmented)",
	"^x7F7F7FQuality (Mana Modifiers): "..colorCodes.MAGIC.."+%d%% (augmented)",
	"^x7F7F7FQuality (Defence Modifiers): "..colorCodes.MAGIC.."+%d%% (augmented)",
	"^x7F7F7FQuality (Physical): "..colorCodes.MAGIC.."+%d%% (augmented)",
	"^x7F7F7FQuality (Fire Modifiers): "..colorCodes.MAGIC.."+%d%% (augmented)",
	"^x7F7F7FQuality (Cold Modifiers): "..colorCodes.MAGIC.."+%d%% (augmented)",
	"^x7F7F7FQuality (Lightning Modifiers): "..colorCodes.MAGIC.."+%d%% (augmented)",
	"^x7F7F7FQuality (Chaos Modifiers): "..colorCodes.MAGIC.."+%d%% (augmented)",
	"^x7F7F7FQuality (Attack Modifiers): "..colorCodes.MAGIC.."+%d%% (augmented)",
	"^x7F7F7FQuality (Caster Modifiers): "..colorCodes.MAGIC.."+%d%% (augmented)",
	"^x7F7F7FQuality (Speed Modifiers): "..colorCodes.MAGIC.."+%d%% (augmented)",
	"^x7F7F7FQuality (Attribute Modifiers): "..colorCodes.MAGIC.."+%d%% (augmented)",
	"^x7F7F7FQuality (Minion Modifiers): "..colorCodes.MAGIC.."+%d%% (augmented)",
}

local flavourLookup = {}

for _, entry in pairs(data.flavourText) do
    if entry.name and entry.id and entry.text then
        flavourLookup[entry.name] = flavourLookup[entry.name] or {}
        flavourLookup[entry.name][entry.id] = {
            text = entry.text,
            origin = entry.origin
        }
    end
end

local function isAnointable(item)
	return (item.canBeAnointed or item.base.type == "Amulet")
		-- and not item.sanctified and not item.corrupted and not item.mirrored
end

local function hasAugmentSockets(item)
	return item and item.itemSocketCount > 0
end

local function canHaveAugmentSockets(item)
	return item and ((item.base.socketLimit and item.base.socketLimit > 0) or item.socketedAugmentTypeOverride ~= nil or hasAugmentSockets(item))
end

local function buildModSortList()
	local sortList = { { label = "Default", stat = nil } }
	for _, entry in ipairs(data.powerStatList) do
		if entry.stat and not entry.ignoreForItems then
			t_insert(sortList, entry)
		end
	end
	return sortList
end

local function setDefaultSortOrder(modList)
	for index, listMod in ipairs(modList) do
		listMod.defaultSortOrder = index
		listMod.sortValue = nil
		listMod.sortValues = nil
	end
end

local function getSortedModValue(item, listMod, sortOption, calcFunc, slotName, addModToItem)
	local stat = sortOption.stat
	listMod.sortValues = listMod.sortValues or { }
	if listMod.sortValues[stat] ~= nil then
		return listMod.sortValues[stat]
	end
	local testItem = new("Item"):Item(item:BuildRaw())
	testItem.id = item.id
	addModToItem(testItem, listMod)
	testItem:BuildAndParseRaw()
	local output = calcFunc({ repSlotName = slotName, repItem = testItem }, stat == "FullDPS")
	local value = data.powerStatList.GetFromOutput(output, sortOption)
	listMod.sortValues[stat] = value
	return value
end

local function sortModList(modList, stat, getSortValue)
	if stat then
		for _, listMod in ipairs(modList) do
			listMod.sortValue = getSortValue(listMod)
		end
		table.sort(modList, function(a, b)
			if a.sortValue ~= b.sortValue then
				return a.sortValue > b.sortValue
			end
			return (a.defaultSortOrder or 0) < (b.defaultSortOrder or 0)
		end)
	else
		table.sort(modList, function(a, b)
			return (a.defaultSortOrder or 0) < (b.defaultSortOrder or 0)
		end)
	end
end

---@class ItemsTab: UndoHandler, ControlHost, Control
local ItemsTabClass = newClass("ItemsTab", "UndoHandler", "ControlHost", "Control")

function ItemsTabClass:ItemsTab(build)
	self:UndoHandler()
	self:ControlHost()
	self:Control()

	self.build = build

	self.socketViewer = new("PassiveTreeView"):PassiveTreeView()

	self.items = { }
	self.itemOrderList = { }

	self.showStatDifferences = true

	-- PoB Trader class initialization
	self.tradeQuery = new("TradeQuery"):TradeQuery(self)

	-- x offset for all of the left side item tab controls since they are
	-- anchored to one another from top to bottom
	local selectorsXOffset = 109
	-- Set selector
	self.controls.setSelect = new("DropDownControl"):DropDownControl({ "TOPLEFT", self, "TOPLEFT" }, { selectorsXOffset, 8, 216, 20 }, nil, function(index, value)
		self:SetActiveItemSet(self.itemSetOrderList[index])
		self:AddUndoState()
	end)
	self.controls.setSelect.enableDroppedWidth = true
	self.controls.setSelect.enabled = function()
		return #self.itemSetOrderList > 1
	end
	self.controls.setSelect.tooltipFunc = function(tooltip, mode, index, value)
		tooltip:Clear()
		if mode == "HOVER" then
			self:AddItemSetTooltip(tooltip, self.itemSets[self.itemSetOrderList[index]])
		end
	end
	self.controls.setLabel = new("LabelControl"):LabelControl({ "RIGHT", self.controls.setSelect, "LEFT" }, { -2, 0, 0, 16 }, "^7Item set:")
	self.controls.setManage = new("ButtonControl"):ButtonControl({ "LEFT", self.controls.setSelect, "RIGHT" }, { 4, 0, 90, 20 }, "Manage...", function()
		self:OpenItemSetManagePopup()
	end)

	-- Price Items
	self.controls.priceDisplayItem = new("ButtonControl"):ButtonControl({ "TOPLEFT", self, "TOPLEFT" }, { selectorsXOffset, 32, 310, 20 }, "Trade for these items", function()
		self.tradeQuery:PriceItem()
	end)
	self.controls.priceDisplayItem.tooltipFunc = function(tooltip)
		tooltip:Clear()
		tooltip:AddLine(16, "^7Contains searches from the official trading site to help find")
		tooltip:AddLine(16, "^7similar or better items for this build")
	end

	-- Runes that fit Martial Artist slots and have global effects.
	local runeList = { helmet = {}, ["body armour"] = {}, gloves = {}, boots = {} }
	for slotType, list in pairs(runeList) do
		t_insert(list, runeModLines[1])
		for _, rune in ipairs(runeModLines) do
			if rune.canSocketInChakraSlots and not rune.isSocketBound and (rune.slot == slotType or rune.slot == "armour") then
				t_insert(list, rune)
			end
		end
	end

	-- Item slots
	self.slots = { }
	self.orderedSlots = { }
	self.slotOrder = { }
	self.runeSlots = { }
	self.runeSlotOrder = { }
	self.initSockets = true
	self.slotAnchor = new("Control"):Control({ "TOPLEFT", self, "TOPLEFT" }, { selectorsXOffset, 76, 310, 0 })
	local prevSlot = self.slotAnchor
	local function addSlot(slot)
		prevSlot = slot
		self.slots[slot.slotName] = slot
		t_insert(self.orderedSlots, slot)
		self.slotOrder[slot.slotName] = #self.orderedSlots
		t_insert(self.controls, slot)
	end
	local function addJewelSockets(parentSlot, shownFunc)
		for i = 1, 6 do
			local jewel = new("ItemSlotControl"):ItemSlotControl({ "TOPLEFT", prevSlot, "BOTTOMLEFT" }, 0, 2, self, parentSlot.slotName .. " Jewel Socket " .. i, "Jewel #" .. i)
			addSlot(jewel)
			jewel.parentSlot = parentSlot
			jewel.weaponSet = parentSlot.weaponSet
			jewel.shown = function()
				return not jewel.inactive and shownFunc()
			end
			parentSlot.jewelSocketList[i] = jewel
		end
	end
	for index, slotName in ipairs(baseSlots) do
		local slot = new("ItemSlotControl"):ItemSlotControl({ "TOPLEFT", prevSlot, "BOTTOMLEFT" }, 0, 2, self, slotName)
		addSlot(slot)
		local swapSlot
		if slotName:match("Weapon") then
			-- Add alternate weapon slot
			slot.weaponSet = 1
			slot.shown = function()
				return not self.activeItemSet.useSecondWeaponSet
			end
			swapSlot = new("ItemSlotControl"):ItemSlotControl({ "TOPLEFT", prevSlot, "BOTTOMLEFT" }, 0, 2, self, slotName .. " Swap", slotName)
			addSlot(swapSlot)
			swapSlot.weaponSet = 2
			swapSlot.shown = function()
				return self.activeItemSet.useSecondWeaponSet
			end
		elseif slotName == "Ring 3" then
			slot.shown = function()
				return self.build.calcsTab.mainEnv.modDB:Flag(nil, "AdditionalRingSlot")
			end
		end
		if slotName == "Weapon 1" or slotName == "Weapon 2" or slotName == "Helmet" or slotName == "Gloves" or slotName == "Body Armour" or slotName == "Boots" or slotName == "Belt" or slotName == "Ring 1" or slotName == "Ring 2" or slotName == "Ring 3" then
			-- Add Jewel Socket slots
			if slotName:match("Weapon") then
				addJewelSockets(slot, function()
					return not self.activeItemSet.useSecondWeaponSet
				end)
				addJewelSockets(swapSlot, function()
					return self.activeItemSet.useSecondWeaponSet
				end)
			else
				addJewelSockets(slot, function()
					return slot.shown()
				end)
			end
		end
	end

	for _, runeSlotData in ipairs(characterRuneSlotList) do
		local slotName, slotType, label = unpack(runeSlotData)
		local runeSlot = new("DropDownControl"):DropDownControl({ "TOPLEFT", prevSlot, "BOTTOMLEFT" }, { 0, 2, 310, 20 }, runeList[slotType], function(_, value)
			self.activeItemSet[slotName].runeName = value.name
			self:AddUndoState()
			self.build.buildFlag = true
		end)
		runeSlot.anchor.collapse = true
		local outputCache = { }
		local outputCacheRevision
		runeSlot.tooltipFunc = function(tooltip, mode, index, rune)
			if tooltip:CheckForUpdate(rune, self.build.outputRevision) and rune.name ~= "None" then
				tooltip:AddLine(16, "^7" .. rune.name)
				if rune.limit then
					tooltip:AddLine(14, "^7" .. s_format("Limited to: %d", rune.limit))
				end
				if rune.req > 1 then
					tooltip:AddLine(14, "^7" .. s_format("Requires: Level %d", rune.req))
				end
				for _, line in ipairs(rune.lines) do
					if not line:match("^Bonded:") then
						tooltip:AddLine(14, colorCodes.MAGIC .. line)
					end
				end
				if rune ~= runeSlot:GetSelValue() then
					if outputCacheRevision ~= self.build.outputRevision then
						outputCache = { }
						outputCacheRevision = self.build.outputRevision
					end
					local calcFunc, outputBase = self.build.calcsTab:GetMiscCalculator()
					outputCache[rune] = outputCache[rune] or calcFunc({ repSlotName = slotName, repRune = rune })
					self.build:AddStatComparesToTooltip(tooltip, outputBase, outputCache[rune], "\n^7Adding this mod will give: ")
				end
			end
		end
		self.controls[slotName .. " Label"] = new("LabelControl"):LabelControl({ "RIGHT", runeSlot, "LEFT" }, { -2, 0, 16, 16 }, s_format("^7%s:", label))
		prevSlot = runeSlot
		t_insert(self.controls, runeSlot)
		self.runeSlots[slotName] = runeSlot
		t_insert(self.runeSlotOrder, slotName)
		runeSlot.shown = function()
			return self.build.calcsTab.mainEnv.modDB:Flag(nil, "SocketRunesOnCharacter")
		end
	end

	-- Passive tree dropdown controls
	self.controls.specSelect = new("DropDownControl"):DropDownControl({ "TOPLEFT", prevSlot, "BOTTOMLEFT" }, { 0, 8, 216, 20 }, nil, function(index, value)
		if self.build.treeTab.specList[index] then
			self.build.modFlag = true
			self.build.treeTab:SetActiveSpec(index)
		end
	end)
	self.controls.specSelect.anchor.collapse = true
	self.controls.specSelect.enabled = function()
		return #self.controls.specSelect.list > 1
	end
	prevSlot = self.controls.specSelect
	self.controls.specButton = new("ButtonControl"):ButtonControl({ "LEFT", prevSlot, "RIGHT" }, { 4, 0, 90, 20 }, "Manage...", function()
		self.build.treeTab:OpenSpecManagePopup()
	end)
	self.controls.specButton.anchor.collapse = true
	self.controls.specLabel = new("LabelControl"):LabelControl({ "RIGHT", prevSlot, "LEFT" }, { -2, 0, 0, 16 }, "^7Passive tree:")
	self.controls.specLabel.anchor.collapse = true

	self.sockets = { }
	local socketOrder = { }
	for _, node in pairs(build.latestTree.nodes) do
		if node.type == "Socket" or node.containJewelSocket then
			t_insert(socketOrder, node)
		end
	end
	table.sort(socketOrder, function(a, b)
		return a.id < b.id
	end)
	for _, node in ipairs(socketOrder) do
		local socketControl = new("ItemSlotControl"):ItemSlotControl({ "TOPLEFT", prevSlot, "BOTTOMLEFT" }, 0, 2, self, "Jewel " .. node.id, "Socket", node.id)
		self.sockets[node.id] = socketControl
		addSlot(socketControl)
	end
	self.controls.slotHeader = new("LabelControl"):LabelControl({ "BOTTOMLEFT", self.slotAnchor, "TOPLEFT" }, { 0, -4, 0, 16 }, "^7Equipped items:")
	self.controls.weaponSwap1 = new("ButtonControl"):ButtonControl({ "BOTTOMRIGHT", self.slotAnchor, "TOPRIGHT" }, { -20, -2, 18, 18 }, "I", function()
		if self.activeItemSet.useSecondWeaponSet then
			self.activeItemSet.useSecondWeaponSet = false
			self:AddUndoState()
			self.build.buildFlag = true
			local mainSocketGroup = self.build.skillsTab.socketGroupList[self.build.mainSocketGroup]
			if mainSocketGroup and mainSocketGroup.slot and self.slots[mainSocketGroup.slot].weaponSet == 2 then
				for index, socketGroup in ipairs(self.build.skillsTab.socketGroupList) do
					if socketGroup.slot and self.slots[socketGroup.slot].weaponSet == 1 then
						self.build.mainSocketGroup = index
						break
					end
				end
			end
		end
	end)
	self.controls.weaponSwap1.overSizeText = 3
	self.controls.weaponSwap1.locked = function()
		return not self.activeItemSet.useSecondWeaponSet
	end
	self.controls.weaponSwap2 = new("ButtonControl"):ButtonControl({ "BOTTOMRIGHT", self.slotAnchor, "TOPRIGHT" }, { 0, -2, 18, 18 }, "II", function()
		if not self.activeItemSet.useSecondWeaponSet then
			self.activeItemSet.useSecondWeaponSet = true
			self:AddUndoState()
			self.build.buildFlag = true
			local mainSocketGroup = self.build.skillsTab.socketGroupList[self.build.mainSocketGroup]
			if mainSocketGroup and mainSocketGroup.slot and self.slots[mainSocketGroup.slot].weaponSet == 1 then
				for index, socketGroup in ipairs(self.build.skillsTab.socketGroupList) do
					if socketGroup.slot and self.slots[socketGroup.slot].weaponSet == 2 then
						self.build.mainSocketGroup = index
						break
					end
				end
			end
		end
	end)
	self.controls.weaponSwap2.overSizeText = 3
	self.controls.weaponSwap2.locked = function()
		return self.activeItemSet.useSecondWeaponSet
	end
	self.controls.weaponSwapLabel = new("LabelControl"):LabelControl({ "RIGHT", self.controls.weaponSwap1, "LEFT" }, { -4, 0, 0, 14 }, "^7Weapon Set:")

	-- All items list
	if main.portraitMode then
		self.controls.itemList = new("ItemListControl"):ItemListControl({ "TOPRIGHT", self.lastSlot, "BOTTOMRIGHT" }, { 0, 0, 360, 308 }, self, true)
	else
		self.controls.itemList = new("ItemListControl"):ItemListControl({ "TOPLEFT", self.controls.setManage, "TOPRIGHT" }, { 40, 20, 360, 308 }, self, true)
	end

	-- Database selector
	self.controls.selectDBLabel = new("LabelControl"):LabelControl({ "TOPLEFT", self.controls.itemList, "BOTTOMLEFT" }, { 0, 14, 0, 16 }, "^7Import from:")
	self.controls.selectDBLabel.shown = function()
		return self.height < 980
	end
	self.selectedDB = "UNIQUE"

	-- Uniques Button
	self.controls.uniqueButton = new("ButtonControl"):ButtonControl({ "LEFT", self.controls.selectDBLabel, "RIGHT" }, { 4, 0, 110, 18 }, "Uniques", function()
	    self.selectedDB = "UNIQUE"
	end)
	self.controls.uniqueButton.locked = function() return self.selectedDB == "UNIQUE" end

	-- Rare Templates Button
	self.controls.rareButton = new("ButtonControl"):ButtonControl({ "LEFT", self.controls.selectDBLabel, "RIGHT" }, { 120, 0, 110, 18 }, "Rare Templates", function()
	    self.selectedDB = "RARE"
	end)
	self.controls.rareButton.locked = function() return self.selectedDB == "RARE" end

	-- Unique database
	self.controls.uniqueDB = new("ItemDBControl"):ItemDBControl({ "TOPLEFT", self.controls.itemList, "BOTTOMLEFT" }, { 0, 76, 360, function(c) return m_min(244, self.maxY - select(2, c:GetPos())) end }, self, main.uniqueDB, "UNIQUE")
	self.controls.uniqueDB.y = function()
		return self.controls.selectDBLabel:IsShown() and 118 or 90
	end
	self.controls.uniqueDB.shown = function()
		return not self.controls.selectDBLabel:IsShown() or self.selectedDB == "UNIQUE"
	end

	-- Rare template database
	self.controls.rareDB = new("ItemDBControl"):ItemDBControl({ "TOPLEFT", self.controls.itemList, "BOTTOMLEFT" }, { 0, 76, 360, function(c) return m_min(284, self.maxY - select(2, c:GetPos())) end }, self, main.rareDB, "RARE")
	self.controls.rareDB.y = function()
		return self.controls.selectDBLabel:IsShown() and 78 or 386
	end
	self.controls.rareDB.shown = function()
		return not self.controls.selectDBLabel:IsShown() or self.selectedDB == "RARE"
	end

	-- Create/import item
	self.controls.craftDisplayItem = new("ButtonControl"):ButtonControl({ "TOPLEFT", main.portraitMode and self.controls.setManage or self.controls.itemList, "TOPRIGHT" }, { 20, main.portraitMode and 0 or -20, 120, 20 }, "Craft item...", function()
		self:CraftItem()
	end)
	self.controls.craftDisplayItem.shown = function()
		return self.displayItem == nil
	end
	self.controls.newDisplayItem = new("ButtonControl"):ButtonControl({ "TOPLEFT", self.controls.craftDisplayItem, "TOPRIGHT" }, { 8, 0, 120, 20 }, "Create custom...", function()
		self:EditDisplayItemText()
	end)
	self.controls.displayItemTip = new("LabelControl"):LabelControl({ "TOPLEFT", self.controls.craftDisplayItem, "BOTTOMLEFT" }, { 0, 8, 100, 16 },
[[^7Double-click an item from one of the lists,
or copy and paste an item from in game
(hover over the item and Ctrl+C) to view or edit
the item and add it to your build. You can
also clone an item within Path of Building by
copying and pasting it with Ctrl+C and Ctrl+V.

You can Control + Click an item to equip it, or
drag it onto the slot.  This will also add it to
your build if it's from the unique/template list.
If there's 2 slots an item can go in,
holding Shift will put it in the second.]])
	self.controls.sharedItemList = new("SharedItemListControl"):SharedItemListControl({ "TOPLEFT", self.controls.craftDisplayItem, "BOTTOMLEFT" }, { 0, 232, 340, 308 }, self, true)

	-- Display item
	self.displayItemTooltip = new("Tooltip"):Tooltip()
	self.displayItemTooltip.maxWidth = 458
	self.anchorDisplayItem = new("Control"):Control({ "TOPLEFT", main.portraitMode and self.controls.setManage or self.controls.itemList, "TOPRIGHT" }, { 20, main.portraitMode and 0 or -20, 0, 0 })
	self.anchorDisplayItem.shown = function()
		return self.displayItem ~= nil
	end
	self.controls.addDisplayItem = new("ButtonControl"):ButtonControl({ "TOPLEFT", self.anchorDisplayItem, "TOPLEFT" }, { 0, 0, 100, 20 }, "", function()
		self:AddDisplayItem()
	end)
	self.controls.addDisplayItem.label = function()
		return self.items[self.displayItem.id] and "Save" or "Add to build"
	end
	self.controls.editDisplayItem = new("ButtonControl"):ButtonControl({ "LEFT", self.controls.addDisplayItem, "RIGHT" }, { 8, 0, 60, 20 }, "Edit...", function()
		self:EditDisplayItemText()
	end)
	self.controls.removeDisplayItem = new("ButtonControl"):ButtonControl({ "LEFT", self.controls.editDisplayItem, "RIGHT" }, { 8, 0, 60, 20 }, "Cancel", function()
		self:SetDisplayItem()
	end)

	self.controls.displayItemBuySimilar = new("ButtonControl"):ButtonControl({ "LEFT", self.controls.removeDisplayItem, "RIGHT", true },
		{ 8, 0, 100, 20 }, "Buy similar", function()
			local itemSlot = self:GetComparisonSlotNameForItem(self.displayItem)
			buySimilar.openPopup(self.displayItem, itemSlot, self.build)
		end)
	self.controls.displayItemBuySimilar.shown = function()
		return self.displayItem
	end
	-- Section: Variant(s)

	self.controls.displayItemSectionVariant = new("Control"):Control({ "TOPLEFT", self.controls.addDisplayItem, "BOTTOMLEFT" }, { 0, 8, 0, function()
		if not self.displayItem then
			return 0
		end
		if self.displayItem:UsesVersionedOrGroupedVariants() then
			local rows = self.displayItem.versionList and #self.displayItem.versionList > 1 and 1 or 0
			if self.displayItem:HasIndependentVariants() then
				rows = rows + (#self.displayItem.variantList > 1 and 1 or 0)
			else
				local groups = 0
				for groupId in pairsSortByKey(self.displayItem.variantGroups) do
					if groups < 6 and #self.displayItem:GetVariantGroupOptions(groupId, false) > 0 then
						rows = rows + 1
						groups = groups + 1
					end
				end
			end
			return rows > 0 and rows * 24 + 4 or 0
		end
		if not self.controls.displayItemVariant:IsShown() then
			return 0
		end
		return (28 +
		(self.displayItem.hasAltVariant and 24 or 0) +
		(self.displayItem.hasAltVariant2 and 24 or 0) +
		(self.displayItem.hasAltVariant3 and 24 or 0) +
		(self.displayItem.hasAltVariant4 and 24 or 0) +
		(self.displayItem.hasAltVariant5 and 24 or 0))
	end})
	self.controls.displayItemVersion = new("DropDownControl"):DropDownControl({ "TOPLEFT", self.controls.displayItemSectionVariant, "TOPLEFT" }, { 0, 0, 300, 20 }, nil, function(index, value)
		self.displayItem.selectedVersion = index
		self.displayItem:NormaliseVariantSelections()
		self.displayItem:BuildAndParseRaw()
		self:UpdateDisplayItemVariantControls()
		self:UpdateRuneControls()
		self:UpdateDisplayItemTooltip()
		self:UpdateDisplayItemRangeLines()
	end)
	self.controls.displayItemVersion.maxDroppedWidth = 1000
	self.controls.displayItemVersion.shown = function()
		return self.displayItem and self.displayItem:UsesVersionedOrGroupedVariants()
			and self.displayItem.versionList and #self.displayItem.versionList > 1
	end
	self.controls.displayItemVariant = new("DropDownControl"):DropDownControl({ "TOPLEFT", self.controls.displayItemSectionVariant, "TOPLEFT" }, { 0, 0, 300, 20 }, nil, function(index, value)
		self:SelectDisplayItemVariant(index, value, "variant", self.controls.displayItemVariant)
	end)
	self.controls.displayItemVariant.y = function()
		return self.controls.displayItemVersion:IsShown() and 24 or 0
	end
	self.controls.displayItemVariant.maxDroppedWidth = 1000
	self.controls.displayItemVariant.shown = function()
		return self.displayItem.variantList and #self.displayItem.variantList > 1
	end
	self.controls.displayItemAltVariant = new("DropDownControl"):DropDownControl({ "TOPLEFT", self.controls.displayItemVariant, "BOTTOMLEFT" }, { 0, 4, 300, 20 }, nil, function(index, value)
		self:SelectDisplayItemVariant(index, value, "variantAlt", self.controls.displayItemAltVariant)
	end)
	self.controls.displayItemAltVariant.maxDroppedWidth = 1000
	self.controls.displayItemAltVariant.shown = function()
		return self.displayItem.hasAltVariant
	end
	self.controls.displayItemAltVariant2 = new("DropDownControl"):DropDownControl({ "TOPLEFT", self.controls.displayItemAltVariant, "BOTTOMLEFT" }, { 0, 4, 300, 20 }, nil, function(index, value)
		self:SelectDisplayItemVariant(index, value, "variantAlt2", self.controls.displayItemAltVariant2)
	end)
	self.controls.displayItemAltVariant2.maxDroppedWidth = 1000
	self.controls.displayItemAltVariant2.shown = function()
		return self.displayItem.hasAltVariant2
	end
	self.controls.displayItemAltVariant3 = new("DropDownControl"):DropDownControl({ "TOPLEFT", self.controls.displayItemAltVariant2, "BOTTOMLEFT" }, { 0, 4, 300, 20 }, nil, function(index, value)
		self:SelectDisplayItemVariant(index, value, "variantAlt3", self.controls.displayItemAltVariant3)
	end)
	self.controls.displayItemAltVariant3.maxDroppedWidth = 1000
	self.controls.displayItemAltVariant3.shown = function()
		return self.displayItem.hasAltVariant3
	end
	self.controls.displayItemAltVariant4 = new("DropDownControl"):DropDownControl({ "TOPLEFT", self.controls.displayItemAltVariant3, "BOTTOMLEFT" }, { 0, 4, 300, 20 }, nil, function(index, value)
		self:SelectDisplayItemVariant(index, value, "variantAlt4", self.controls.displayItemAltVariant4)
	end)
	self.controls.displayItemAltVariant4.maxDroppedWidth = 1000
	self.controls.displayItemAltVariant4.shown = function()
		return self.displayItem.hasAltVariant4
	end
	self.controls.displayItemAltVariant5 = new("DropDownControl"):DropDownControl({ "TOPLEFT", self.controls.displayItemAltVariant4, "BOTTOMLEFT" }, { 0, 4, 300, 20 }, nil, function(index, value)
		self:SelectDisplayItemVariant(index, value, "variantAlt5", self.controls.displayItemAltVariant5)
	end)
	self.controls.displayItemAltVariant5.maxDroppedWidth = 1000
	self.controls.displayItemAltVariant5.shown = function()
		return self.displayItem.hasAltVariant5
	end
	for _, control in ipairs({
		self.controls.displayItemVariant,
		self.controls.displayItemAltVariant,
		self.controls.displayItemAltVariant2,
		self.controls.displayItemAltVariant3,
		self.controls.displayItemAltVariant4,
		self.controls.displayItemAltVariant5,
	}) do
		local legacyShown = control.shown
		control.shown = function(c)
			if not self.displayItem then
				return false
			end
			if self.displayItem:UsesVersionedOrGroupedVariants() then
				return c.newVariantVisible
			end
			return legacyShown()
		end
		control.enabled = function(c)
			return not self.displayItem or not self.displayItem:UsesVersionedOrGroupedVariants() or c.newVariantEnabled
		end
	end

	-- Section: Sockets and Links
	self.controls.displayItemSectionSockets = new("Control"):Control({ "TOPLEFT", self.controls.displayItemSectionVariant, "BOTTOMLEFT" }, { 0, 0, 0, function()
		return canHaveAugmentSockets(self.displayItem) and 28 or 0
	end})
	self.controls.displayItemSocketRune = new("LabelControl"):LabelControl({ "TOPLEFT", self.controls.displayItemSectionSockets, "TOPLEFT" }, { 0, 0, 36, 20 }, "^x7F7F7FS")
	self.controls.displayItemSocketRune.shown = function()
		return canHaveAugmentSockets(self.displayItem)
	end
	self.controls.displayItemSocketRuneEdit = new("EditControl"):EditControl({ "LEFT", self.controls.displayItemSocketRune, "RIGHT" }, { 2, 0, 50, 20 }, nil, nil, "%D", 1, function(buf)
		local count = tonumber(buf) or 0
		if count > 6 then
			self.controls.displayItemSocketRuneEdit:SetText(6)
			return
		end
		self.displayItem.itemSocketCount = count
		self.displayItem:UpdateRunes()
		self.displayItem:BuildAndParseRaw()
		self:UpdateRuneControls()
		self:UpdateDisplayItemTooltip()
	end)
	self.controls.displayItemSocketRuneEdit.shown = self.controls.displayItemSocketRune

	-- Jewel Sockets // shown where Runes are shown
	self.controls.displayItemSocketJewel = new("LabelControl"):LabelControl({ "TOPLEFT", self.controls.displayItemSocketRune, "TOPLEFT" }, { 70, 0, 36, 20 }, "^x7F7F7FJ")
	self.controls.displayItemSocketJewelEdit = new("EditControl"):EditControl({ "LEFT", self.controls.displayItemSocketJewel, "RIGHT" }, { 2, 0, 50, 20 }, nil, nil, "%D", 1, function(buf)
		local count = tonumber(buf) or 0
		if count > 6 then
			self.controls.displayItemSocketJewelEdit:SetText(6)
			return
		end
		self.displayItem.jewelSocketCount = count
		self.displayItem:BuildAndParseRaw()
		self:UpdateDisplayItemTooltip()
	end)

	-- Section: Enchant / Anoint / Corrupt
	self.controls.displayItemSectionEnchant = new("Control"):Control({ "TOPLEFT", self.controls.displayItemSectionSockets, "BOTTOMLEFT" }, { 0, 0, 0, function()
		return (self.controls.displayItemAnoint:IsShown() or self.controls.displayItemCorrupt:IsShown() ) and 28 or 0
	end})
	self.controls.displayItemAnoint = new("ButtonControl"):ButtonControl({ "TOPLEFT", self.controls.displayItemSectionEnchant, "TOPLEFT" }, { 0, 0, 100, 20 }, "Anoint...", function()
		self:AnointDisplayItem(1)
	end)
	self.controls.displayItemAnoint.shown = function()
		return self.displayItem and isAnointable(self.displayItem)
	end
	self.controls.displayItemAnoint2 = new("ButtonControl"):ButtonControl({ "TOPLEFT", self.controls.displayItemAnoint, "TOPRIGHT", true }, { 8, 0, 100, 20 }, "Anoint 2...", function()
		self:AnointDisplayItem(2)
	end)
	self.controls.displayItemAnoint2.shown = function()
		return self.displayItem and isAnointable(self.displayItem) and
			self.displayItem.canHaveTwoEnchants and #self.displayItem.enchantModLines > 0
	end
	self.controls.displayItemAnoint3 = new("ButtonControl"):ButtonControl({ "TOPLEFT", self.controls.displayItemAnoint2, "TOPRIGHT", true }, { 8, 0, 100, 20 }, "Anoint 3...", function()
		self:AnointDisplayItem(3)
	end)
	self.controls.displayItemAnoint3.shown = function()
		return self.displayItem and isAnointable(self.displayItem) and
			self.displayItem.canHaveThreeEnchants and #self.displayItem.enchantModLines > 1
	end
	self.controls.displayItemAnoint4 = new("ButtonControl"):ButtonControl({ "TOPLEFT", self.controls.displayItemAnoint3, "TOPRIGHT", true }, { 8, 0, 100, 20 }, "Anoint 4...", function()
		self:AnointDisplayItem(4)
	end)
	self.controls.displayItemAnoint4.shown = function()
		return self.displayItem and isAnointable(self.displayItem) and
			self.displayItem.canHaveFourEnchants and #self.displayItem.enchantModLines > 2
	end
	self.controls.displayItemCorrupt = new("ButtonControl"):ButtonControl({ "TOPLEFT", self.controls.displayItemAnoint4, "TOPRIGHT", true }, { 8, 0, 100, 20 }, "Corrupt...", function()
		self:CorruptDisplayItem()
	end)
	self.controls.displayItemCorrupt.shown = function()
		return self.displayItem and self.displayItem.corruptible
	end

	-- Section: Item Quality
	self.controls.displayItemSectionQuality = new("Control"):Control({ "TOPLEFT", self.controls.displayItemSectionEnchant, "BOTTOMLEFT" }, { 0, 0, 0, function()
		return (self.controls.displayItemQuality:IsShown() and self.controls.displayItemQualityEdit:IsShown()) and 28 or 0
	end})
	self.controls.displayItemQuality = new("LabelControl"):LabelControl({ "TOPLEFT", self.controls.displayItemSectionQuality, "TOPRIGHT" }, { -4, 0, 0, 16 }, "^7Quality:")
	self.controls.displayItemQuality.shown = function()
		return self.displayItem and self.displayItem.quality and self.displayItem.base.quality
	end

	self.controls.displayItemQualityEdit = new("EditControl"):EditControl({ "LEFT", self.controls.displayItemQuality, "RIGHT" }, { 2, 0, 60, 20 }, nil, nil, "%D", 2, function(buf)
		self.displayItem.quality = tonumber(buf)
		self.displayItem:BuildAndParseRaw()
		self:UpdateDisplayItemTooltip()
	end)
	self.controls.displayItemQualityEdit.shown = function()
		return self.displayItem and self.displayItem.quality and self.displayItem.base.quality
	end

	-- Section: Catalysts
	self.controls.displayItemSectionCatalyst = new("Control"):Control({ "TOPLEFT", self.controls.displayItemSectionQuality, "BOTTOMLEFT" }, { 0, 0, 0, function()
		return (self.controls.displayItemCatalyst:IsShown() or self.controls.displayItemCatalystQualityEdit:IsShown()) and 28 or 0
	end})
	self.controls.displayItemCatalyst = new("DropDownControl"):DropDownControl({ "TOPLEFT", self.controls.displayItemSectionCatalyst, "TOPRIGHT" }, { 0, 0, 250, 20 },
		{"Catalyst",
		"Flesh (Life)",
		"Neural (Mana)",
		"Carapace (Defense)",
		"Uul-Netol's (Physical)",
		"Xoph's (Fire)",
		"Tul's (Cold)",
		"Esh's (Lightning)",
		"Chayula's (Chaos)",
		"Reaver (Attack)",
		"Sibilant (Caster)",
		"Skittering (Speed)",
		"Adaptive (Attribute)",
		"Necrotic (Minion)",
		},
		function(index, value)
			self.displayItem.catalyst = index - 1
			if not self.displayItem.catalystQuality then
				if string.match(self.displayItem.name, "Breach Ring") then
					self.displayItem.catalystQuality = 50
				else
					self.displayItem.catalystQuality = 20
				end
				self.controls.displayItemCatalystQualityEdit:SetText(self.displayItem.catalystQuality)
			end
			if self.displayItem.crafted then
				for i = 1, self.displayItem.affixLimit do
					-- Force affix selectors to update
					local drop = self.controls["displayItemAffix"..i]
					drop.selFunc(drop.selIndex, drop.list[drop.selIndex])
				end
			end
			self.displayItem:BuildAndParseRaw()
			self:UpdateDisplayItemTooltip()
		end)
	self.controls.displayItemCatalyst.shown = function()
		return self.displayItem and (self.displayItem.crafted or self.displayItem.hasModTags) and (self.displayItem.base.type == "Amulet" or self.displayItem.base.type == "Ring")
	end
	self.controls.displayItemCatalystQualityEdit = new("EditControl"):EditControl({ "LEFT", self.controls.displayItemCatalyst, "RIGHT" }, { 2, 0, 60, 20 }, nil, nil, "%D", 2, function(buf)
		self.displayItem.catalystQuality = tonumber(buf)
		if self.displayItem.crafted then
			for i = 1, self.displayItem.affixLimit do
				-- Force affix selectors to update
				local drop = self.controls["displayItemAffix"..i]
				drop.selFunc(drop.selIndex, drop.list[drop.selIndex])
			end
		end
		self.displayItem:BuildAndParseRaw()
		self:UpdateDisplayItemTooltip()
	end)
	self.controls.displayItemCatalystQualityEdit.shown = function()
		return self.displayItem and (self.displayItem.crafted or self.displayItem.hasModTags) and self.displayItem.catalyst and self.displayItem.catalyst > 0
	end

	-- Section: Cluster Jewel
	self.controls.displayItemSectionClusterJewel = new("Control"):Control({ "TOPLEFT", self.controls.displayItemSectionCatalyst, "BOTTOMLEFT" }, { 0, 0, 0, function()
		return self.controls.displayItemClusterJewelSkill:IsShown() and 52 or 0
	end})
	self.controls.displayItemClusterJewelSkill = new("DropDownControl"):DropDownControl({ "TOPLEFT", self.controls.displayItemSectionClusterJewel, "TOPLEFT" }, { 0, 0, 300, 20 }, {}, function(index, value)
		self.displayItem.clusterJewelSkill = value.skillId
		self:CraftClusterJewel()
	end) {
		shown = function()
			return self.displayItem and self.displayItem.crafted and self.displayItem.clusterJewel
		end
	}

	self.controls.displayItemClusterJewelNodeCountLabel = new("LabelControl"):LabelControl({ "TOPLEFT", self.controls.displayItemClusterJewelSkill, "BOTTOMLEFT" }, { 0, 7, 0, 14 }, "^7Added Passives:")
	self.controls.displayItemClusterJewelNodeCount = new("SliderControl"):SliderControl({ "LEFT", self.controls.displayItemClusterJewelNodeCountLabel, "RIGHT" }, { 2, 0, 150, 20 }, function(val)
		local divVal = self.controls.displayItemClusterJewelNodeCount:GetDivVal()
		local clusterJewel = self.displayItem.clusterJewel
		self.displayItem.clusterJewelNodeCount = round(val * (clusterJewel.maxNodes - clusterJewel.minNodes) + clusterJewel.minNodes)
		self:CraftClusterJewel()
	end)

	-- Section: Rune Selection
	self.controls.displayItemSectionRune = new("Control"):Control({ "TOPLEFT", self.controls.displayItemSectionClusterJewel, "BOTTOMLEFT" }, { 0, 0, 0, function()
		if not hasAugmentSockets(self.displayItem) then
			return 0
		end
		local h = 6
		for i = 1, 6 do
			if self.controls["displayItemRune"..i]:IsShown() then
				h = h + 24
			end
		end
		return h
	end})
	for i = 1, 6 do
		local prev = self.controls["displayItemRune"..(i-1)] or self.controls.displayItemSectionRune
		local drop
		drop = new("DropDownControl"):DropDownControl({ "TOPLEFT", prev, "TOPLEFT" }, { i == 1 and 40 or 0, 0, 418, 20 }, nil, function(index, value)
			self.displayItem.runes[i] = value.name
			self.displayItem:UpdateRunes()
			self.displayItem:BuildAndParseRaw()
			if self.displayItem.crafted then
				self:UpdateAffixControls()
			end
			self:UpdateDisplayItemTooltip()
		end)
		drop.y = function()
			return i == 1 and 0 or 24
		end
		drop.tooltipFunc = function(tooltip, mode, index, value)
			tooltip:Clear()
			if value.lines and value.lines[1] ~= "None" then
				tooltip:AddLine(16, "^7" .. value.name)

				if value.limit then
					tooltip:AddLine(14, "^7" .. s_format("Limited to: %d", value.limit))
				end

				if value.req > 1 then
					tooltip:AddLine(14, "^7" .. s_format("Requires: Level %d", value.req))
				end
				for _, line in ipairs(value.lines) do
					tooltip:AddLine(14, colorCodes.MAGIC .. line)
				end
				-- Adding Comparison
				local compLines = { type = "Rune" }
				for _, line in ipairs(value.lines) do
					t_insert(compLines, line)
				end
				self:AddModComparisonTooltip(tooltip, compLines)
			end
		end
		drop.shown = function()
			return hasAugmentSockets(self.displayItem) and i <= self.displayItem.itemSocketCount
		end

		self.controls["displayItemRune"..i] = drop
		self.controls["displayItemRuneLabel" .. i] = new("LabelControl"):LabelControl({ "RIGHT", drop, "LEFT" }, { -4, 0, 0, 14 }, "^7Rune #" .. i)
	end

	-- Section: Crafting modifier sorting
	local sortList = buildModSortList()
	local function craftingSortingShown()
		return self.displayItem and self.displayItem.crafted and not self.displayItem.clusterJewel
	end
	self.controls.displayItemSectionCraftingSort = new("Control"):Control({ "TOPLEFT", self.controls.displayItemSectionRune, "BOTTOMLEFT" }, { 0, 0, 0, function()
		return craftingSortingShown() and 28 or 0
	end })
	self.controls.craftingSortingLabel = new("LabelControl"):LabelControl({ "TOPLEFT", self.controls.displayItemSectionCraftingSort, "TOPLEFT" }, { 0, 6, 0, 16 }, "^7Modifier sorting:")
	self.controls.craftingSortingLabel.shown = craftingSortingShown
	self.controls.craftingSorting = new("DropDownControl"):DropDownControl({ "LEFT", self.controls.craftingSortingLabel, "RIGHT" }, { 4, 0, 200, 20 }, sortList, function()
		self:UpdateAffixControls()
	end)
	self.controls.craftingSorting.shown = craftingSortingShown

	-- Section: Affix Selection
	local maxModCount = 9
	self.controls.displayItemSectionAffix = new("Control"):Control({ "TOPLEFT", self.controls.displayItemSectionCraftingSort, "BOTTOMLEFT" }, { 0, 0, 0, function()
		if not self.displayItem or not self.displayItem.crafted then
			return 0
		end
		local h = 6
		for i = 1, maxModCount do
			if self.controls["displayItemAffix"..i]:IsShown() then
				h = h + 24
				if self.controls["displayItemAffixRange"..i]:IsShown() then
					h = h + 18
				end
			end
		end
		return h
	end})

	for i = 1, maxModCount do
		local prev = self.controls["displayItemAffix"..(i-1)] or self.controls.displayItemSectionAffix
		local drop, slider
		local function verifyRange(range, index, drop) -- flips range if it will form discontinuous values
			local priorMod = index - 1 > 0 and self.displayItem.affixes[drop.list[drop.selIndex].modList[index - 1]] or nil
			local nextMod = index + 1 < #drop.list[drop.selIndex].modList and self.displayItem.affixes[drop.list[drop.selIndex].modList[index + 1]] or nil
			local function flipRange(modA, modB) -- assumes all pairs are ordered the same
				local function getMinMax(mod) -- gets first valid range from a mod
					for _, line in ipairs(mod) do
						local min, max = line:match("%((%d[%d%.]*)%-(%d[%d%.]*)%)")
						if min and max then return tonumber(min), tonumber(max)	end
					end
				end

				local minA, maxA = getMinMax(modA)
				local minB, maxB = getMinMax(modB)

				if not minA or not minB or not maxA or not maxB then
					return false
				end

				local allInts = minA == m_floor(minA) and maxA == m_floor(maxA) and minB == m_floor(minB) and maxB == m_floor(maxB) -- if the mod goes in steps that aren't 1, then the code below this doesn't work
				if (minA and minB and maxA and maxB and allInts) then
					if (minA < minB) then -- ascending
						return minA + 1 == maxB
					else -- descending
						return minA - 1 == maxB
					end
				end
				return false
			end

			if priorMod then
				if flipRange(priorMod, self.displayItem.affixes[drop.list[drop.selIndex].modList[index]]) then
					range = 1 - range
				end
			elseif nextMod then
				if flipRange(self.displayItem.affixes[drop.list[drop.selIndex].modList[index]], nextMod) then
					range = 1 - range
				end
			end
			return range
		end
		drop = new("DropDownControl"):DropDownControl({ "TOPLEFT", prev, "TOPLEFT" }, { i == 1 and 40 or 0, 0, 418, 20 }, nil, function(index, value)
			local affix = { modId = "None", fractured = self.displayItem[drop.outputTable][drop.outputIndex].fractured }
			if value.modId then
				affix.modId = value.modId
				affix.range = slider.val
			elseif value.modList then
				slider.divCount = #value.modList
				local index, range = slider:GetDivVal()
				affix.modId = value.modList[index]
				affix.range = verifyRange(range, index, drop)
			end
			self.displayItem[drop.outputTable][drop.outputIndex] = affix
			self.displayItem:Craft()
			self:UpdateDisplayItemTooltip()
			self:UpdateAffixControls()
		end)
		drop.y = function()
			return i == 1 and 0 or 24 + (prev.slider:IsShown() and 18 or 0)
		end
		drop.tooltipFunc = function(tooltip, mode, index, value)
			local modList = value and value.modList
			if not modList or main.popups[1] or mode == "OUT" or (self.selControl and self.selControl ~= drop) then
				tooltip:Clear()
			elseif tooltip:CheckForUpdate(modList) then
				if value.modId or #modList == 1 then
					local mod = self.displayItem.affixes[value.modId or modList[1]]
					tooltip:AddLine(16, "^7Affix: "..mod.affix)
					for _, line in ipairs(mod) do
						tooltip:AddLine(14, "^7"..line)
					end
					if mod.level > 1 then
						tooltip:AddLine(16, "Level: "..mod.level)
					end
					if mod.modTags and #mod.modTags > 0 then
						tooltip:AddLine(16, "Tags: "..table.concat(mod.modTags, ', '))
					end
				else
					tooltip:AddLine(16, "^7"..#modList.." Tiers")
					local minMod = self.displayItem.affixes[modList[1]]
					local maxMod = self.displayItem.affixes[modList[#modList]]
					for l, line in ipairs(minMod) do
						local minLine = line:gsub("%((%d[%d%.]*)%-(%d[%d%.]*)%)", "%1")
						local maxLine = maxMod[l]:gsub("%((%d[%d%.]*)%-(%d[%d%.]*)%)", "%2")
						if maxLine == maxMod[l] then
							tooltip:AddLine(14, maxLine)
						else
							local start = 1
							tooltip:AddLine(14, (minLine:gsub("%d[%d%.]*", function(min)
								local s, e, max = maxLine:find("(%d[%d%.]*)", start)
								start = e + 1
								if min == max then
									return min
								else
									return "("..min.."-"..max..")"
								end
							end)))
						end
					end
					tooltip:AddLine(16, "Level: "..minMod.level.." to "..maxMod.level)
					-- Assuming that all mods have the same tags
					if maxMod.modTags and #maxMod.modTags > 0 then
						tooltip:AddLine(16, "Tags: "..table.concat(maxMod.modTags, ', '))
					end
				end
				local mod = self.displayItem.affixes[value.modId or modList[1]]
				local notableName = mod[1] and mod[1]:match("1 Added Passive Skill is (.*)")
				local node = notableName and self.build.spec.tree.clusterNodeMap[notableName]
				if node then
					tooltip:AddSeparator(14)

					-- Node name
					self.socketViewer:AddNodeName(tooltip, node, self.build)

					-- Node description
					if node.sd[1] then
						tooltip:AddLine(18, "")
						for i, line in ipairs(node.sd) do
							if line ~= " " and (node.mods[i].extra or not node.mods[i].list) then
								local line = colorCodes.UNSUPPORTED .. line
								line = main.notSupportedModTooltips and (line .. main.notSupportedTooltipText) or line
								tooltip:AddLine(18, line)
							else
								tooltip:AddLine(18, colorCodes.MAGIC..line)
							end
						end
					end

					-- Reminder text
					if node.reminderText then
						tooltip:AddSeparator(14)
						for _, line in ipairs(node.reminderText) do
							tooltip:AddLine(14, "^xA0A080"..line)
						end
					end

					-- Comparison
					tooltip:AddSeparator(14)
					self:AppendAddedNotableTooltip(tooltip, node)

					-- Information of for this notable appears
					local clusterInfo = self.build.data.clusterJewelInfoForNotable[notableName]
					if clusterInfo then
						tooltip:AddSeparator(14)
						tooltip:AddLine(20, "^7"..notableName.." can appear on:")
						local isFirstSize = true
						for size, v in pairs(clusterInfo.size) do
							tooltip:AddLine(18, colorCodes.MAGIC..size..":")
							local sizeSkills = self.build.data.clusterJewels.jewels[size].skills
							for i, type in ipairs(clusterInfo.jewelTypes) do
								if sizeSkills[type] then
									tooltip:AddLine(14, "^7    "..sizeSkills[type].name)
								end
							end
							if not isFirstSize then
								tooltip:AddLine(10, "")
							end
							isFirstSize = false
						end
					end
				else
					local mod = { }
					if value.modId or #modList == 1 then
						mod = self.displayItem.affixes[value.modId or modList[1]]
					else
						mod = self.displayItem.affixes[modList[1 + round((#modList - 1) * main.defaultItemAffixQuality)]]
					end

					-- Adding Mod
					self:AddModComparisonTooltip(tooltip, mod)
				end
			end
		end
		drop.shown = function()
			return self.displayItem and self.displayItem.crafted and i <= self.displayItem.affixLimit
		end
		slider = new("SliderControl"):SliderControl({ "TOPLEFT", drop, "BOTTOMLEFT" }, { 0, 2, 300, 16 }, function(val)
			local affix = self.displayItem[drop.outputTable][drop.outputIndex]
			local index, range = slider:GetDivVal()
			affix.modId = drop.list[drop.selIndex].modList[index]

			affix.range = verifyRange(range, index, drop)
			self.displayItem:Craft()
			self:UpdateDisplayItemTooltip()
		end)
		slider.width = function()
			return slider.divCount and 300 or 100
		end
		slider.tooltipFunc = function(tooltip, val)
			local modList = drop.list[drop.selIndex].modList
			if not modList or main.popups[1] or (self.selControl and self.selControl ~= slider) then
				tooltip:Clear()
			elseif tooltip:CheckForUpdate(val, modList) then
				local index, range = slider:GetDivVal(val)
				range = verifyRange(range, index, drop)
				local modId = modList[index]
				local mod = self.displayItem.affixes[modId]
				for _, line in ipairs(mod) do
					tooltip:AddLine(16, itemLib.applyRange(line, range))
				end
				tooltip:AddSeparator(10)
				if #modList > 1 then
					tooltip:AddLine(16, "^7Affix: Tier "..(#modList - isValueInArray(modList, modId) + 1).." ("..mod.affix..")")
				else
					tooltip:AddLine(16, "^7Affix: "..mod.affix)
				end
				for _, line in ipairs(mod) do
					tooltip:AddLine(14, line)
				end
				if mod.level > 1 then
					tooltip:AddLine(16, "Level: "..mod.level)
				end
			end
		end
		drop.slider = slider
		self.controls["displayItemAffix"..i] = drop
		self.controls["displayItemAffixLabel" .. i] = new("LabelControl"):LabelControl({ "RIGHT", drop, "LEFT" }, { -4, 0, 0, 14 }, function()
			return drop.outputTable == "prefixes" and "^7Prefix:" or "^7Suffix:"
		end)
		self.controls["displayItemAffixRange"..i] = slider
		self.controls["displayItemAffixRangeLabel" .. i] = new("LabelControl"):LabelControl({ "RIGHT", slider, "LEFT" }, { -4, 0, 0, 14 }, function()
			return drop.selIndex > 1 and "^7Roll:" or "^x7F7F7FRoll:"
		end)
	end

	-- Section: Custom modifiers
	-- if Custom mod button is shown, create the control for the list of mods
	self.controls.displayItemSectionCustom = new("Control"):Control({ "TOPLEFT", self.controls.displayItemSectionAffix, "BOTTOMLEFT" }, { 0, 0, 0, function()
		return self.controls.displayItemAddCustom:IsShown() and 28 + self.displayItem.customCount * 22 or 0
	end})
	self.controls.displayItemAddCustom = new("ButtonControl"):ButtonControl({ "TOPLEFT", self.controls.displayItemSectionCustom, "TOPLEFT" }, { 0, 0, 120, 20 }, "Add modifier...", function()
		self:AddCustomModifierToDisplayItem()
	end)
	self.controls.displayItemAddCustom.shown = function()
		return self.displayItem and (self.displayItem.rarity == "MAGIC" or self.displayItem.rarity == "RARE")
	end

	-- Section: Modifier Range
	self.controls.displayItemSectionRange = new("Control"):Control({ "TOPLEFT", self.controls.displayItemSectionCustom, "BOTTOMLEFT" }, { 0, 0, 0, function()
		if not self.displayItem or not self.displayItem.rangeLineList[1] then
			return 0
		end
		if main.showAllItemAffixes and (self.displayItem.rarity == "UNIQUE" or self.displayItem.rarity == "RELIC") then
			local count = #self.displayItem.rangeLineList
			return count * 22 + 4
		else
			return 28
		end
	end})
	self.controls.displayItemRangeLine = new("DropDownControl"):DropDownControl({ "TOPLEFT", self.controls.displayItemSectionRange, "TOPLEFT" }, { 0, 0, 350, 18 }, nil, function(index, value)
		self.controls.displayItemRangeSlider.val = self.displayItem.rangeLineList[index].range
	end)
	self.controls.displayItemRangeLine.shown = function()
		return self.displayItem and self.displayItem.rangeLineList[1] ~= nil and
		not (main.showAllItemAffixes and (self.displayItem.rarity == "UNIQUE" or self.displayItem.rarity == "RELIC"))
	end
	self.controls.displayItemRangeSlider = new("SliderControl"):SliderControl({ "LEFT", self.controls.displayItemRangeLine, "RIGHT" }, { 8, 0, 100, 18 }, function(val)
		self.displayItem.rangeLineList[self.controls.displayItemRangeLine.selIndex].range = val
		self.displayItem:BuildAndParseRaw()
		self:UpdateDisplayItemTooltip()
		self:UpdateCustomControls()
	end)

	for i = 1, 20 do
		local baseControl = i == 1 and self.controls.displayItemSectionRange or self.controls["displayItemStackedRangeSlider"..(i-1)]

		self.controls["displayItemStackedRangeSlider" .. i] = new("SliderControl"):SliderControl({ "TOPLEFT", baseControl, "TOPLEFT" }, { 0, function()
			return i == 1 and 2 or 22
		end, 100, 18}, function(val)
			if self.displayItem and self.displayItem.rangeLineList[i] then
				self.displayItem.rangeLineList[i].range = val
				self.displayItem:BuildAndParseRaw()
				self:UpdateDisplayItemTooltip()
				self:UpdateCustomControls()
			end
		end)
		self.controls["displayItemStackedRangeLine" .. i] = new("LabelControl"):LabelControl({ "LEFT", self.controls["displayItemStackedRangeSlider" .. i], "RIGHT" }, { 8, -2, 350, 14 }, function()
			if self.displayItem and self.displayItem.rangeLineList[i] then
				return "^7" .. self.displayItem.rangeLineList[i].line
			end
			return ""
		end)
		self.controls["displayItemStackedRangeSlider"..i].shown = function()
			return main.showAllItemAffixes and self.displayItem and
			(self.displayItem.rarity == "UNIQUE" or self.displayItem.rarity == "RELIC") and
			self.displayItem.rangeLineList[i] ~= nil
		end

		self.controls["displayItemStackedRangeLine"..i].shown = function()
			return self.controls["displayItemStackedRangeSlider"..i]:IsShown()
		end
	end

	-- Tooltip anchor
	self.controls.displayItemTooltipAnchor = new("Control"):Control({ "TOPLEFT", self.controls.displayItemSectionRange, "BOTTOMLEFT" })

	-- Scroll bars
	self.controls.scrollBarH = new("ScrollBarControl"):ScrollBarControl(nil, { 0, 0, 0, 18 }, 100, "HORIZONTAL", true)
	self.controls.scrollBarV = new("ScrollBarControl"):ScrollBarControl(nil, { 0, 0, 18, 0 }, 100, "VERTICAL", true)

	-- Initialise drag target lists
	t_insert(self.controls.itemList.dragTargetList, self.controls.sharedItemList)
	t_insert(self.controls.itemList.dragTargetList, build.controls.mainSkillMinion)
	t_insert(self.controls.uniqueDB.dragTargetList, self.controls.itemList)
	t_insert(self.controls.uniqueDB.dragTargetList, self.controls.sharedItemList)
	t_insert(self.controls.uniqueDB.dragTargetList, build.controls.mainSkillMinion)
	t_insert(self.controls.rareDB.dragTargetList, self.controls.itemList)
	t_insert(self.controls.rareDB.dragTargetList, self.controls.sharedItemList)
	t_insert(self.controls.rareDB.dragTargetList, build.controls.mainSkillMinion)
	t_insert(self.controls.sharedItemList.dragTargetList, self.controls.itemList)
	t_insert(self.controls.sharedItemList.dragTargetList, build.controls.mainSkillMinion)
	for _, slot in pairs(self.slots) do
		t_insert(self.controls.itemList.dragTargetList, slot)
		t_insert(self.controls.uniqueDB.dragTargetList, slot)
		t_insert(self.controls.rareDB.dragTargetList, slot)
		t_insert(self.controls.sharedItemList.dragTargetList, slot)
	end

	-- Initialise item sets
	self.itemSets = { }
	self.itemSetOrderList = { 1 }
	self:CreateItemSet(1, "Default")
	self:SetActiveItemSet(1)

	self:PopulateSlots()
	self.lastSlot = self.slots[baseSlots[#baseSlots]]
	return self
end

function ItemsTabClass:Load(xml, dbFileName)
	self.activeItemSetId = 0
	self.itemSets = { }
	self.itemSetOrderList = { }
	self.tradeQuery.statSortSelectionList = { }
	for _, node in ipairs(xml) do
		if node.elem == "Item" then
			local item = new("Item"):Item("")
			item.id = tonumber(node.attrib.id)
			item.variant = tonumber(node.attrib.variant)
			if node.attrib.variantAlt then
				item.hasAltVariant = true
				item.variantAlt = tonumber(node.attrib.variantAlt)
			end
			if node.attrib.variantAlt2 then
				item.hasAltVariant2 = true
				item.variantAlt2 = tonumber(node.attrib.variantAlt2)
			end
			if node.attrib.variantAlt3 then
				item.hasAltVariant3 = true
				item.variantAlt3 = tonumber(node.attrib.variantAlt3)
			end
			if node.attrib.variantAlt4 then
				item.hasAltVariant4 = true
				item.variantAlt4 = tonumber(node.attrib.variantAlt4)
			end
			if node.attrib.variantAlt5 then
				item.hasAltVariant5 = true
				item.variantAlt5 = tonumber(node.attrib.variantAlt5)
			end
			for _, child in ipairs(node) do
				if type(child) == "string" then
					item:ParseRaw(child)
				elseif child.elem == "ModRange" then
					local id = tonumber(child.attrib.id) or 0
					local range = tonumber(child.attrib.range) or 1
					-- This is garbage, but needed due to change to separate mod line lists
					-- 'ModRange' elements are legacy though, so is this actually needed? :<
					-- Maybe it is? Maybe it isn't? Maybe up is down? Maybe good is bad? AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
					-- Sorry, cluster jewels are making me crazy(-ier)
					for _, list in ipairs{item.buffModLines, item.enchantModLines, item.implicitModLines, item.explicitModLines } do
						if id <= #list then
							list[id].range = range
							break
						end
						id = id - #list
					end
				end
			end
			-- backwards compat or fallback if the item doesn't have "Sockets: J ..." on Load
			-- maybe at some point we won't need this at all
			local fallBackJewelSocketCount = {
				["Tabula Rasa"] = 6,
				["Sekhema's Resolve"] = 1,
			}
			if item.base then
				if fallBackJewelSocketCount[item.title] and item.jewelSocketCount == 0 then
					item.jewelSocketCount = fallBackJewelSocketCount[item.title]
				end
				item:BuildModList()
				self.items[item.id] = item
				t_insert(self.itemOrderList, item.id)
				end
		-- Below is OBE and left for legacy compatibility (all Slots are part of ItemSets now)
		elseif node.elem == "Slot" then
			local slot = self.slots[node.attrib.name or ""]
			if slot then
				slot.selItemId = tonumber(node.attrib.itemId)
				if slot.controls.activate then
					slot.active = node.attrib.active == "true"
					slot.controls.activate.state = slot.active
				end
			end
		elseif node.elem == "ItemSet" then
			local itemSet = self:CreateItemSet(tonumber(node.attrib.id), node.attrib.title or "Default")
			itemSet.useSecondWeaponSet = node.attrib.useSecondWeaponSet == "true"
			for _, child in ipairs(node) do
				if child.elem == "Slot" then
					local slotName = child.attrib.name or ""
					if itemSet[slotName] then
						itemSet[slotName].selItemId = tonumber(child.attrib.itemId)
						itemSet[slotName].active = child.attrib.active == "true"
						itemSet[slotName].pbURL = child.attrib.itemPbURL or ""
						itemSet[slotName].note = child.attrib.note
					end
				elseif child.elem == "RuneSlot" then
					local slotName = child.attrib.slotName or ""
					local slot = itemSet[slotName]
					if slot then
						local runeName = child.attrib.runeName or "None"
						slot.runeName = runeName
					end
				elseif child.elem == "SocketIdURL" then
					local id = tonumber(child.attrib.nodeId)
					itemSet[id] = { pbURL = child.attrib.itemPbURL or "" }
				end
			end
			t_insert(self.itemSetOrderList, itemSet.id)
		elseif node.elem == "TradeSearchWeights" then
			for _, child in ipairs(node) do
				local statSort = {
					label = child.attrib.label,
					stat = child.attrib.stat,
					weightMult = tonumber(child.attrib.weightMult)
				}
				for _, statEntry in ipairs(data.powerStatList) do
					if statSort.stat == statEntry.stat then
						-- update information which can be out of data or missing in the xml
						statSort.label = statEntry.label
						statSort.transform = statEntry.transform
						t_insert(self.tradeQuery.statSortSelectionList, statSort)
						break
					end
				end
			end
		end
	end
	if not self.itemSetOrderList[1] then
		self.activeItemSet = self:CreateItemSet(1, "Default")
		self.activeItemSet.useSecondWeaponSet = xml.attrib.useSecondWeaponSet == "true"
		self.itemSetOrderList[1] = 1
	end
	self:SetActiveItemSet(tonumber(xml.attrib.activeItemSet) or 1)
	if xml.attrib.showStatDifferences then
		self.showStatDifferences = xml.attrib.showStatDifferences == "true"
	end
	self:ResetUndo()
end

function ItemsTabClass:Save(xml)
	xml.attrib = {
		activeItemSet = tostring(self.activeItemSetId),
		useSecondWeaponSet = tostring(self.activeItemSet.useSecondWeaponSet),
		showStatDifferences = tostring(self.showStatDifferences),
	}
	for _, id in ipairs(self.itemOrderList) do
		local item = self.items[id]
		local child = {
			elem = "Item",
			attrib = {
				id = tostring(id),
				variant = item.variant and tostring(item.variant),
				variantAlt = item.variantAlt and tostring(item.variantAlt),
				variantAlt2 = item.variantAlt2 and tostring(item.variantAlt2),
				variantAlt3 = item.variantAlt3 and tostring(item.variantAlt3),
				variantAlt4 = item.variantAlt4 and tostring(item.variantAlt4),
				variantAlt5 = item.variantAlt5 and tostring(item.variantAlt5)
			}
		}
		item:BuildAndParseRaw()
		t_insert(child, item.raw)
		local id = #item.buffModLines + 1
		for _, modLine in ipairs(item.enchantModLines) do
			if modLine.range then
				t_insert(child, { elem = "ModRange", attrib = { id = tostring(id), range = tostring(modLine.range) } })
			end
			id = id + 1
		end
		for _, modLine in ipairs(item.runeModLines) do
			if modLine.range then
				t_insert(child, { elem = "ModRange", attrib = { id = tostring(id), range = tostring(modLine.range) } })
			end
			id = id + 1
		end
		for _, modLine in ipairs(item.implicitModLines) do
			if modLine.range then
				t_insert(child, { elem = "ModRange", attrib = { id = tostring(id), range = tostring(modLine.range) } })
			end
			id = id + 1
		end
		for _, modLine in ipairs(item.explicitModLines) do
			if modLine.range then
				t_insert(child, { elem = "ModRange", attrib = { id = tostring(id), range = tostring(modLine.range) } })
			end
			id = id + 1
		end
		t_insert(xml, child)
	end
	for _, itemSetId in ipairs(self.itemSetOrderList) do
		local itemSet = self.itemSets[itemSetId]
		local child = { elem = "ItemSet", attrib = { id = tostring(itemSetId), title = itemSet.title, useSecondWeaponSet = tostring(itemSet.useSecondWeaponSet) } }
		for slotName, slot in pairs(self.slots) do
			if not slot.parentSlot or itemSet[slotName].selItemId ~= 0 then
				if not slot.nodeId then
					t_insert(child, { elem = "Slot", attrib = { name = slotName, itemId = tostring(itemSet[slotName].selItemId), itemPbURL = itemSet[slotName].pbURL or "", active = itemSet[slotName].active and "true", note = itemSet[slotName].note }})
				else
					if self.build.spec.allocNodes[slot.nodeId] then
						t_insert(child, { elem = "SocketIdURL", attrib = { name = slotName, nodeId = tostring(slot.nodeId), itemPbURL = itemSet[slot.nodeId] and itemSet[slot.nodeId].pbURL or ""}})
					end
				end
			end
		end
		for slotName, _ in pairs(self.runeSlots) do
			local runeName = (itemSet[slotName] and itemSet[slotName].runeName) or "None"
			local node = { elem = "RuneSlot", attrib = { slotName = slotName, runeName = runeName } }
			t_insert(child, node)
		end
		t_insert(xml, child)
	end
	if self.tradeQuery.statSortSelectionList then
		local parent = {
			elem = "TradeSearchWeights"
		}
		for _, statSort in ipairs(self.tradeQuery.statSortSelectionList) do
			if statSort.weightMult and statSort.weightMult > 0 then
				local child = {
				elem = "Stat",
				attrib = {
					label = statSort.label,
					stat = statSort.stat,
					weightMult = s_format("%.2f", tostring(statSort.weightMult))
				}
			}
			t_insert(parent, child)
			end
		end
		t_insert(xml, parent)
	end
end

function ItemsTabClass:Draw(viewPort, inputEvents)
	self.x = viewPort.x
	self.y = viewPort.y
	self.width = viewPort.width
	self.height = viewPort.height
	self.controls.scrollBarH.width = viewPort.width
	self.controls.scrollBarH.x = viewPort.x
	self.controls.scrollBarH.y = viewPort.y + viewPort.height - 18
	self.controls.scrollBarV.height = viewPort.height - 18
	self.controls.scrollBarV.x = viewPort.x + viewPort.width - 18
	self.controls.scrollBarV.y = viewPort.y
	do
		local maxY = select(2, self.lastSlot:GetPos()) + 24
		local maxX = self.anchorDisplayItem:GetPos() + 462
		if self.displayItem then
			local x, y = self.controls.displayItemTooltipAnchor:GetPos()
			local ttW, ttH = self.displayItemTooltip:GetDynamicSize(viewPort)
			maxY = m_max(maxY, y + ttH + 4)
			maxX = m_max(maxX, x + ttW + 80)
		end
		local contentHeight = maxY - self.y
		local contentWidth = maxX - self.x
		local v = contentHeight > viewPort.height
		local h = contentWidth > viewPort.width - (v and 20 or 0)
		if h then
			v = contentHeight > viewPort.height - 20
		end
		self.controls.scrollBarV:SetContentDimension(contentHeight, viewPort.height - (h and 20 or 0))
		self.controls.scrollBarH:SetContentDimension(contentWidth, viewPort.width - (v and 20 or 0))
		if self.snapHScroll == "RIGHT" then
			self.controls.scrollBarH:SetOffset(self.controls.scrollBarH.offsetMax)
		elseif self.snapHScroll == "LEFT" then
			self.controls.scrollBarH:SetOffset(0)
		end
		self.snapHScroll = nil
		self.maxY = h and self.controls.scrollBarH.y or viewPort.y + viewPort.height
	end
	self.x = self.x - self.controls.scrollBarH.offset
	self.y = self.y - self.controls.scrollBarV.offset

	for _, event in ipairs(inputEvents) do
		if event.type == "KeyDown" then
			if event.key == "v" and IsKeyDown("CTRL") then
				local newItem = Paste()
				if newItem then
					self:CreateDisplayItemFromRaw(newItem, true)
				end
				if self.displayItem and IsKeyDown("SHIFT") then
					self:AddDisplayItem()
				end
			elseif event.key == "e" then
				local mOverControl = self:GetMouseOverControl()
				if mOverControl and mOverControl._className == "ItemSlotControl" and mOverControl.selItemId ~= 0 then
					-- Trigger itemList's double click procedure
					self.controls.itemList:OnSelClick(0, mOverControl.selItemId, true)
				end
			elseif event.key == "z" and IsKeyDown("CTRL") then
				self:Undo()
				self.build.buildFlag = true
			elseif event.key == "y" and IsKeyDown("CTRL") then
				self:Redo()
				self.build.buildFlag = true
			elseif event.key == "f" and IsKeyDown("CTRL") then
				if self.selectedDB == "RARE" then
					self:SelectControl(self.controls.rareDB.controls.search)
				else
					self:SelectControl(self.controls.uniqueDB.controls.search)
				end
			elseif event.key == "d" and IsKeyDown("CTRL") then
				self.showStatDifferences = not self.showStatDifferences
				self.build.buildFlag = true
			elseif self.displayItem and IsKeyDown("RETURN") then
				self:AddDisplayItem()
			end
		end
	end
	self:ProcessControlsInput(inputEvents, viewPort)
	for _, event in ipairs(inputEvents) do
		if event.type == "KeyUp" then
			if self.controls.scrollBarV:IsScrollDownKey(event.key) then
				if self.controls.scrollBarV:IsMouseOver() or not self.controls.scrollBarH:IsShown() then
					self.controls.scrollBarV:Scroll(1)
				else
					self.controls.scrollBarH:Scroll(1)
				end
			elseif self.controls.scrollBarV:IsScrollUpKey(event.key) then
				if self.controls.scrollBarV:IsMouseOver() or not self.controls.scrollBarH:IsShown() then
					self.controls.scrollBarV:Scroll(-1)
				else
					self.controls.scrollBarH:Scroll(-1)
				end
			end
		end
	end

	main:DrawBackground(viewPort)

	local newItemList = { }
	for index, itemSetId in ipairs(self.itemSetOrderList) do
		local itemSet = self.itemSets[itemSetId]
		t_insert(newItemList, itemSet.title or "Default")
		if itemSetId == self.activeItemSetId then
			self.controls.setSelect.selIndex = index
		end
	end
	self.controls.setSelect:SetList(newItemList)

	if self.displayItem then
		local x, y = self.controls.displayItemTooltipAnchor:GetPos()
		self.displayItemTooltip:Draw(x, y, nil, nil, viewPort)

		-- Toggle mods
		local cursorX, cursorY = GetCursorPos()
		for _, line in ipairs(self.displayItemTooltip.lines) do
			if line.modLine and line.bounds then
				local b = line.bounds
				if cursorX >= b.x and cursorX <= b.x + b.width and cursorY >= b.y and cursorY <= b.y + b.height then
					SetDrawColor(1, 1, 1, 0.15)
					DrawImage(nil, b.x, b.y, b.width, b.height)
					SetDrawColor(1, 1, 1)

					for id, event in ipairs(inputEvents) do
						if event.type == "KeyDown" and event.key:match("BUTTON") then
							inputEvents[id] = nil
							self:ToggleDisplayItemModLine(line.modLine)
							break
						end
					end
				end
			end
		end
	end

	self:UpdateSockets()
	-- Update weapon slots in case we got Giant's Blood from somewhere
	self.slots["Weapon 2"]:Populate()
	self.slots["Weapon 2 Swap"]:Populate()

	if main.portraitMode then
		self.controls.itemList:SetAnchor("TOPRIGHT", self.lastSlot, "BOTTOMRIGHT", 0, 40)
	else
		self.controls.itemList:SetAnchor("TOPLEFT", self.controls.setManage, "TOPRIGHT", 40, 20)
	end
	self.controls.craftDisplayItem:SetAnchor("TOPLEFT", main.portraitMode and self.controls.setManage or self.controls.itemList, "TOPRIGHT", 20, main.portraitMode and 0 or -20)
	self.anchorDisplayItem:SetAnchor("TOPLEFT", main.portraitMode and self.controls.setManage or self.controls.itemList, "TOPRIGHT", 20, main.portraitMode and 0)

	self:DrawControls(viewPort)
	if self.controls.scrollBarH:IsShown() then
		self.controls.scrollBarH:Draw(viewPort)
	end
	if self.controls.scrollBarV:IsShown() then
		self.controls.scrollBarV:Draw(viewPort)
	end

	self.controls.specSelect:SetList(self.build.treeTab:GetSpecList())
end

-- Creates a new item set
function ItemsTabClass:CreateItemSet(itemSetId, name)
	local itemSet = { id = itemSetId, title = name }
	if not itemSetId then
		itemSet.id = 1
		while self.itemSets[itemSet.id] do
			itemSet.id = itemSet.id + 1
		end
	end
	for slotName, slot in pairs(self.slots) do
		if not slot.nodeId then
			itemSet[slotName] = { selItemId = 0 }
		end
	end
	for slotName, _ in pairs(self.runeSlots) do
		itemSet[slotName] = { runeName = "None" }
	end
	self.itemSets[itemSet.id] = itemSet
	return itemSet
end

function ItemsTabClass:NewItemSet(itemSetId, name)
	local itemSet = self:CreateItemSet(itemSetId, name)
	t_insert(self.itemSetOrderList, itemSet.id)
	self.modFlag = true
	return itemSet
end

function ItemsTabClass:CopyItemSet(sourceItemSetId, newItemSetName)
	local newSet = copyTable(self.itemSets[sourceItemSetId])
	newSet.id = #self.itemSets + 1
	newSet.title = newItemSetName or newSet.title .. " (Copy)"
	t_insert(self.itemSetOrderList, newSet.id)
	self.modFlag = true
	self.itemSets[newSet.id] = newSet
	return newSet
end

-- Renames an item set
function ItemsTabClass:RenameItemSet(itemSetId, newTitle)
	local itemSet = self.itemSets[itemSetId]

	if not itemSet then
		return
	end

	itemSet.title = newTitle
	self.modFlag = true
end

-- Deletes an item set
function ItemsTabClass:DeleteItemSet(itemSetId, orderListIndex)
	t_remove(self.itemSetOrderList, orderListIndex)
	self.itemSets[itemSetId] = nil
	self.modFlag = true
end

-- Changes the active item set
function ItemsTabClass:SetActiveItemSet(itemSetId, deferSync)
	local prevSet = self.activeItemSet
	if not self.itemSetOrderList[1] then
		self:NewItemSet(1, "Default")
	end
	if not self.itemSets[itemSetId] then
		itemSetId = self.itemSetOrderList[1]
	end
	self.activeItemSetId = itemSetId
	self.activeItemSet = self.itemSets[itemSetId]
	local curSet = self.activeItemSet
	for slotName, slot in pairs(self.slots) do
		if not slot.nodeId then
			if prevSet then
				-- Update the previous set
				prevSet[slotName].selItemId = slot.selItemId
				prevSet[slotName].active = slot.active
				prevSet[slotName].note = slot.note
			end
			-- Equip the incoming set's item
			slot.selItemId = curSet[slotName].selItemId
			slot.active = curSet[slotName].active
			slot.note = curSet[slotName].note
			if slot.controls.activate then
				slot.controls.activate.state = slot.active
			end
		end
	end
	for slotName, slot in pairs(self.runeSlots) do
		if prevSet then
			-- Update the previous set
			prevSet[slotName] = { runeName = slot:GetSelValue().name }
		end
		-- Equip incoming set's rune
		local currentRune = curSet[slotName] and curSet[slotName].runeName or "None"
		slot:SelByValue(currentRune, "name")
	end
	self.build.buildFlag = true
	self:PopulateSlots()
	if not deferSync then
		self.build:SyncLoadouts()
	end
end

-- Equips the given item in the given item set
function ItemsTabClass:EquipItemInSet(item, itemSetId)
	local itemSet = self.itemSets[itemSetId]
	local slotName = item:GetPrimarySlot()
	if self.slots[slotName].weaponSet == 1 and itemSet.useSecondWeaponSet then
		-- Redirect to second weapon set
		slotName = slotName .. " Swap"
	end
	if not item.id or not self.items[item.id] then
		item = new("Item"):Item(item.raw)
		self:AddItem(item, true)
	end
	local altSlot = slotName:gsub("1","2")
	if IsKeyDown("SHIFT") then
		-- Redirect to second slot if possible
		if self:IsItemValidForSlot(item, altSlot, itemSet) then
			slotName = altSlot
		end
	end
	if itemSet == self.activeItemSet then
		self.slots[slotName]:SetSelItemId(item.id)
	else
		itemSet[slotName].selItemId = item.id
		if itemSet[altSlot].selItemId ~= 0 and not self:IsItemValidForSlot(self.items[itemSet[altSlot].selItemId], altSlot, itemSet) then
			itemSet[altSlot].selItemId = 0
		end
	end
	self:PopulateSlots()
	self:AddUndoState()
	self.build.buildFlag = true
end

-- Update the item lists for all the slot controls
function ItemsTabClass:PopulateSlots()
	for _, slot in pairs(self.slots) do
		slot:Populate()
	end
end

-- Updates the status and position of the socket controls
function ItemsTabClass:UpdateSockets()
	-- Build a list of active sockets
	self.activeSocketList = { }
	for nodeId, slot in pairs(self.sockets) do
		if self.build.spec.allocNodes[nodeId] then
			t_insert(self.activeSocketList, nodeId)
			slot.inactive = false
		else
			slot.inactive = true
		end
	end
	table.sort(self.activeSocketList)

	-- Update the state of the active socket controls
	self.lastSlot = self.slots[baseSlots[#baseSlots]]
	for index, nodeId in ipairs(self.activeSocketList) do
		self.sockets[nodeId].label = "Socket #"..index
		self.lastSlot = self.sockets[nodeId]
	end
	self.initSockets = false
end

-- Returns the slot control and equipped jewel for the given node ID
function ItemsTabClass:GetSocketAndJewelForNodeID(nodeId)
	return self.sockets[nodeId], self.sockets[nodeId] and self.items[self.sockets[nodeId].selItemId] or nil
end

-- Adds the given item to the build's item list
function ItemsTabClass:AddItem(item, noAutoEquip, index)
	if not item.id then
		-- Find an unused item ID
		item.id = 1
		while self.items[item.id] do
			item.id = item.id + 1
		end

		if index then
			t_insert(self.itemOrderList, index, item.id)
		else
			-- Add it to the end of the display order list
			t_insert(self.itemOrderList, item.id)
		end

		if not noAutoEquip then
			-- Autoequip it
			for _, slot in ipairs(self.orderedSlots) do
				if not slot.nodeId and slot.selItemId == 0 and slot:IsShown() and self:IsItemValidForSlot(item, slot.slotName) then
					slot:SetSelItemId(item.id)
					break
				end
			end
		end
	end

	-- Add it to the list
	local replacing = self.items[item.id]
	self.items[item.id] = item
	item:BuildModList()

	if replacing and (replacing.clusterJewel or item.clusterJewel or replacing.baseName == "Timeless Jewel") then
		-- We're replacing an existing item, and either the new or old one is a cluster jewel
		if isValueInTable(self.build.spec.jewels, item.id) then
			-- Item is currently equipped, so we need to rebuild the graphs
			self.build.spec:BuildClusterJewelGraphs()
		end
	end
end

-- Adds the current display item to the build's item list
function ItemsTabClass:AddDisplayItem(noAutoEquip)
	-- Add it to the list and clear the current display item
	self:AddItem(self.displayItem, noAutoEquip)
	self:SetDisplayItem()

	self:PopulateSlots()
	self:AddUndoState()
	self.build.buildFlag = true
end

-- Sorts the build's item list
function ItemsTabClass:SortItemList()
	table.sort(self.itemOrderList, function(a, b)
		local itemA = self.items[a]
		local itemB = self.items[b]
		local primSlotA = itemA:GetPrimarySlot()
		local primSlotB = itemB:GetPrimarySlot()
		if primSlotA ~= primSlotB then
			if not self.slotOrder[primSlotA] then
				return false
			elseif not self.slotOrder[primSlotB] then
				return true
			end
			return self.slotOrder[primSlotA] < self.slotOrder[primSlotB]
		end
		local equipSlotA, equipSetA = self:GetEquippedSlotForItem(itemA)
		local equipSlotB, equipSetB = self:GetEquippedSlotForItem(itemB)
		if equipSlotA and equipSlotB then
			if equipSlotA ~= equipSlotB then
				return self.slotOrder[equipSlotA.slotName] < self.slotOrder[equipSlotB.slotName]
			elseif equipSetA and not equipSetB then
				return false
			elseif not equipSetA and equipSetB then
				return true
			elseif equipSetA and equipSetB then
				return isValueInArray(self.itemSetOrderList, equipSetA.id) < isValueInArray(self.itemSetOrderList, equipSetB.id)
			end
		elseif equipSlotA then
			return true
		elseif equipSlotB then
			return false
		end
		return itemA.name < itemB.name
	end)
	self:AddUndoState()
end

-- Deletes an item
function ItemsTabClass:DeleteItem(item, deferUndoState)
	for slotName, slot in pairs(self.slots) do
		if slot.selItemId == item.id then
			slot:SetSelItemId(0)
			self.build.buildFlag = true
		end
		if not slot.nodeId then
			for _, itemSet in pairs(self.itemSets) do
				if itemSet[slotName].selItemId == item.id then
					itemSet[slotName].selItemId = 0
					self.build.buildFlag = true
				end
			end
		end
	end
	for index, id in pairs(self.itemOrderList) do
		if id == item.id then
			t_remove(self.itemOrderList, index)
			break
		end
	end
	for _, spec in pairs(self.build.treeTab.specList) do
		local rebuildClusterJewelGraphs = false
		for nodeId, itemId in pairs(spec.jewels) do
			if itemId == item.id then
				spec.jewels[nodeId] = 0
				rebuildClusterJewelGraphs = true
				-- Deallocate all nodes that required this jewel
				if spec.nodes[nodeId] then
					for depNodeId, depNode in ipairs(spec.nodes[nodeId].depends) do
						depNode.alloc = false
						spec.allocNodes[depNodeId] = nil
					end
					spec.nodes[nodeId].alloc = false
					spec.allocNodes[nodeId] = nil
				end
			end
		end
		if rebuildClusterJewelGraphs and not deferUndoState then
			spec:BuildClusterJewelGraphs()
		end
	end
	self.items[item.id] = nil
	if not deferUndoState then
		self:PopulateSlots()
		self:AddUndoState()
	end
end

local function isAnointable(item)
	return (item.canBeAnointed or item.base.type == "Amulet")
end

local function isAugmentable(item)
	return (item.sockets and #item.sockets > 0) or (item.base.socketLimit and item.base.socketLimit > 0)
end

function ItemsTabClass:CopyAnointsAndAugments(newItem, copyAugments, overwrite, sourceSlotName)
	local isWeapon = newItem.base.tags and (newItem.base.tags.onehand or newItem.base.tags.twohand)
	local isShield = newItem.base.tags and (newItem.base.tags.shield or newItem.base.tags.focus)
	local newItemType = sourceSlotName or (isWeapon and "Weapon 1") or (isShield and "Weapon 2") or newItem.base.type
	-- tabula rasa has jewel sockets which don't apply here
	if newItem.name == "Tabula Rasa, Garment" then return end
	if self.activeItemSet[newItemType] then
		local currentItem = self.activeItemSet[newItemType].selItemId and self.items[self.activeItemSet[newItemType].selItemId]
		-- if you don't have an equipped item that matches the type of the newItem, no need to do anything
		if currentItem then
			local modifiableItem = not (newItem.corrupted or newItem.mirrored or newItem.sanctified)
			-- if the new item is anointable and does not have an anoint and your current respective item does, apply that anoint to the new item
			if isAnointable(newItem) and (#newItem.enchantModLines == 0 or overwrite) and self.activeItemSet[newItemType].selItemId > 0 and modifiableItem then
				local currentAnoint = currentItem.enchantModLines
				newItem.enchantModLines = currentAnoint
			end

			--https://www.poe2wiki.net/wiki/Augment_socket
			-- augments, given there are enough sockets

			local hasEmptySockets = true
			for i = 1, #newItem.runes do
				if newItem.runes[i] ~= "None" then
					hasEmptySockets = false
					break
				end
			end
			local shouldChangeAugments = copyAugments and isAugmentable(newItem) and
			(#newItem.runes == 0 or hasEmptySockets or overwrite)

			-- current runes sans "None"
			local currentRunes = {}
			for i = 1, #currentItem.runes do
				if currentItem.runes[i] ~= "None" then
					table.insert(currentRunes, currentItem.runes[i])
				end
			end
			-- add sockets, if necessary and possible
			if shouldChangeAugments and isAugmentable(newItem) and modifiableItem and #newItem.sockets < #currentItem.sockets then
				local maxSockets = modifiableItem and math.min(#currentItem.sockets, newItem.base.socketLimit)
				local neededSockets = math.max(0, maxSockets - #newItem.sockets)
				for i = 1, neededSockets do
					table.insert(newItem.runes, "None")
					table.insert(newItem.sockets, { group = #newItem.sockets + 1})
				end
				newItem.itemSocketCount = #newItem.sockets
				newItem:UpdateRunes()
			end

			local validRunes = self:GetValidRunesForItem(newItem)

			-- replace runes with current ones, or set to none
			local skipped = 0
			if shouldChangeAugments then
				for i = 1, #newItem.sockets do
					-- avoid overwriting socket bound runes as removing these from e.g. trade results
					-- will be confusing
					if self:IsSocketBoundRune(newItem, newItem.runes[i], validRunes) then
						-- if the new item has more slots than the old item, we still copy old
						-- runes in order after skipping the socket bound rune
						skipped = skipped + 1
						goto continue
					end
					newItem.runes[i] = "None"
					if currentRunes[i - skipped] then
						for _, rune in ipairs(validRunes) do
							-- we only copy runes which fit the new item type
							if rune.name == currentRunes[i - skipped] then
								newItem.runes[i] = currentRunes[i - skipped]
								break
							end
						end
					end
					::continue::
				end
				newItem:UpdateRunes()
			end

			newItem:BuildAndParseRaw()
		end
	end
end

-- Attempt to create a new item from the given item raw text and sets it as the new display item
function ItemsTabClass:CreateDisplayItemFromRaw(itemRaw, normalise)
	local newItem = new("Item"):Item(itemRaw)
	if newItem.base then
		self:CopyAnointsAndAugments(newItem, main.migrateAugments, false)
		if normalise then
			newItem:NormaliseQuality()
			newItem:BuildModList()
		end
		self:SetDisplayItem(newItem)
	end
end

function ItemsTabClass:SelectDisplayItemVariant(index, value, legacyField, control)
	if self.displayItem:HasVariantGroups() then
		if not value or not value.variantId then
			return
		end
		self.displayItem.variantGroupSelections[control.variantGroupId] = value.variantId
		self.displayItem:NormaliseVariantSelections()
	else
		self.displayItem[legacyField] = index
	end
	self.displayItem:BuildAndParseRaw()
	self:UpdateDisplayItemVariantControls()
	self:UpdateRuneControls()
	self:UpdateDisplayItemTooltip()
	self:UpdateDisplayItemRangeLines()
end

function ItemsTabClass:UpdateDisplayItemVariantControls()
	local item = self.displayItem
	local controls = {
		self.controls.displayItemVariant,
		self.controls.displayItemAltVariant,
		self.controls.displayItemAltVariant2,
		self.controls.displayItemAltVariant3,
		self.controls.displayItemAltVariant4,
		self.controls.displayItemAltVariant5,
	}
	for _, control in ipairs(controls) do
		control.newVariantVisible = false
	end
	if not item or not item:UsesVersionedOrGroupedVariants() then
		return
	end

	self.controls.displayItemVersion.list = item.versionList or { }
	self.controls.displayItemVersion.selIndex = item.selectedVersion or 1
	self.controls.displayItemVersion:CheckDroppedWidth(true)
	if item:HasIndependentVariants() then
		local control = self.controls.displayItemVariant
		control.list = item.variantList
		control.selIndex = item.variant
		control.variantGroupId = nil
		control.newVariantVisible = #item.variantList > 1
		control.newVariantEnabled = #item.variantList > 1
		control:CheckDroppedWidth(true)
		return
	end
	local controlIndex = 1
	for groupId in pairsSortByKey(item.variantGroups) do
		local eligibleOptions = item:GetVariantGroupOptions(groupId, false)
		if #eligibleOptions > 0 then
			local control = controls[controlIndex]
			if not control then
				ConPrintf("Item '%s' has more than 6 variant groups", item.name)
				break
			end
			local availableOptions = item:GetVariantGroupOptions(groupId, true)
			local list = { }
			local selectedIndex
			for _, variantId in ipairs(availableOptions) do
				t_insert(list, {
					label = item.variantList[variantId],
					variantId = variantId,
				})
				if item.variantGroupSelections[groupId] == variantId then
					selectedIndex = #list
				end
			end
			if #list == 0 then
				t_insert(list, {
					label = "No available variants",
				})
			end
			control.list = list
			control.selIndex = selectedIndex or 1
			control.variantGroupId = groupId
			control.newVariantVisible = true
			control.newVariantEnabled = #availableOptions > 1
			control:CheckDroppedWidth(true)
			controlIndex = controlIndex + 1
		end
	end
end

-- Sets the display item to the given item
function ItemsTabClass:SetDisplayItem(item)
	self.displayItem = item
	if item then
		-- Update the display item controls
		self:UpdateDisplayItemTooltip()
		self.snapHScroll = "RIGHT"
		local usesVersionedOrGroupedVariants = item:UsesVersionedOrGroupedVariants()

		if usesVersionedOrGroupedVariants then
			self:UpdateDisplayItemVariantControls()
		else
			self.controls.displayItemVariant.list = item.variantList
			self.controls.displayItemVariant.selIndex = item.variant
			self.controls.displayItemVariant:CheckDroppedWidth(true)
		end
		if not usesVersionedOrGroupedVariants and item.hasAltVariant then
			self.controls.displayItemAltVariant.list = item.variantList
			self.controls.displayItemAltVariant.selIndex = item.variantAlt
			self.controls.displayItemAltVariant:CheckDroppedWidth(true)
		end
		if not usesVersionedOrGroupedVariants and item.hasAltVariant2 then
			self.controls.displayItemAltVariant2.list = item.variantList
			self.controls.displayItemAltVariant2.selIndex = item.variantAlt2
			self.controls.displayItemAltVariant2:CheckDroppedWidth(true)
		end
		if not usesVersionedOrGroupedVariants and item.hasAltVariant3 then
			self.controls.displayItemAltVariant3.list = item.variantList
			self.controls.displayItemAltVariant3.selIndex = item.variantAlt3
			self.controls.displayItemAltVariant3:CheckDroppedWidth(true)
		end
		if not usesVersionedOrGroupedVariants and item.hasAltVariant4 then
			self.controls.displayItemAltVariant4.list = item.variantList
			self.controls.displayItemAltVariant4.selIndex = item.variantAlt4
			self.controls.displayItemAltVariant4:CheckDroppedWidth(true)
		end
		if not usesVersionedOrGroupedVariants and item.hasAltVariant5 then
			self.controls.displayItemAltVariant5.list = item.variantList
			self.controls.displayItemAltVariant5.selIndex = item.variantAlt5
			self.controls.displayItemAltVariant5:CheckDroppedWidth(true)
		end
		if item.crafted then
			self:UpdateAffixControls()
		end
		self.controls.displayItemSocketRuneEdit:SetText(item.itemSocketCount)
		self.controls.displayItemSocketJewelEdit:SetText(item.jewelSocketCount)
		self.controls.displayItemQualityEdit:SetText(item.quality)
		self.controls.displayItemCatalyst:SetSel((item.catalyst or 0) + 1, true)
		if item.catalystQuality then
			self.controls.displayItemCatalystQualityEdit:SetText(m_max(item.catalystQuality, 0))
		else
			self.controls.displayItemCatalystQualityEdit:SetText(0)
		end
		self:UpdateCustomControls()
		self:UpdateRuneControls()
		self:UpdateDisplayItemRangeLines()
		if item.clusterJewel and item.crafted then
			self:UpdateClusterJewelControls()
		end
	else
		self.snapHScroll = "LEFT"
	end
end

function ItemsTabClass:UpdateDisplayItemTooltip()
	self.displayItemTooltip:Clear()
	self:AddItemTooltip(self.displayItemTooltip, self.displayItem)
	self.displayItemTooltip.center = true
end

function ItemsTabClass:ToggleDisplayItemModLine(modLine)
	if not self.displayItem or not modLine then
		return
	end
	modLine.disabled = not modLine.disabled
	self.displayItem:BuildAndParseRaw()
	self:UpdateDisplayItemTooltip()
	self:UpdateDisplayItemRangeLines()
	self:UpdateCustomControls()
	if self.displayItem.crafted then
		self:UpdateAffixControls()
	end
	self.build.buildFlag = true
end

function ItemsTabClass:UpdateClusterJewelControls()
	local item = self.displayItem

	local unavailableSkills = { ["affliction_strength"] = true, ["affliction_dexterity"] = true, ["affliction_intelligence"] = true, }

	-- Update list of skills
	local skillList = wipeTable(self.controls.displayItemClusterJewelSkill.list)
	for skillId, skill in pairs(item.clusterJewel.skills) do
		if not unavailableSkills[skillId] then
			t_insert(skillList, { label = skill.name, skillId = skillId })
		end
	end
	table.sort(skillList, function(a, b) return a.label < b.label end)
	if not item.clusterJewelSkill or not item.clusterJewel.skills[item.clusterJewelSkill] then
		item.clusterJewelSkill = skillList[1].skillId
	end
	self.controls.displayItemClusterJewelSkill:SelByValue(item.clusterJewelSkill, "skillId")

	-- Update added node count slider
	local countControl = self.controls.displayItemClusterJewelNodeCount
	item.clusterJewelNodeCount = m_min(m_max(item.clusterJewelNodeCount or item.clusterJewel.maxNodes, item.clusterJewel.minNodes), item.clusterJewel.maxNodes)
	countControl.divCount = item.clusterJewel.maxNodes - item.clusterJewel.minNodes
	countControl.val = (item.clusterJewelNodeCount - item.clusterJewel.minNodes) / (item.clusterJewel.maxNodes - item.clusterJewel.minNodes)

	self:CraftClusterJewel()
end

function ItemsTabClass:CraftClusterJewel()
	local item = self.displayItem
	wipeTable(item.enchantModLines)
	t_insert(item.enchantModLines, { line = "Adds "..(item.clusterJewelNodeCount or item.clusterJewel.maxNodes).." Passive Skills", enchant = true })
	if item.clusterJewel.size == "Large" then
		t_insert(item.enchantModLines, { line = "2 Added Passive Skills are Jewel Sockets", enchant = true })
	elseif item.clusterJewel.size == "Medium" then
		t_insert(item.enchantModLines, { line = "1 Added Passive Skill is a Jewel Socket", enchant = true })
	end
	local skill = item.clusterJewel.skills[item.clusterJewelSkill]
	t_insert(item.enchantModLines, { line = table.concat(skill.enchant, "\n"), enchant = true })
	item:BuildAndParseRaw()

	-- Update affixes manually to force out affixes that may now be invalid
	self:UpdateAffixControls()
	for i = 1, item.affixLimit do
		local drop = self.controls["displayItemAffix"..i]
		drop.selFunc(drop.selIndex, drop.list[drop.selIndex])
	end
end

-- Update affix selection controls
function ItemsTabClass:UpdateAffixControls()
	local item = self.displayItem
	local prefixLimit = item.prefixes.limit or (item.affixLimit / 2)
	local powerCache = { }
	for i = 1, item.affixLimit do
		if i <= prefixLimit then
			self:UpdateAffixControl(self.controls["displayItemAffix"..i], item, "Prefix", "prefixes", i, powerCache)
		else
			self:UpdateAffixControl(self.controls["displayItemAffix"..i], item, "Suffix", "suffixes", i - prefixLimit, powerCache)
		end
	end
	-- The custom affixes may have had their indexes changed, so the custom control UI is also rebuilt so that it will
	-- reference the correct affix index.
	self:UpdateCustomControls()
end

runeModLines = { { name = "None", label = "None", lines = { "None" }, mods = { }, req = 1, order = -1, slot = "None", group = -1, isSocketBound = false } }
for name, runeMods in pairs(data.itemMods.Runes) do
	-- Some runes have multiple mod lines; insert each as separate entry
	for slotType, runeMod in pairs(runeMods) do
		-- Bonded stats are stored separately for calculation, but remain part of the
		-- visible rune description and are prefixed only at this presentation boundary.
		local lines = { }
		for _, line in ipairs(runeMod) do
			t_insert(lines, line)
		end
		for _, line in ipairs(runeMod.bonded or { }) do
			t_insert(lines, "Bonded: " .. line)
		end
		local mods = { }
		for _, line in ipairs(runeMod) do
			local modList = modLib.parseMod(line)
			for _, mod in ipairs(modList or { }) do
				t_insert(mods, modLib.setSource(mod, "Rune:" .. name))
			end
		end
		local order = (runeMod.statOrder and runeMod.statOrder[1]) or (runeMod.bonded and runeMod.bonded.statOrder and runeMod.bonded.statOrder[1]) or 0
		t_insert(runeModLines, { name = name, label = runeMod[1], lines = lines, mods = mods, req = runeMod.levelReq, order = order, slot = slotType, type = runeMod.type, group = #lines, isSocketBound = runeMod.isSocketBound, localMod = runeMod.localMod, limit = runeMod.limit, canSocketInChakraSlots = runeMod.canSocketInChakraSlots, canSocketInUniqueItems = runeMod.canSocketInUniqueItems, canSocketInJewellery = runeMod.canSocketInJewellery })
	end
end
table.sort(runeModLines, function(a, b)
	if a.order == b.order then
		return a.req < b.req
	elseif a.group == b.group then
		return a.order < b.order
	else
		return a.group < b.group
	end
end)

function ItemsTabClass:GetValidRunesForItem(item)
	local runes = { }
	local addedRunes = { }
	local socketedItemType
	if item.baseModList then
		if item.baseModList:Flag(nil, "SocketedSoulCoresOnly") then
			socketedItemType = "SoulCore"
		elseif item.baseModList:Flag(nil, "SocketedRunesOnly") then
			socketedItemType = "Rune"
		end
	end
	local baseType, specificType = item:GetSocketedAugmentTypes()
	local soulCoreTypes = item.socketedSoulCoreTypes
	local uniqueItem = item.rarity == "UNIQUE" or item.rarity == "RELIC"
	local jewellery = item.type == "Ring" or item.type == "Amulet" or item.type == "Belt"
	for _, rune in ipairs(runeModLines) do
		if rune.slot == "None" then
			t_insert(runes, rune)
		elseif (rune.slot == baseType or rune.slot == specificType or (rune.type == "SoulCore" and soulCoreTypes[rune.slot])) and (not socketedItemType or rune.type == socketedItemType) and (not uniqueItem or rune.canSocketInUniqueItems) and (not jewellery or rune.canSocketInJewellery) then
			local addedRune = addedRunes[rune.name]
			if not addedRune then
				addedRune = copyTable(rune, true)
				addedRune.lines = { }
				t_insert(runes, addedRune)
				addedRunes[rune.name] = addedRune
			end
			addedRune.label = addedRune.label or rune.label
			for _, line in ipairs(rune.lines) do
				t_insert(addedRune.lines, line)
			end
		end
	end
	for _, rune in ipairs(runes) do
		rune.label = rune.label or rune.lines[1]
	end
	return runes
end

function ItemsTabClass:IsSocketBoundRune(item, runeName, validRunes)
	if not runeName or runeName == "None" then
		return false
	end
	for _, rune in ipairs(validRunes or self:GetValidRunesForItem(item)) do
		if rune.name == runeName then
			return rune.isSocketBound or false
		end
	end
	return false
end

-- Update rune selection controls
function ItemsTabClass:UpdateRuneControls()
	local item = self.displayItem
	-- Build rune selection for item
	local runes = self:GetValidRunesForItem(item)
	local runesUpdated = false

	for i = 1, item.itemSocketCount do
		self.controls["displayItemRune"..i].list = runes
		if item.runes[i] then
			local found = false
			for j, modLine in ipairs(self.controls["displayItemRune"..i].list) do
				if item.runes[i] == modLine.name then
					self.controls["displayItemRune"..i].selIndex = j
					found = true
				end
			end
			if not found then
				self.controls["displayItemRune"..i].selIndex = 1
				item.runes[i] = "None"
				runesUpdated = true
			end
		else
			self.controls["displayItemRune"..i].selIndex = 1
		end
	end
	if runesUpdated then
		item:UpdateRunes()
	end
end

function ItemsTabClass:UpdateAffixControl(control, item, affixType, outputTable, outputIndex, powerCache)
	local extraTags = { }
	local excludeGroups = { }
	for _, table in ipairs({"prefixes","suffixes"}) do
		for index = 1, (item[table].limit or (item.affixLimit / 2)) do
			if index ~= outputIndex or table ~= outputTable then
				local mod = item.affixes[item[table][index] and item[table][index].modId]
				if mod then
					if mod.group then
						excludeGroups[mod.group] = true
					end
					if mod.tags then
						for _, tag in ipairs(mod.tags) do
							extraTags[tag] = true
						end
					end
				end
			end
		end
	end
	if item.clusterJewel and item.clusterJewelSkill then
		local skill = item.clusterJewel.skills[item.clusterJewelSkill]
		if skill then
			extraTags[skill.tag] = true
		end
	end
	local affixList = { }
	for modId, mod in pairs(item.affixes) do
		if mod.type == affixType and not excludeGroups[mod.group] and item:GetModSpawnWeight(mod, extraTags) > 0 then
			t_insert(affixList, modId)
		end
	end
	table.sort(affixList, function(a, b)
		local modA = item.affixes[a]
		local modB = item.affixes[b]
		for i = 1, m_max(#modA, #modB) do
			if not modA[i] then
				return true
			elseif not modB[i] then
				return false
			elseif modA.statOrder[i] ~= modB.statOrder[i] then
				return modA.statOrder[i] < modB.statOrder[i]
			end
		end
		return modA.level > modB.level
	end)
	control.selIndex = 1
	control.list = { "None" }
	control.outputTable = outputTable
	control.outputIndex = outputIndex
	control.slider.shown = false
	control.slider.val = main.defaultItemAffixQuality or 0.5
	local selAffix = item[outputTable][outputIndex].modId
	if (item.type == "Jewel" and item.base.subType ~= "Abyss") then
		for i, modId in pairs(affixList) do
			local mod = item.affixes[modId]
			if selAffix == modId then
				control.selIndex = i + 1
			end
			local modString = table.concat(mod, "/")
			local label = modString
			if item.type == "Flask" then
				label = mod.affix .. "   ^8[" .. modString .. "]"
			end
			-- shorten time-lost jewel affix labels to fit the dropdown
			if label and item.baseName:find("Time%-Lost") ~= nil then
				label = label:gsub(" Passive Skills in Radius also grant", ":")
			end
			control.list[i + 1] = {
				label = label,
				modList = { modId },
				modId = modId,
				haveRange = modString:match("%(%-?[%d%.]+%-%-?[%d%.]+%)"),
			}
		end
	else
		local lastSeries
		for _, modId in ipairs(affixList) do
			local mod = item.affixes[modId]
			if not lastSeries or not tableDeepEquals(lastSeries.statOrder, mod.statOrder) then
				local modString = table.concat(mod, "/")
				lastSeries = {
					label = modString,
					modList = { },
					haveRange = modString:match("%(%-?[%d%.]+%-%-?[%d%.]+%)"),
					statOrder = mod.statOrder,
				}
				t_insert(control.list, lastSeries)
			end
			if selAffix == modId then
				control.selIndex = #control.list
			end
			t_insert(lastSeries.modList, 1, modId)
			if #lastSeries.modList == 2 then
				lastSeries.label = lastSeries.label:gsub("%(%-?[%d%.]+%-%-?[%d%.]+%)","#"):gsub("%-?%d+%.?%d*","#")
				lastSeries.haveRange = true
			end
		end
	end
	local sortOption = self.controls.craftingSorting:GetSelValue()
	if sortOption.stat and self.controls.craftingSorting:IsShown() then
		local modList = { }
		for index = 2, #control.list do
			t_insert(modList, control.list[index])
		end
		setDefaultSortOrder(modList)
		local calcFunc = self.build.calcsTab:GetMiscCalculator()
		local slotName = self:GetComparisonSlotNameForItem(item)
		local controlPowerCache = selAffix ~= "None" and { } or powerCache or { }
		sortModList(modList, sortOption.stat, function(listMod)
			local modId = listMod.modList[1 + round((#listMod.modList - 1) * main.defaultItemAffixQuality)]
			local cacheEntry = controlPowerCache[modId]
			if not cacheEntry then
				cacheEntry = { modId = modId }
				controlPowerCache[modId] = cacheEntry
			end
			return getSortedModValue(item, cacheEntry, sortOption, calcFunc, slotName, function(testItem, sortedMod)
				testItem[outputTable][outputIndex] = { modId = sortedMod.modId, range = main.defaultItemAffixQuality }
				testItem:Craft()
			end)
		end)
		wipeTable(control.list)
		t_insert(control.list, "None")
		for _, listMod in ipairs(modList) do
			t_insert(control.list, listMod)
		end
		for index, listMod in ipairs(control.list) do
			if listMod.modList and isValueInArray(listMod.modList, selAffix) then
				control.selIndex = index
				break
			end
		end
	end
	if control.list[control.selIndex].haveRange then
		control.slider.divCount = #control.list[control.selIndex].modList
		local index = isValueInArray(control.list[control.selIndex].modList, selAffix)
		-- Imported legacy rolls can sit outside the current 0-1 affix range.
		-- Keep that value on the affix, but show the nearest slider endpoint.
		local affixRange = item[outputTable][outputIndex].range
		local range = m_min(1, m_max(0, type(affixRange) == "table" and affixRange[1] or affixRange or 0.5))
		-- Avoid exact integer boundary that slider:GetDivVal's ceil would assign to the previous segment
		if range == 0 and index > 1 then
			range = 1e-4
		end
		control.slider.val = (index - 1 + range) / control.slider.divCount
		if control.slider.divCount == 1 then
			control.slider.divCount = nil
		end
		control.slider.shown = true
	end
end

-- Create/update custom modifier controls
function ItemsTabClass:UpdateCustomControls()
	local item = self.displayItem
	local i = 1
	local modLines = copyTable(item.explicitModLines)
	if item.rarity == "MAGIC" or item.rarity == "RARE" then
		for index, modLine in ipairs(modLines) do
			if modLine.custom then
				local line = itemLib.formatModLine(modLine)
				if line then
					if not self.controls["displayItemCustomModifierRemove"..i] then
						self.controls["displayItemCustomModifierRemove" .. i] = new("ButtonControl"):ButtonControl({ "TOPLEFT", self.controls.displayItemSectionCustom, "TOPLEFT" }, { 0, i * 22 + 4, 70, 20 }, "^7Remove")
						self.controls["displayItemCustomModifier" .. i] = new("LabelControl"):LabelControl({ "LEFT", self.controls["displayItemCustomModifierRemove" .. i], "RIGHT" }, { 65, 0, 0, 16 })
						self.controls["displayItemCustomModifierLabel" .. i] = new("LabelControl"):LabelControl({ "LEFT", self.controls["displayItemCustomModifierRemove" .. i], "RIGHT" }, { 5, 0, 0, 16 })
					end
					self.controls["displayItemCustomModifierRemove"..i].shown = true
					local label = itemLib.formatModLine(modLine)
					if DrawStringCursorIndex(16, "VAR", label, 330, 10) < #label then
						label = label:sub(1, DrawStringCursorIndex(16, "VAR", label, 310, 10)) .. "..."
					end
					self.controls["displayItemCustomModifier"..i].label = label
					self.controls["displayItemCustomModifierLabel"..i].label = " ^7Custom:"
					self.controls["displayItemCustomModifierRemove"..i].onClick = function()
						if index <= #item.explicitModLines then
							t_remove(item.explicitModLines, index)
						end
						item:BuildAndParseRaw()
						local id = item.id
						self:CreateDisplayItemFromRaw(item:BuildRaw())
						self.displayItem.id = id
					end
					i = i + 1
				end
			end
		end
	end
	item.customCount = i - 1
	while self.controls["displayItemCustomModifierRemove"..i] do
		self.controls["displayItemCustomModifierRemove"..i].shown = false
		i = i + 1
	end
end

-- Updates the range line dropdown and range slider for the current display item
function ItemsTabClass:UpdateDisplayItemRangeLines()
	if self.displayItem and self.displayItem.rangeLineList[1] then
		wipeTable(self.controls.displayItemRangeLine.list)
		for i, modLine in ipairs(self.displayItem.rangeLineList) do
			if self.controls["displayItemStackedRangeSlider"..i] then
				self.controls["displayItemStackedRangeSlider"..i].val = modLine.range
			end
			-- primarily for Against the Darkness // a way to cut down on really long modLines, gsub could be updated for others
			t_insert(self.controls.displayItemRangeLine.list, (modLine.line:gsub(" Passive Skills in Radius also grant", ":")))
		end
		self.controls.displayItemRangeLine.selIndex = 1
		self.controls.displayItemRangeSlider.val = self.displayItem.rangeLineList[1].range
	end
end

---@param line string
local function checkLineForAllocates(line, nodes)
	if nodes and string.match(line, "Allocates") then
		local nodeId = tonumber(string.match(line, "%d+"))
		if nodes[nodeId] then
			return "Allocates "..nodes[nodeId].name
		end
	end
	return line
end

function ItemsTabClass:AddModComparisonTooltip(tooltip, mod)
	local slotName = self:GetComparisonSlotNameForItem(self.displayItem)
	local newItem = new("Item"):Item(self.displayItem:BuildRaw())

	for _, subMod in ipairs(mod) do
		t_insert(newItem.explicitModLines, { line = checkLineForAllocates(subMod, self.build.spec.nodes), modTags = mod.modTags, [mod.type or "Suffix"] = true })
	end

	newItem:BuildAndParseRaw()

	local calcFunc = self.build.calcsTab:GetMiscCalculator()
	local outputBase = calcFunc({ repSlotName = slotName, repItem = self.displayItem })
	local outputNew = calcFunc({ repSlotName = slotName, repItem = newItem })
	self.build:AddStatComparesToTooltip(tooltip, outputBase, outputNew, "\nAdding this mod will give: ")
end

-- Returns the first slot in which the given item is equipped
function ItemsTabClass:GetEquippedSlotForItem(item)
	for _, slot in ipairs(self.orderedSlots) do
		if not slot.inactive then
			if slot.selItemId == item.id then
				return slot
			end
			for _, itemSetId in ipairs(self.itemSetOrderList) do
				local itemSet = self.itemSets[itemSetId]
				if itemSetId ~= self.activeItemSetId and itemSet[slot.slotName] and itemSet[slot.slotName].selItemId == item.id then
					return slot, itemSet
				end
			end
		end
	end
end

function ItemsTabClass:GetComparisonSlotNameForItem(item)
	local equippedSlot = self:GetEquippedSlotForItem(item)
	if equippedSlot then
		return equippedSlot.slotName
	end
	if item.type == "Jewel" then
		for _, slot in ipairs(self.orderedSlots) do
			if not slot.inactive and slot.selItemId == 0 and slot:IsShown() and self:IsItemValidForSlot(item, slot.slotName) then
				return slot.slotName
			end
		end
	end
	return item:GetPrimarySlot()
end

-- Check if the given item could be equipped in the given slot, taking into account possible conflicts with currently equipped items
-- For example, a shield is not valid for Weapon 2 if Weapon 1 is a staff, and a wand is not valid for Weapon 2 if Weapon 1 is a dagger
function ItemsTabClass:IsItemValidForSlot(item, slotName, itemSet, flagState)
	itemSet = itemSet or self.activeItemSet
	local slotType, slotId = slotName:match("^([%a ]+) (%d+)$")
	if not slotType then
		slotType = slotName
	end
	if slotType == "Jewel" then
		-- Special checks for jewel sockets
		local node = self.build.spec.tree.nodes[tonumber(slotId)] or self.build.spec.nodes[tonumber(slotId)]
		if not node or item.type ~= "Jewel" then
			return false
		elseif node.sinister and (item.rarity == "UNIQUE" or item.rarity == "RELIC") then
			-- Sinister Jewel Sockets can only accept non-unique jewels
			return false
		elseif node.containJewelSocket  then
			if item.rarity == "UNIQUE" or item.rarity == "RELIC" or (item.base and item.base.subType ~= nil) then
				-- Lich socket can only accept basic non-unique jewels
				-- Need to change this to use ModParser if GGG add different conditional ascendancy jewel sockets
				return false
			end
			return true
		elseif node.charmSocket or item.base.subType == "Charm" then
			-- Charm sockets can only have charms, and charms can only be in charm sockets
			if node.charmSocket and item.base.subType == "Charm" then
				return true
			end
			return false
		elseif item.clusterJewel and not node.expansionJewel then
			-- Don't allow cluster jewels in inner sockets
			return false
		elseif not node.expansionJewel or node.expansionJewel.size == 2 then
			-- Outer sockets can fit anything
			return true
		else
			-- Only allow jewels that fit in this socket
			return not item.clusterJewel or item.clusterJewel.sizeIndex <= node.expansionJewel.size
		end
	elseif item.type == "Flask" and slotType == "Flask" then
		if item.baseName:match("Life Flask") and slotName:match("Flask 1") then
			return true
		elseif item.baseName:match("Mana Flask") and slotName:match("Flask 2") then
			return true
		end
	elseif item.base.subType == "Transcendent Arm" and slotType == "Arm" then
		return true
	elseif item.base.subType == "Transcendent Leg" and slotType == "Leg" then
		return true
	elseif item.type == slotType then
		return true
	elseif item.type == "Jewel" and slotName:match("Jewel Socket") and not (item.rarity == "UNIQUE") then
		local parentSlotName = slotName:gsub(" Jewel Socket %d", "") -- Ring 1 Jewel Socket 1 -> Ring 1
		local slotItem = itemSet[parentSlotName] and self.items[itemSet[parentSlotName].selItemId]
		-- Sekhema's Resolve restricts which base jewel can be socketed, other items (Tabula only for now) have no restriction
		if slotItem and (not slotItem.canSocketJewelBase or (slotItem.canSocketJewelBase and slotItem.canSocketJewelBase[item.baseName])) then
			return true
		end
	elseif slotName == "Weapon 1" or slotName == "Weapon 1 Swap" or slotName == "Weapon" then
		return item.base.tags.onehand or item.base.tags.twohand
	elseif slotName == "Weapon 2" or slotName == "Weapon 2 Swap" then
		local weapon1Sel = itemSet[slotName == "Weapon 2" and "Weapon 1" or "Weapon 1 Swap"].selItemId or 0
		local weapon1Base = self.items[weapon1Sel] and self.items[weapon1Sel].base or "Unarmed"
		-- Calcs tab isn't loaded yet when the items tab gets loaded, so assume we have Giant's Blood until proven wrong
		local giantsBlood, instrumentsOfPower, lordOfTheWilds = true, true, true
		if flagState then
			giantsBlood = flagState.giantsBlood
			instrumentsOfPower = flagState.instrumentsOfPower
			lordOfTheWilds = flagState.lordOfTheWilds
		elseif self.build.calcsTab and self.build.calcsTab.mainEnv then
			giantsBlood = self.build.calcsTab.mainEnv.modDB:Flag(nil, "GiantsBlood")
			instrumentsOfPower = self.build.calcsTab.mainEnv.modDB:Flag(nil, "InstrumentsOfPower")
			lordOfTheWilds = self.build.calcsTab.mainEnv.modDB:Flag(nil, "LordOfTheWilds")
		end
		if weapon1Base.type == "Bow" then
			return item.type == "Quiver"
		elseif weapon1Base.type == "Talisman" and lordOfTheWilds then
			return item.type == "Sceptre" and item.rarity ~= "UNIQUE" and item.rarity ~= "RELIC"
		elseif weapon1Base.type == "Staff" and instrumentsOfPower then
			return item.type == "Focus"
		elseif weapon1Base == "Unarmed" or weapon1Base.tags.onehand or (giantsBlood and (weapon1Base.tags.axe or weapon1Base.tags.mace or weapon1Base.tags.sword)) then
			return item.type == "Shield" or item.type == "Focus" or item.type == "Sceptre"
					or (item.base.tags.one_hand_weapon and weapon1Base.type ~= "Wand" and weapon1Base.type ~= "Sceptre" and item.type ~= "Spear")
					or (giantsBlood and (item.base.tags.axe or item.base.tags.mace or item.base.tags.sword))
		end
	end
end

-- Ensure weapon 2 slots remain valid if keystone-dependent restrictions change
function ItemsTabClass:ValidateWeaponSlots(flagState)
	local activeSetChanged = false
	local itemSet = self.activeItemSet
	if itemSet then
		local slotName = itemSet.useSecondWeaponSet and "Weapon 2 Swap" or "Weapon 2"
		local slotData = itemSet[slotName]
		if slotData and slotData.selItemId and slotData.selItemId ~= 0 then
			local item = self.items[slotData.selItemId]
			if not item or not self:IsItemValidForSlot(item, slotName, itemSet, flagState) then
				if self.slots[slotName] then
					self.slots[slotName]:SetSelItemId(0)
				else
					slotData.selItemId = 0
				end
				activeSetChanged = true
			end
		end
	end
	return activeSetChanged
end

-- Opens the item set manager
function ItemsTabClass:OpenItemSetManagePopup()
	local controls = { }
	controls.setList = new("ItemSetListControl"):ItemSetListControl(nil, { -155, 50, 300, 200 }, self)
	controls.sharedList = new("SharedItemSetListControl"):SharedItemSetListControl(nil, { 155, 50, 300, 200 }, self)
	controls.setList.dragTargetList = { controls.sharedList }
	controls.sharedList.dragTargetList = { controls.setList }
	controls.close = new("ButtonControl"):ButtonControl(nil, { 0, 260, 90, 20 }, "Done", function()
		main:ClosePopup()
	end)
	main:OpenPopup(630, 290, "Manage Item Sets", controls)
end

-- Opens the item crafting popup
function ItemsTabClass:CraftItem()
	local controls = { }
	local function makeItem(base)
		local item = new("Item"):Item()
		item.name = base.name
		item.base = base.base
		item.baseName = base.name
		item.charmLimit = base.charmLimit
		item.spiritValue = base.spiritValue
		item.buffModLines = { }
		item.enchantModLines = { }
		item.runeModLines = { }
		item.classRequirementModLines = { }
		item.implicitModLines = { }
		item.explicitModLines = { }
		item.sockets = { }
		item.runes = { }
		if base.base.quality then
			item.quality = 0
		else
			item.quality = nil
		end
		if base.base.socketLimit and (base.base.weapon or base.base.armour or base.base.tags.wand or base.base.tags.staff or base.base.tags.sceptre) then -- must be a martial weapon/armour
			if #item.sockets == 0 then
				for i = 1, base.base.socketLimit do
					t_insert(item.sockets, { group = 0 })
				end
				item.itemSocketCount = #item.sockets
			end
		end
		local raritySel = controls.rarity.selIndex
		if base.base.flask
				or (base.base.type == "Jewel" and base.base.subType == "Charm")
		 		or base.base.type == "Charm"
		then
			if raritySel == 3 then
				raritySel = 2
			end
		end
		if base.base.type == "Transcendent Limb" then
			raritySel = 1
		end
		if raritySel == 2 or raritySel == 3 then
			item.crafted = true
		end
		item.rarity = controls.rarity.list[raritySel].rarity
		if raritySel >= 3 then
			item.title = controls.title.buf:match("%S") and controls.title.buf or "New Item"
		end
		if base.base.implicit then
			local implicitIndex = 1
			for line in base.base.implicit:gmatch("[^\n]+") do
				local modList, extra = modLib.parseMod(line)
				t_insert(item.implicitModLines, { line = line, extra = extra, modList = modList or { }, modTags = base.base.implicitModTypes and base.base.implicitModTypes[implicitIndex] or { } })
				implicitIndex = implicitIndex + 1
			end
		end
		if base.base.variantList then
			item.variantList = copyTable(base.base.variantList, true)
			item.variant = 1
			item.baseLines = { }
		end
		if base.base.type == "Jewel" and base.base.subType == "Radius" then
			item.jewelRadiusLabel = "Small"
		end
		item:NormaliseQuality()
		item:BuildAndParseRaw()
		return item
	end
	controls.rarityLabel = new("LabelControl"):LabelControl({ "TOPRIGHT", nil, "TOPLEFT" }, { 50, 20, 0, 16 }, "^7Rarity:")
	controls.rarity = new("DropDownControl"):DropDownControl(nil, { -80, 20, 100, 18 }, rarityDropList)
	controls.rarity.selIndex = self.lastCraftRaritySel or 3
	controls.title = new("EditControl"):EditControl(nil, { 70, 20, 190, 18 }, "", "Name")
	controls.title.shown = function()
		return controls.rarity.selIndex >= 3
	end
	controls.typeLabel = new("LabelControl"):LabelControl({ "TOPRIGHT", nil, "TOPLEFT" }, { 50, 45, 0, 16 }, "^7Type:")
	controls.type = new("DropDownControl"):DropDownControl({ "TOPLEFT", nil, "TOPLEFT" }, { 55, 45, 295, 18 }, self.build.data.itemBaseTypeList, function(index, value)
		controls.base.list = self.build.data.itemBaseLists[self.build.data.itemBaseTypeList[index]]
		controls.base.selIndex = 1
	end)
	controls.type.selIndex = self.lastCraftTypeSel or 1
	controls.baseLabel = new("LabelControl"):LabelControl({ "TOPRIGHT", nil, "TOPLEFT" }, { 50, 70, 0, 16 }, "Base:")
	controls.base = new("DropDownControl"):DropDownControl({ "TOPLEFT", nil, "TOPLEFT" }, { 55, 70, 200, 18 }, self.build.data.itemBaseLists[self.build.data.itemBaseTypeList[controls.type.selIndex]])
	controls.base.selIndex = self.lastCraftBaseSel or 1
	controls.base.tooltipFunc = function(tooltip, mode, index, value)
		tooltip:Clear()
		if mode ~= "OUT" then
			self:AddItemTooltip(tooltip, makeItem(value), nil, true)
		end
	end
	controls.save = new("ButtonControl"):ButtonControl(nil, { -45, 100, 80, 20 }, "Create", function()
		main:ClosePopup()
		local item = makeItem(controls.base.list[controls.base.selIndex])
		self:SetDisplayItem(item)
		if not item.crafted and item.rarity ~= "NORMAL" then
			self:EditDisplayItemText()
		end
		self.lastCraftRaritySel = controls.rarity.selIndex
		self.lastCraftTypeSel = controls.type.selIndex
		self.lastCraftBaseSel = controls.base.selIndex
	end)
	controls.cancel = new("ButtonControl"):ButtonControl(nil, { 45, 100, 80, 20 }, "Cancel", function()
		main:ClosePopup()
	end)
	main:OpenPopup(370, 130, "Craft Item", controls)
end

-- Opens the item text editor popup
function ItemsTabClass:EditDisplayItemText(alsoAddItem)
	local controls = { }
	local function buildRaw()
		local editBuf = controls.edit.buf
		if editBuf:match("^Item Class: .*\nRarity: ") or editBuf:match("^Rarity: ") then
			return editBuf
		else
			return "Rarity: "..controls.rarity.list[controls.rarity.selIndex].rarity.."\n"..controls.edit.buf
		end
	end
	controls.rarity = new("DropDownControl"):DropDownControl(nil, { -190, 10, 100, 18 }, rarityDropList)
	controls.edit = new("EditControl"):EditControl(nil, { 0, 40, 480, 420 }, "", nil, "^%C\t\n", nil, nil, 14)
	if self.displayItem then
		controls.edit:SetText(self.displayItem:BuildRaw():gsub("Rarity: %w+\n",""))
		controls.rarity:SelByValue(self.displayItem.rarity, "rarity")
	else
		controls.rarity.selIndex = 3
	end
	controls.edit.font = "FIXED"
	controls.edit.pasteFilter = sanitiseText
	controls.save = new("ButtonControl"):ButtonControl(nil, { -45, 470, 80, 20 }, self.displayItem and "Save" or "Create", function()
		local id = self.displayItem and self.displayItem.id
		self:CreateDisplayItemFromRaw(buildRaw(), not self.displayItem)
		self.displayItem.id = id
		if alsoAddItem then
			self:AddDisplayItem()
		end
		main:ClosePopup()
	end, nil, true)
	controls.save.enabled = function()
		local item = new("Item"):Item(buildRaw())
		return item.base ~= nil
	end
	controls.save.tooltipFunc = function(tooltip)
		tooltip:Clear()
		local item = new("Item"):Item(buildRaw())
		if item.base then
			self:AddItemTooltip(tooltip, item, nil, true)
		else
			tooltip:AddLine(14, "The item is invalid.")
			tooltip:AddLine(14, "Check that the item's title and base name are in the correct format.")
			tooltip:AddLine(14, "For Rare and Unique items, the first 2 lines must be the title and base name. E.g.:")
			tooltip:AddLine(14, "Abberath's Horn")
			tooltip:AddLine(14, "Goat's Horn")
			tooltip:AddLine(14, "For Normal and Magic items, the base name must be somewhere in the first line. E.g.:")
			tooltip:AddLine(14, "Scholar's Platinum Kris of Joy")
		end
	end
	controls.cancel = new("ButtonControl"):ButtonControl(nil, { 45, 470, 80, 20 }, "Cancel", function()
		main:ClosePopup()
	end)
	main:OpenPopup(500, 500, self.displayItem and "Edit Item Text" or "Create Custom Item from Text", controls, nil, "edit")
end

---Gets the name of the anointed node on an item
---@param item table @The item to get the anoint from
---@return string @The name of the anointed node, or nil if there is no anoint
function ItemsTabClass:getAnoint(item)
	local result = { }
	if item then
		for _, modList in ipairs{item.enchantModLines} do
			for _, mod in ipairs(modList) do
				local line = mod.line
				local anoint = line:find("Allocates ([a-zA-Z ]+)")
				if anoint then
					local nodeName = line:sub(anoint + string.len("Allocates "))
					t_insert(result, nodeName)
				end
			end
		end
	end
	return result
end

---Returns a copy of the currently displayed item, but anointed with a new node.
---Removes any existing enchantments before anointing. (Anoints are considered enchantments)
---@param node table @The passive tree node to anoint, or nil to just remove existing anoints.
---@return table @The new item
function ItemsTabClass:anointItem(node)
	self.anointEnchantSlot = self.anointEnchantSlot or 1
	local item = new("Item"):Item(self.displayItem:BuildRaw())
	item.id = self.displayItem.id
	if #item.enchantModLines >= self.anointEnchantSlot then
		t_remove(item.enchantModLines, self.anointEnchantSlot)
	end
	if node then
		t_insert(item.enchantModLines, self.anointEnchantSlot, { enchant = true, line = "Allocates " .. node.dn })
	end
	item:BuildAndParseRaw()
	return item
end

---Appends tooltip information for anointing a new passive tree node onto the currently editing item
---@param tooltip table @The tooltip to append into
---@param node table @The passive tree node that will be anointed, or nil to remove the current anoint.
function ItemsTabClass:AppendAnointTooltip(tooltip, node, actionText)
	if not self.displayItem then
		return
	end

	if not actionText then
		actionText = "Anointing"
	end

	local header
	if node then
		if self.build.spec.allocNodes[node.id] then
			tooltip:AddLine(14, "^7"..actionText.." "..node.dn.." changes nothing because this node is already allocated on the tree.")
			return
		end

		local curAnoints = self:getAnoint(self.displayItem)
		if curAnoints and #curAnoints > 0 then
			for _, curAnoint in ipairs(curAnoints) do
				if curAnoint == node.dn then
					tooltip:AddLine(14, "^7"..actionText.." "..node.dn.." changes nothing because this node is already anointed.")
					return
				end
			end
		end

		header = "^7"..actionText.." "..node.dn.." will give you: "
	else
		header = "^7"..actionText.." nothing will give you: "
	end
	local calcFunc = self.build.calcsTab:GetMiscCalculator()
	local repSlotName = self.displayItem:GetPrimarySlot()
	local outputBase = calcFunc({ repSlotName = repSlotName, repItem = self.displayItem })
	local outputNew = calcFunc({ repSlotName = repSlotName, repItem = self:anointItem(node) })
	local numChanges = self.build:AddStatComparesToTooltip(tooltip, outputBase, outputNew, header)
	if node and numChanges == 0 then
		tooltip:AddLine(14, "^7"..actionText.." "..node.dn.." changes nothing.")
	end
end

---Appends tooltip with information about added notable passive node if it would be allocated.
---@param tooltip table @The tooltip to append into
---@param node table @The passive tree node that will be added
function ItemsTabClass:AppendAddedNotableTooltip(tooltip, node)
	local calcFunc, calcBase = self.build.calcsTab:GetMiscCalculator()
	local outputNew = calcFunc({ addNodes = { [node] = true } })
	local numChanges = self.build:AddStatComparesToTooltip(tooltip, calcBase, outputNew, "^7Allocating "..node.dn.." will give you: ")
	if numChanges == 0 then
		tooltip:AddLine(14, "^7Allocating "..node.dn.." changes nothing.")
	end
end

-- Opens the item anointing popup
function ItemsTabClass:AnointDisplayItem(enchantSlot)
	self.anointEnchantSlot = enchantSlot or 1

	local controls = { }
	controls.notableDB = new("NotableDBControl"):NotableDBControl({ "TOPLEFT", nil, "TOPLEFT" }, { 10, 20, 360, 400 }, self, self.build.spec.tree.nodes, "ANOINT")

	local function saveLabel()
		local node = controls.notableDB.selValue
		if node then
			return "Anoint " .. node.dn
		end
		local curAnoints = self:getAnoint(self.displayItem)
		if curAnoints and #curAnoints >= self.anointEnchantSlot then
			return "Remove "..curAnoints[self.anointEnchantSlot]
		end
		return "No Anoint"
	end
	local function saveLabelWidth()
		local label = saveLabel()
		return DrawStringWidth(16, "VAR", label) + 10
	end
	local function saveLabelX()
		local width = saveLabelWidth()
		return -(width + 90) / 2
	end
	controls.save = new("ButtonControl"):ButtonControl({ "BOTTOMLEFT", nil, "BOTTOM" }, { saveLabelX, -4, saveLabelWidth, 20 }, saveLabel, function()
		self:SetDisplayItem(self:anointItem(controls.notableDB.selValue))
		main:ClosePopup()
	end)
	controls.save.tooltipFunc = function(tooltip)
		tooltip:Clear()
		self:AppendAnointTooltip(tooltip, controls.notableDB.selValue)
	end
	controls.close = new("ButtonControl"):ButtonControl({ "TOPLEFT", controls.save, "TOPRIGHT" }, { 10, 0, 80, 20 }, "Cancel", function()
		main:ClosePopup()
	end)
	main:OpenPopup(380, 448, "Anoint Item", controls)
end

-- Opens the item corrupting popup
function ItemsTabClass:CorruptDisplayItem() -- todo implement vaal orb new outcomes this code is for poe 1
	local controls = { }
	local enchantList = { }
	local enchantNum = 2
	local shownExplicits = {}
	local explicitOffset = 0
	local corruptedRanges = {}
	local currentModType = "Corrupted"
	local sourceList = { "Corrupted" }
	local sortList = buildModSortList()

	if self.displayItem.base.type == "Helmet" then
		t_insert(sourceList, "Glimpse of Chaos")
		if self.displayItem.title == "Glimpse of Chaos" then
			currentModType = "SpecialCorrupted"
			enchantNum = 8
		end
	end
	local function buildEnchantList(modType)
		if enchantList[modType] then
			return
		end
		enchantList[modType] = {}
		for modId, mod in pairs(data.itemMods.Corruption) do
			if mod.type == modType and (modType == "SpecialCorrupted" or self.displayItem:GetModSpawnWeight(mod) > 0) then
				t_insert(enchantList[modType], { mod = mod })
			end
		end
		table.sort(enchantList[modType], function(a, b)
			local an = a.mod[1]:lower():gsub("%(.-%)","$"):gsub("[%+%-%%]",""):gsub("%d+","$")
			local bn = b.mod[1]:lower():gsub("%(.-%)","$"):gsub("[%+%-%%]",""):gsub("%d+","$")
			if an ~= bn then
				return an < bn
			else
				return a.mod.level < b.mod.level
			end
		end)
		setDefaultSortOrder(enchantList[modType])
	end
	buildEnchantList("Corrupted")
	buildEnchantList("SpecialCorrupted")
	local function buildList(control, others, modType)
		local selfMod = control.selIndex and control.selIndex > 1 and control.list[control.selIndex].mod
		wipeTable(control.list)
		t_insert(control.list, { label = "None" })
		for _, listMod in ipairs(enchantList[modType]) do
			local mod = listMod.mod
			local alreadySelected = false
			for _, other in ipairs(others) do
				local otherMod = other and other.selIndex and other.selIndex > 1 and other.list[other.selIndex].mod
				if otherMod and mod.group == otherMod.group then
					alreadySelected = true
				end
			end
			if not alreadySelected then
				t_insert(control.list, { label = table.concat(mod, "/"), mod = mod })
			end
		end
		control:SelByValue(selfMod, "mod")
	end
	local function applyCorruptionMods(item, mods)
		local newEnchant = { }
		for _, mod in ipairs(mods) do
			for i, modLine in ipairs(mod) do
				if mod.modTags[1] then
					t_insert(newEnchant, { line = "{tags:" .. table.concat(mod.modTags, ",") .. "}" .. modLine, enchant = true, order = mod.statOrder[i] })
				else
					t_insert(newEnchant, { line = modLine, enchant = true, order = mod.statOrder[i] })
				end
			end
		end

		local temp = {}
		-- currently enchants are always either corruptions or anoints, so we
		-- can just save the anoints
		for _, mod in ipairs(item.enchantModLines) do
			if mod.line:match("Allocates .*") then
				table.insert(temp, mod)
			end
		end
		item.enchantModLines = temp

		if #newEnchant > 0 then
			table.sort(newEnchant, function(a, b)
				return a.order < b.order
			end)
			for i, enchant in ipairs(newEnchant) do
				enchant.order = nil
				t_insert( item.enchantModLines, i, enchant)
			end
		end
	end
	local function sortEnchantList(sortOption)
		if sortOption.stat then
			local slotName = self:GetComparisonSlotNameForItem(self.displayItem)
			local calcFunc = self.build.calcsTab:GetMiscCalculator()
			sortModList(enchantList[currentModType], sortOption.stat, function(listMod)
				return getSortedModValue(self.displayItem, listMod, sortOption, calcFunc, slotName, function(item, sortedMod)
					applyCorruptionMods(item, { sortedMod.mod })
				end)
			end)
		else
			sortModList(enchantList[currentModType])
		end
	end
	local function rebuildEnchantControls(resetSelection)
		for i = 1, 8 do
			local shown = i <= enchantNum
			controls["enchant"..i].shown = shown
			controls["enchant"..i.."Label"].shown = shown
			if shown then
				if resetSelection then
					controls["enchant"..i]:SetSel(1)
				end
				local others = { }
				for j = 1, enchantNum do
					if i ~= j then
						t_insert(others, controls["enchant"..j])
					end
				end
				buildList(controls["enchant"..i], others, currentModType)
			end
		end
	end
	local function corruptItem(enchanting)
		local item = new("Item"):Item(self.displayItem:BuildRaw())
		item.id = self.displayItem.id
		item.corrupted = true
		local mods = { }
		for i = 1, enchantNum do
			local control = controls["enchant"..i]
			if control.selIndex > 1 then
				t_insert(mods, control.list[control.selIndex].mod)
			end
		end
		-- avoid removing corruption mods or rolls so that the user can make a
		-- vaal rolled item with enchants
		if enchanting then
			applyCorruptionMods(item, mods)

		else
			for i, modLine in ipairs(item.explicitModLines) do
				if corruptedRanges[i] ~= 1 then modLine.corruptedRange = corruptedRanges[i] end
			end
		end
		item:BuildAndParseRaw()
		return item
	end
	if self.displayItem.rarity == "UNIQUE" or self.displayItem.rarity == "RELIC" then
		local item = new("Item"):Item(self.displayItem:BuildRaw())
		local offset = 20
		for i, mod in ipairs(item.explicitModLines) do
			-- test if a mod is scalable at all. this will let through mods that scale, but don't actually change within the corrupt range
			local testScaledLine = itemLib.applyRange(mod.line, mod.range or main.defaultItemAffixQuality, mod.valueScalar or 1, 2)
			if not (testScaledLine == mod.line) and item:CheckModLineVariant(mod) then
				local label = ""
				controls["rollRangeValue" .. i] = new("LabelControl"):LabelControl({ "TOPLEFT", nil, "TOPLEFT" }, { 10, 10 + offset, 200, 16 }, "^71.00")
				controls["rollRangeSlider" .. i] = new("SliderControl"):SliderControl({ "LEFT", controls["rollRangeValue" .. i], "RIGHT" }, { 5, 0, 80, 18 }, function(val)
					corruptedRanges[i] = 0.78+round(0.44*val, 2) -- 0.78-1.22
					controls["rollRangeValue"..i].label = "^7"..string.format("%.2f", corruptedRanges[i])
					local label = ""
					for i, line in ipairs(main:WrapString("^7"..itemLib.applyRange(mod.line, mod.range or main.defaultItemAffixQuality, mod.valueScalar or 1, corruptedRanges[i]),16,430)) do
						if i == 1 then
							label = line
						else
							label = label.."\n"..line
						end
					end
					controls["rollRangeLabel"..i].label = label
				end)
				corruptedRanges[i] = mod.corruptedRange or 1
				controls["rollRangeSlider"..i].val = ((corruptedRanges[i])-0.78)/0.44
				controls["rollRangeValue"..i].label = "^7"..string.format("%.2f", corruptedRanges[i])
				for i, line in ipairs(main:WrapString("^7"..itemLib.applyRange(mod.line, mod.range or main.defaultItemAffixQuality, mod.valueScalar or 1, corruptedRanges[i]),16,430)) do
					if i == 1 then
						label = line
					else
						offset = offset + 16
						label = label.."\n"..line
					end
				end
				controls["rollRangeLabel" .. i] = new("LabelControl"):LabelControl({ "LEFT", controls["rollRangeSlider" .. i], "RIGHT" }, { 5, 0, 200, 16 }, label)
				-- hide them by default as they are a secondary window
				controls["rollRangeLabel"..i].shown = false
				controls["rollRangeSlider"..i].shown = false
				controls["rollRangeValue"..i].shown = false
				offset = offset + 20
				t_insert(shownExplicits, i)
			end
		end
		explicitOffset = offset
	end
	controls.enchants = new("ButtonControl"):ButtonControl({ "TOPLEFT", nil, "TOPLEFT" }, { 5, 5, 80, 20 }, "Enchants", function()
		for i = 1, enchantNum do
			controls["enchant"..i].shown = true
			controls["enchant"..i.."Label"].shown = true
		end
		for _, i in ipairs(shownExplicits) do
			controls["rollRangeLabel"..i].shown = false
			controls["rollRangeSlider"..i].shown = false
			controls["rollRangeValue"..i].shown = false
		end
		controls.source.shown = true
		controls.sourceLabel.shown = true
		controls.sort.shown = true
		controls.sortLabel.shown = true
		main.popups[1].height = 103 + 20 * enchantNum
		controls.close.y = 73 + 20 * enchantNum
		controls.save.y = 73 + 20 * enchantNum
	end)
	controls.enchants.shown = function ()
		return self.displayItem.rarity == "UNIQUE" or self.displayItem.rarity == "RELIC"
	end
	controls.rolls = new("ButtonControl"):ButtonControl({ "LEFT", controls.enchants, "RIGHT" }, { 5, 0, 80, 20 }, "Roll Ranges", function()
		for i = 1, 8 do
			controls["enchant"..i].shown = false
			controls["enchant"..i.."Label"].shown = false
		end
		for _, i in ipairs(shownExplicits) do
			controls["rollRangeLabel"..i].shown = true
			controls["rollRangeSlider"..i].shown = true
			controls["rollRangeValue"..i].shown = true
		end
		controls.source.shown = false
		controls.sourceLabel.shown = false
		controls.sort.shown = false
		controls.sortLabel.shown = false
		main.popups[1].height = 55 + explicitOffset
		controls.close.y = 25 + explicitOffset
		controls.save.y = 25 + explicitOffset
	end)
	controls.rolls.shown = function ()
		return self.displayItem.rarity == "UNIQUE" or self.displayItem.rarity == "RELIC"
	end
	controls.sourceLabel = new("LabelControl"):LabelControl({ "TOPRIGHT", nil, "TOPLEFT" }, { 95, 30, 0, 16 }, "^7Source:")
	controls.source = new("DropDownControl"):DropDownControl({ "TOPLEFT", nil, "TOPLEFT" }, { 100, 30, 150, 18 }, sourceList, function(index, value)
		if value == "Corrupted" then
			currentModType = "Corrupted"
			enchantNum = 2
		elseif value == "Glimpse of Chaos" and self.displayItem.base.type == "Helmet" then -- special corruption enchants
			currentModType = "SpecialCorrupted"
			if self.displayItem.title == "Glimpse of Chaos" then -- glimpse of chaos can have all 8 special enchants
				enchantNum = 8
			else -- other helmets can have 2
				enchantNum = 2
			end
		end
		if controls.sort then
			sortEnchantList(controls.sort:GetSelValue())
		end
		rebuildEnchantControls(true)
		main.popups[1].height = 103 + 20 * enchantNum
		controls.close.y = 73 + 20 * enchantNum
		controls.save.y = 73 + 20 * enchantNum
	end)
	controls.source:SelByValue(currentModType == "SpecialCorrupted" and "Glimpse of Chaos" or "Corrupted")
	controls.sortLabel = new("LabelControl"):LabelControl({ "TOPRIGHT", nil, "TOPLEFT" }, { 350, 30, 0, 16 }, "^7Sort by:")
	controls.sort = new("DropDownControl"):DropDownControl({ "TOPLEFT", nil, "TOPLEFT" }, { 355, 30, 240, 18 }, sortList, function(index, value)
		sortEnchantList(value)
		rebuildEnchantControls()
	end)
	for i = 1, 8 do
		if i == 1 then
			controls.enchant1Label = new("LabelControl"):LabelControl({ "TOPRIGHT", nil, "TOPLEFT" }, { 95, 55, 0, 16 }, function()
				if enchantNum == 1 then -- update label so 1 doesn't appear in case of 1 enchant.
					return "^7Enchant:"
				else
					return "^7Enchant #1:"
				end
			end)
		else
			controls["enchant" .. i .. "Label"] = new("LabelControl"):LabelControl({ "TOPRIGHT", nil, "TOPLEFT" }, { 95, 35 + i * 20, 0, 16 }, "^7Enchant #" .. i .. ":")
		end
		controls["enchant" .. i] = new("DropDownControl"):DropDownControl({ "TOPLEFT", nil, "TOPLEFT" }, { 100, 35 + i * 20, 440, 18 }, nil, function()
			rebuildEnchantControls()
		end)
		controls["enchant"..i].tooltipFunc = function(tooltip, mode, index, value)
			tooltip:Clear()
			if mode ~= "OUT" and value and value.mod then
				for _, line in ipairs(value.mod) do
					tooltip:AddLine(16, "^7"..line)
				end
				self:AddModComparisonTooltip(tooltip, value.mod)
			end
		end
	end
	rebuildEnchantControls()
	controls.save = new("ButtonControl"):ButtonControl(nil, { -45, 69 + enchantNum * 20, 80, 20 }, "Corrupted", function()
		self:SetDisplayItem(corruptItem(controls.enchant1.shown))
		main:ClosePopup()
	end)
	controls.save.tooltipFunc = function(tooltip)
		tooltip:Clear()
		self:AddItemTooltip(tooltip, corruptItem(controls.enchant1.shown))
	end
	controls.close = new("ButtonControl"):ButtonControl(nil, { 45, 69 + enchantNum * 20, 80, 20 }, "Cancel", function()
		main:ClosePopup()
	end)
	main:OpenPopup(620, 103 + enchantNum * 20, "Corrupted Item", controls)
end

-- Opens the custom modifier popup
function ItemsTabClass:AddCustomModifierToDisplayItem()
	local controls = { }
	local sourceList = { }
	local modList = { }
	local sortList = buildModSortList()
	local function applySort(sortOption, selectFirst)
		if not controls.modSelect or not controls.modSelect:IsShown() then
			return
		end
		local selected = not selectFirst and modList[controls.modSelect.selIndex] or nil
		if sortOption.stat then
			local slotName = self:GetComparisonSlotNameForItem(self.displayItem)
			local calcFunc = self.build.calcsTab:GetMiscCalculator()
			sortModList(modList, sortOption.stat, function(listMod)
				return getSortedModValue(self.displayItem, listMod, sortOption, calcFunc, slotName, function(item, sortedMod)
					for _, line in ipairs(sortedMod.mod) do
						t_insert(item.explicitModLines, { line = checkLineForAllocates(line, self.build.spec.nodes), modTags = sortedMod.mod.modTags, [sortedMod.type] = true })
					end
				end)
			end)
		else
			sortModList(modList)
		end
		controls.modSelect:UpdateSearch()
		if selected then
			for index, listMod in ipairs(modList) do
				if listMod == selected then
					controls.modSelect.selIndex = index
					break
				end
			end
		else
			controls.modSelect:SetSel(1, true)
		end
	end
	---Mutates modList to contain mods from the specified source
	---@param sourceId string @The crafting source id to build the list of mods for
	local function buildMods(sourceId)
		wipeTable(modList)
		if sourceId == "PREFIX" or sourceId == "SUFFIX" then -- might be implied.
			for _, mod in pairs(self.displayItem.affixes) do
				if sourceId:lower() == mod.type:lower() and self.displayItem:GetModSpawnWeight(mod) > 0 then
					t_insert(modList, {
						label = mod.affix .. "   ^8[" .. table.concat(mod, "/") .. "]",
						mod = mod,
						type = "custom",
					})
				end
			end
			table.sort(modList, function(a, b)
				local modA = a.mod
				local modB = b.mod
				for i = 1, m_max(#modA, #modB) do
					if not modA[i] then
						return true
					elseif not modB[i] then
						return false
					elseif modA.statOrder[i] ~= modB.statOrder[i] then
						return modA.statOrder[i] < modB.statOrder[i]
					end
				end
				return modA.level > modB.level
			end)
		elseif sourceId == "ESSENCE" then
			local itemType = (self.displayItem.type == "Staff" and self.displayItem.base.subType) or self.displayItem.type
			for _, essence in pairs(self.build.data.essences) do
				local modId = essence.mods[itemType]
				if modId then
					local mod = self.displayItem.affixes[modId] or data.itemMods.Exclusive[modId]
					if mod then -- passive_hash mods don't get described
						t_insert(modList, {
							label = essence.name .. "   " .. "^8[" .. table.concat(mod, "/") .. "]" .. " (" .. (mod.type or "Suffix") .. ")",
							mod = mod,
							type = "custom",
							essence = essence,
						})
					end
				end
			end
			table.sort(modList, function(a, b)
				if a.essence.type ~= b.essence.type then
					return a.essence.type > b.essence.type
				else
					return a.essence.tierLevel > b.essence.tierLevel
				end
			end)
		elseif sourceId == "EMOTION" then
			local radiusJewel = not not (self.displayItem.base.subType and self.displayItem.base.subType:match("Radius"))
			local baseColour
			for _, itemName in ipairs({ "Ruby", "Emerald", "Sapphire", "Diamond" }) do
				if self.displayItem.baseName:match(itemName) then
					baseColour = itemName
					break
				end
			end
			if baseColour then
				for _, emotion in pairs(data.emotions) do
					if emotion.radiusJewel == radiusJewel then
						for modType, modId in pairs(emotion.mods[baseColour] or {}) do
							local mod = data.itemMods.Jewel[modId]
							if mod then
								t_insert(modList, {
									label = string.format("%s ^8[%s] (%s)", emotion.name, table.concat(mod, "/"),
										mod.type or ""),
									mod = mod,
									type = "custom",
									emotion = emotion,
								})
							end
						end
					end
				end
				table.sort(modList, function(a, b)
					if a.emotion.tierLevel ~= b.emotion.tierLevel then
						return a.emotion.tierLevel > b.emotion.tierLevel
					else
						return a.emotion.name > b.emotion.name
					end
				end)
			end
		elseif sourceId == "DESECRATED" then
			local function isDesecratedMod(mod)
				for _, tag in ipairs(mod.modTags or { }) do
					if tag == "ulaman_mod" or tag == "amanamu_mod" or tag == "kurgal_mod" or tag == "unveiled_mod" then
						return true
					end
				end
			end
			for _, mod in pairs(self.displayItem.affixes) do -- Normal mods for the item can be desecrated as well.
				if (mod.type == "Prefix" or mod.type == "Suffix") and self.displayItem:GetModSpawnWeight(mod) > 0 then
					t_insert(modList, {
						label = mod.affix .. "   ^8[" .. table.concat(mod, "/") .. "]",
						mod = mod,
						type = "desecrated",
					})
				end
			end
			for _, mod in pairs(self.build.data.itemMods.Desecrated) do
				if isDesecratedMod(mod) and self.displayItem:GetModSpawnWeight(mod) > 0 then
					t_insert(modList, {
						label = mod.affix .. "   " .. "^8[" .. table.concat(mod, "/") .. "]" .. " (" .. (mod.type or "Suffix") .. ") (Desecrated)",
						mod = mod,
						type = "desecrated",
						desecratedSpecific = true,
					})
				end
			end
			table.sort(modList, function(a, b)
				local modA = a.mod
				local modB = b.mod

				-- Desecrated specific mods always come first
				if a.desecratedSpecific ~= b.desecratedSpecific then
					return a.desecratedSpecific == true
				end

				for i = 1, m_max(#modA.statOrder or 0, #modB.statOrder or 0) do
					local statA = modA.statOrder and modA.statOrder[i]
					local statB = modB.statOrder and modB.statOrder[i]

					if not statA then
						return true
					elseif not statB then
						return false
					elseif statA ~= statB then
						return statA < statB
					end
				end
				return (modA.level or 0) > (modB.level or 0)
			end)
		end
		setDefaultSortOrder(modList)
	end
	if not self.displayItem.crafted then
		t_insert(sourceList, { label = "Prefix", sourceId = "PREFIX" })
		t_insert(sourceList, { label = "Suffix", sourceId = "SUFFIX" })
	end
	buildMods("DESECRATED")
	local hasDesecratedMods = #modList > 0
	buildMods("ESSENCE") 	-- This is technically a waste if there aren't any essence mods,
									-- but it makes it so we don't have to maintain a list of applicable essence-able base types
	if #modList > 0 then
		t_insert(sourceList, { label = "Essence", sourceId = "ESSENCE" })
	end
	if hasDesecratedMods then
		t_insert(sourceList, { label = "Desecrated", sourceId = "DESECRATED" })
	end
	if self.displayItem.base.type == "Jewel" then
		buildMods("EMOTION")
		if #modList > 0 then
			t_insert(sourceList, { label = "Emotion", sourceId = "EMOTION" })
		end
	end
	t_insert(sourceList, { label = "Custom", sourceId = "CUSTOM" })
	buildMods(sourceList[1].sourceId)
	local function addModifier()
		local item = new("Item"):Item(self.displayItem:BuildRaw())
		item.id = self.displayItem.id
		local sourceId = sourceList[controls.source.selIndex].sourceId
		if sourceId == "CUSTOM" then
			if controls.custom.buf:match("%S") then
				t_insert(item.explicitModLines, { line = controls.custom.buf, custom = true })
			end
		elseif sourceId == "DESECRATED" then
			local listMod = modList[controls.modSelect.selIndex]
			for _, line in ipairs(listMod.mod) do
				t_insert(item.explicitModLines, { line = line, modTags = listMod.mod.modTags, [listMod.type] = true, custom = true })
			end
		else
			local listMod = modList[controls.modSelect.selIndex]
			for _, line in ipairs(listMod.mod) do
				t_insert(item.explicitModLines, { line = line, modTags = listMod.mod.modTags, [listMod.type] = true })
			end
		end
		item:BuildAndParseRaw()
		return item
	end
	controls.sourceLabel = new("LabelControl"):LabelControl({ "TOPRIGHT", nil, "TOPLEFT" }, { 95, 20, 0, 16 }, "^7Source:")
	controls.source = new("DropDownControl"):DropDownControl({ "TOPLEFT", nil, "TOPLEFT" }, { 100, 20, 150, 18 }, sourceList, function(index, value)
		buildMods(value.sourceId)
		controls.modSelect:SetSel(1)
		if controls.sort then
			applySort(controls.sort:GetSelValue(), true)
		end
	end)
	controls.source.enabled = #sourceList > 1
	controls.sortLabel = new("LabelControl"):LabelControl({ "TOPRIGHT", nil, "TOPLEFT" }, { 350, 20, 0, 16 }, "^7Sort by:")
	controls.sortLabel.shown = function()
		return sourceList[controls.source.selIndex].sourceId ~= "CUSTOM"
	end
	controls.sort = new("DropDownControl"):DropDownControl({ "TOPLEFT", nil, "TOPLEFT" }, { 355, 20, 240, 18 }, sortList, function(index, value)
		applySort(value, true)
	end)
	controls.sort.shown = function()
		return sourceList[controls.source.selIndex].sourceId ~= "CUSTOM"
	end
	controls.modSelectLabel = new("LabelControl"):LabelControl({ "TOPRIGHT", nil, "TOPLEFT" }, { 95, 45, 0, 16 }, "^7Modifier:")
	controls.modSelect = new("DropDownControl"):DropDownControl({ "TOPLEFT", nil, "TOPLEFT" }, { 100, 45, 600, 18 }, modList)
	controls.modSelect.shown = function()
		return sourceList[controls.source.selIndex].sourceId ~= "CUSTOM"
	end
	controls.modSelect.tooltipFunc = function(tooltip, mode, index, value)
		tooltip:Clear()
		if mode ~= "OUT" and value then
			for _, line in ipairs(value.mod) do
				tooltip:AddLine(16, "^7"..line)
			end
			self:AddModComparisonTooltip(tooltip, value.mod)
		end
	end
	controls.custom = new("EditControl"):EditControl({ "TOPLEFT", nil, "TOPLEFT" }, { 100, 45, 440, 18 })
	controls.custom.shown = function()
		return sourceList[controls.source.selIndex].sourceId == "CUSTOM"
	end
	controls.save = new("ButtonControl"):ButtonControl(nil, { -45, 75, 80, 20 }, "Add", function()
		self:SetDisplayItem(addModifier())
		main:ClosePopup()
	end)
	controls.save.tooltipFunc = function(tooltip)
		tooltip:Clear()
		self:AddItemTooltip(tooltip, addModifier())
	end
	controls.close = new("ButtonControl"):ButtonControl(nil, { 45, 75, 80, 20 }, "Cancel", function()
		main:ClosePopup()
	end)
	main:OpenPopup(710, 105, "Add Modifier to Item", controls, "save", sourceList[controls.source.selIndex].sourceId == "CUSTOM" and "custom")
end

function ItemsTabClass:AddItemSetTooltip(tooltip, itemSet)
	for _, slot in ipairs(self.orderedSlots) do
		if not slot.nodeId then
			local item = self.items[itemSet[slot.slotName].selItemId]
			if item then
				tooltip:AddLine(16, s_format("^7%s: %s%s", slot.slotName, colorCodes[item.rarity], item.name))
			end
		end
	end
end

function ItemsTabClass:SetTooltipHeaderInfluence(tooltip, item)
	tooltip.influenceHeader1 = nil
	tooltip.influenceHeader2 = nil
	-- Fractured items don't have the icon now, they did on trade before 0.3. Maybe they will return.
	--if item.fractured then
	--	tooltip.influenceHeader1 = "Fractured"
	--end
	if item.desecrated then
		if not tooltip.influenceHeader1 then
			tooltip.influenceHeader1 = "Desecrated"
		else
			tooltip.influenceHeader2 = "Desecrated"
		end
	end
	if item.mutated then
		if not tooltip.influenceHeader1 then
			tooltip.influenceHeader1 = "Mutated"
		else
			tooltip.influenceHeader2 = "Mutated"
		end
	end
	-- If only one influence, we copy to second header. Preparing for dual influence mods like in first game.
	if tooltip.influenceHeader1 and not tooltip.influenceHeader2 then
		tooltip.influenceHeader2 = tooltip.influenceHeader1
	end
end

function ItemsTabClass:FormatItemSource(text)
	return text:gsub("unique{([^}]+)}",colorCodes.UNIQUE.."%1"..colorCodes.SOURCE)
			   :gsub("normal{([^}]+)}",colorCodes.NORMAL.."%1"..colorCodes.SOURCE)
			   :gsub("currency{([^}]+)}",colorCodes.CURRENCY.."%1"..colorCodes.SOURCE)
			   :gsub("prophecy{([^}]+)}",colorCodes.PROPHECY.."%1"..colorCodes.SOURCE)
end

function ItemsTabClass:AddItemTooltip(tooltip, item, slot, dbMode, maxWidth)
	local fontSizeSmall = main.showFlavourText and 16 or 14
	local fontSizeBig = main.showFlavourText and 18 or 16
	local fontSizeTitle = main.showFlavourText and 22 or 20
	local rarityCode = colorCodes[item.rarity]
	tooltip.maxWidth = m_min(maxWidth or 600, 600) -- Cap very long lines. Can use a narrower width for small viewports
	tooltip.tooltipHeader = item.rarity
	tooltip.center = true
	tooltip.color = rarityCode
	-- Shared items can use old base names that no longer exist. Add a tooltip so they can be copied or removed without causing a crash.
	if not item.base or not item.baseName then
		tooltip:AddLine(fontSizeTitle, rarityCode..(item.title or item.name or "Unknown Item"), "FONTIN SC")
		tooltip:AddSeparator(30)
		tooltip:AddLine(fontSizeTitle, colorCodes.NEGATIVE.."Item base is not supported by the current version.", "FONTIN SC")
		return
	end
	-- Item name
	if item.title then
		tooltip:AddLine(fontSizeTitle, rarityCode..item.title, "FONTIN SC")
		tooltip:AddLine(fontSizeTitle, rarityCode..item.baseName:gsub(" %(.+%)",""), "FONTIN SC")
	else
		tooltip:AddLine(fontSizeTitle, rarityCode..item.namePrefix..item.baseName:gsub(" %(.+%)","")..item.nameSuffix, "FONTIN SC")
	end
	tooltip.runicItem = item.runicItem
	tooltip:AddSeparator(10)

	-- Special fields for database items
	if dbMode then
		if item:UsesVersionedOrGroupedVariants() then
			if item.versionList and item.selectedVersion then
				tooltip:AddLine(fontSizeBig, "^xFFFF30Version: " .. item.versionList[item.selectedVersion], "FONTIN SC")
			end
			if item:HasIndependentVariants() then
				tooltip:AddLine(fontSizeBig, "^xFFFF30Variant: " .. item.variantList[item.variant], "FONTIN SC")
			else
				local selectedVariants = { }
				for groupId in pairsSortByKey(item.variantGroups) do
					local variantId = item.variantGroupSelections[groupId]
					if variantId and item:IsVariantGroupOptionEligible(groupId, variantId) then
						t_insert(selectedVariants, item.variantList[variantId])
					end
				end
				if #selectedVariants > 0 then
					tooltip:AddLine(fontSizeBig, "^xFFFF30Variants: " .. table.concat(selectedVariants, ", "), "FONTIN SC")
				end
			end
		elseif item.variantList then
			if #item.variantList == 1 then
				tooltip:AddLine(fontSizeBig, "^xFFFF30Variant: "..item.variantList[1], "FONTIN SC")
			else
				tooltip:AddLine(fontSizeBig, "^xFFFF30Variant: "..item.variantList[item.variant].." ("..#item.variantList.." variants)", "FONTIN SC")
			end
		end
		if item.league then
			tooltip:AddLine(fontSizeBig, "^xFF5555Exclusive to: "..item.league, "FONTIN SC")
		end
		if item.unreleased then
			tooltip:AddLine(fontSizeBig, colorCodes.NEGATIVE.."Not yet available", "FONTIN SC")
		end
		if item.source then
			tooltip:AddLine(fontSizeBig, colorCodes.SOURCE.."Source: "..self:FormatItemSource(item.source), "FONTIN SC")
		end
		if item.upgradePaths then
			for _, path in ipairs(item.upgradePaths) do
				tooltip:AddLine(fontSizeBig, colorCodes.SOURCE..self:FormatItemSource(path), "FONTIN SC")
			end
		end
		tooltip:AddSeparator(10)
	end

	local base = item.base
	local slotNum = slot and slot.slotNum or (IsKeyDown("SHIFT") and 2 or 1)
	local modList = item.modList or item.slotModList[slotNum]

	-- Find matching flavour entry and extract origin ONCE
	local itemOrigin = nil
	local flavourText = nil
	if item.rarity == "UNIQUE" or item.rarity == "RELIC" or item.base.type == "Transcendent Limb" then
		if main.showFlavourText then
			local flavourTable
			if item.base.type == "Transcendent Limb" then
				flavourTable = flavourLookup["Transcendent Limb"]
			else
				flavourTable = flavourLookup[item.title]
			end
			if flavourTable then
				local flavour = nil

				if item.title == "Grand Spectrum" then
					local selectedFlavourId = nil
					local baseName = item.baseName
					if baseName == "Ruby" then
						selectedFlavourId = "FourUniqueJewel1"
					elseif baseName == "Emerald" then
						selectedFlavourId = "FourUniqueJewel2"
					elseif baseName == "Sapphire" then
						selectedFlavourId = "FourUniqueJewel3"
					end
					if selectedFlavourId then
						flavour = flavourTable[selectedFlavourId]
					end

				else
					for _, text in pairs(flavourTable) do
						flavour = text
						break
					end
				end

				if flavour then
					if flavour.origin then
						itemOrigin = flavour.origin
					end
					flavourText = flavour.text or flavour
				end
			end
		end
	end

	-- Combine base type with origin if available
	local typeStr = base.weapon and self.build.data.weaponTypeInfo[base.type].label or base.type
	if itemOrigin then
		typeStr = itemOrigin .. " " .. typeStr
		if itemOrigin == "Vaal" then
			item.mutated = true
		end
	end
	self:SetTooltipHeaderInfluence(tooltip, item)
	tooltip:AddLine(fontSizeBig, s_format("^x7F7F7F%s", typeStr), "FONTIN SC")
	if item.quality and item.quality > 0 then
		tooltip:AddLine(fontSizeBig, s_format("^x7F7F7FQuality: "..colorCodes.MAGIC.."+%d%%", item.quality), "FONTIN SC")
	end

	if item.charmLimit then
		tooltip:AddLine(fontSizeBig, s_format("^x7F7F7FCharm Slots: "..main:StatColor(item.charmLimit, base.charmLimit).."%d", item.charmLimit), "FONTIN SC")
	end
	if item.spiritValue then
		tooltip:AddLine(fontSizeBig, s_format("^x7F7F7FSpirit: "..main:StatColor(item.spiritValue, base.spirit).."%d", item.spiritValue), "FONTIN SC")
	end

	if base.weapon then
		-- Weapon-specific info
		local weaponData = item.weaponData[slotNum]
		local totalDamageTypes = 0
		if weaponData.PhysicalDPS then
			tooltip:AddLine(fontSizeBig, s_format("^x7F7F7FPhysical Damage: "..colorCodes.MAGIC.."%d-%d (%.1f DPS)", weaponData.PhysicalMin, weaponData.PhysicalMax, weaponData.PhysicalDPS), "FONTIN SC")
			totalDamageTypes = totalDamageTypes + 1
		end
		if weaponData.ElementalDPS then
			local elemLine
			for _, var in ipairs({"Fire","Cold","Lightning"}) do
				if weaponData[var.."DPS"] then
					elemLine = elemLine and elemLine.."^x7F7F7F, " or "^x7F7F7FElemental Damage: "
					elemLine = elemLine..s_format("%s%d-%d", colorCodes[var:upper()], weaponData[var.."Min"], weaponData[var.."Max"], "FONTIN SC")
				end
			end
			tooltip:AddLine(fontSizeBig, elemLine, "FONTIN SC")
			tooltip:AddLine(fontSizeBig, s_format("^x7F7F7FElemental DPS: "..colorCodes.MAGIC.."%.1f", weaponData.ElementalDPS), "FONTIN SC")
			totalDamageTypes = totalDamageTypes + 1
		end
		if weaponData.ChaosDPS then
			tooltip:AddLine(fontSizeBig, s_format("^x7F7F7FChaos Damage: "..colorCodes.CHAOS.."%d-%d "..colorCodes.MAGIC.."(%.1f DPS)", weaponData.ChaosMin, weaponData.ChaosMax, weaponData.ChaosDPS), "FONTIN SC")
			totalDamageTypes = totalDamageTypes + 1
		end
		if totalDamageTypes > 1 then
			tooltip:AddLine(fontSizeBig, s_format("^x7F7F7FTotal DPS: "..colorCodes.MAGIC.."%.1f", weaponData.TotalDPS), "FONTIN SC")
		end
		tooltip:AddLine(fontSizeBig, s_format("^x7F7F7FCritical Hit Chance: %s%.2f%%", main:StatColor(weaponData.CritChance, base.weapon.CritChanceBase), weaponData.CritChance), "FONTIN SC")
		tooltip:AddLine(fontSizeBig, s_format("^x7F7F7FAttacks per Second: %s%.2f", main:StatColor(weaponData.AttackRate, base.weapon.AttackRateBase), weaponData.AttackRate), "FONTIN SC")
		if weaponData.ReloadTime then
			tooltip:AddLine(fontSizeBig, s_format("^x7F7F7FReload Time: %s%.2f", main:StatColor(weaponData.ReloadTime, base.weapon.ReloadTimeBase), weaponData.ReloadTime), "FONTIN SC")
		end
		if weaponData.range < 120 then
			tooltip:AddLine(fontSizeBig, s_format("^x7F7F7FWeapon Range: %s%.1f ^x7F7F7Fmetres", main:StatColor(weaponData.range, base.weapon.Range), weaponData.range / 10), "FONTIN SC")
		end
	elseif base.armour then
		-- Armour-specific info
		local armourData = item.armourData
		local level = self.build.characterLevel
		local armour = item:GetArmourDataValue("Armour", level)
		local evasion = item:GetArmourDataValue("Evasion", level)
		local energyShield = item:GetArmourDataValue("EnergyShield", level)
		local ward = item:GetArmourDataValue("Ward", level)
		if base.armour.BlockChance and armourData.BlockChance > 0 then
			tooltip:AddLine(fontSizeBig, s_format("^x7F7F7FChance to Block: %s%d%%", main:StatColor(armourData.BlockChance, base.armour.BlockChance), armourData.BlockChance), "FONTIN SC")
		end
		if armour > 0 then
			tooltip:AddLine(fontSizeBig, s_format("^x7F7F7FArmour: %s%d", main:StatColor(armour, armourData.ArmourBase), armour), "FONTIN SC")
		end
		if evasion > 0 then
			tooltip:AddLine(fontSizeBig, s_format("^x7F7F7FEvasion Rating: %s%d", main:StatColor(evasion, armourData.EvasionBase), evasion), "FONTIN SC")
		end
		if energyShield > 0 then
			tooltip:AddLine(fontSizeBig, s_format("^x7F7F7FEnergy Shield: %s%d", main:StatColor(energyShield, armourData.EnergyShieldBase), energyShield), "FONTIN SC")
		end
		if ward > 0 then
			tooltip:AddLine(fontSizeBig, s_format("^x7F7F7FRunic Ward: %s%d", main:StatColor(ward, armourData.WardBase), ward), "FONTIN SC")
		end
	elseif base.flask then
		-- Flask-specific info
		local flaskData = item.flaskData
		if flaskData.lifeTotal then
			if flaskData.lifeGradual ~= 0 then
				tooltip:AddLine(fontSizeBig, s_format("^x7F7F7FRecovers %s%d ^x7F7F7FLife over %s%.1f0 ^x7F7F7FSeconds",
					main:StatColor(flaskData.lifeTotal, base.flask.life), flaskData.lifeGradual,
					main:StatColor(flaskData.duration, base.flask.duration), flaskData.duration
					), "FONTIN SC")
			end
			if flaskData.lifeInstant ~= 0 then
				tooltip:AddLine(fontSizeBig, s_format("^x7F7F7FRecovers %s%d ^x7F7F7FLife instantly", main:StatColor(flaskData.lifeTotal, base.flask.life), flaskData.lifeInstant), "FONTIN SC")
			end
		end
		if flaskData.manaTotal then
			if flaskData.manaGradual ~= 0 then
				tooltip:AddLine(fontSizeBig, s_format("^x7F7F7FRecovers %s%d ^x7F7F7FMana over %s%.1f0 ^x7F7F7FSeconds",
					main:StatColor(flaskData.manaTotal, base.flask.mana), flaskData.manaGradual,
					main:StatColor(flaskData.duration, base.flask.duration), flaskData.duration
					), "FONTIN SC")
			end
			if flaskData.manaInstant ~= 0 then
				tooltip:AddLine(fontSizeBig, s_format("^x7F7F7FRecovers %s%d ^x7F7F7FMana instantly", main:StatColor(flaskData.manaTotal, base.flask.mana), flaskData.manaInstant), "FONTIN SC")
			end
		end
		tooltip:AddLine(fontSizeBig, s_format("^x7F7F7FConsumes %s%d ^x7F7F7Fof %s%d ^x7F7F7FCharges on use",
			main:StatColor(flaskData.chargesUsed, base.flask.chargesUsed), flaskData.chargesUsed,
			main:StatColor(flaskData.chargesMax, base.flask.chargesMax), flaskData.chargesMax
			), "FONTIN SC")
		for _, modLine in pairs(item.buffModLines) do
			if modLine.extra then
				local line = colorCodes.UNSUPPORTED..modLine.line
				line = main.notSupportedModTooltips and (line .. main.notSupportedTooltipText) or line
				tooltip:AddLine(fontSizeBig, line, "FONTIN SC")
			else
				tooltip:AddLine(fontSizeBig, colorCodes.MAGIC..modLine.line, "FONTIN SC")
			end
		end
	elseif base.charm then
		-- Charm-specific info
		local charmData = item.charmData

		tooltip:AddLine(fontSizeBig, s_format("^x7F7F7FLasts %s%.2f ^x7F7F7FSeconds", main:StatColor(charmData.duration, base.charm.duration), charmData.duration), "FONTIN SC")
		tooltip:AddLine(fontSizeBig, s_format("^x7F7F7FConsumes %s%d ^x7F7F7Fof %s%d ^x7F7F7FCharges on use",
			main:StatColor(charmData.chargesUsed, base.charm.chargesUsed), charmData.chargesUsed,
			main:StatColor(charmData.chargesMax, base.charm.chargesMax), charmData.chargesMax
		), "FONTIN SC")
		for _, modLine in pairs(item.buffModLines) do
			if modLine.extra then
				local line = colorCodes.UNSUPPORTED..modLine.line
				line = main.notSupportedModTooltips and (line .. main.notSupportedTooltipText) or line
				tooltip:AddLine(fontSizeBig, line, "FONTIN SC")
			else
				tooltip:AddLine(fontSizeBig, colorCodes.MAGIC..modLine.line, "FONTIN SC")
			end
		end
	elseif item.type == "Jewel" then
		-- Jewel-specific info
		if item.limit then
			tooltip:AddLine(fontSizeBig, "^x7F7F7FLimited to: ^7"..item.limit, "FONTIN SC")
		end
		if item.classRestriction then
			tooltip:AddLine(fontSizeBig, "^x7F7F7FRequires Class "..(self.build.spec.curClassName == item.classRestriction and colorCodes.POSITIVE or colorCodes.NEGATIVE)..item.classRestriction, "FONTIN SC")
		end
		if item.jewelRadiusLabel then
			tooltip:AddLine(fontSizeBig, "^x7F7F7FRadius: ^7"..item.jewelRadiusLabel, "FONTIN SC")
		end
		if item.jewelRadiusData and slot and item.jewelRadiusData[slot.nodeId] then
			local radiusData = item.jewelRadiusData[slot.nodeId]
			local line
			local codes = { colorCodes.STRENGTH, colorCodes.DEXTERITY, colorCodes.INTELLIGENCE }
			for i, stat in ipairs({"Str","Dex","Int"}) do
				if radiusData[stat] and radiusData[stat] ~= 0 then
					line = (line and line .. ", " or "") .. s_format("%s%d %s^7", codes[i], radiusData[stat], stat)
				end
			end
			if line then
				tooltip:AddLine(fontSizeBig, "^x7F7F7FAttributes in Radius: "..line, "FONTIN SC")
			end
		end
	end

	if item.catalyst and item.catalyst > 0 and item.catalyst <= #catalystQualityFormat and item.catalystQuality and item.catalystQuality > 0 then
		tooltip:AddLine(fontSizeBig, s_format(catalystQualityFormat[item.catalyst], item.catalystQuality), "FONTIN SC")
		tooltip:AddSeparator(10)
	end

	if item.itemSocketCount > 0 then
		local socketString = ""
		for _ = 1, item.itemSocketCount do
			socketString = socketString .. "S "
		end
		socketString = socketString:gsub(" $", "")
		tooltip:AddLine(fontSizeBig, "^x7F7F7FSockets: " .. socketString, "FONTIN SC")
	end
	if item.jewelSocketCount > 0 then
		local socketString = ""
		for _ = 1, item.jewelSocketCount do
			socketString = socketString .. "J "
		end
		socketString = socketString:gsub(" $", "")
		tooltip:AddLine(fontSizeBig, "^x7F7F7FSockets: " .. socketString, "FONTIN SC")
	end
	tooltip:AddSeparator(10)

	if item.talismanTier then
		tooltip:AddLine(fontSizeBig, "^x7F7F7FTalisman Tier ^xFFFFFF"..item.talismanTier, "FONTIN SC")
		tooltip:AddSeparator(10)
	end

	-- Requirements
	self.build:AddRequirementsToTooltip(tooltip, item.requirements.level,
		item.requirements.strMod, item.requirements.dexMod, item.requirements.intMod,
		item.requirements.str or 0, item.requirements.dex or 0, item.requirements.int or 0)

	-- Modifiers
	-- Support for Lich Socket Jewel only for tooltip display
	-- the real calculation is done in the CalcSetup
	local scale = 1
	local extraTooltip = ""
	if slot and slot.nodeId then
		local node = self.build.spec.nodes[slot.nodeId]
		if node and node.containJewelSocket then
			local jewelEffect = node.modList:Sum("INC", nil, "SocketedJewelEffect")
			extraTooltip = "^x7F7F7FSocketed Jewel Effect: "
			if jewelEffect > 0 then
				extraTooltip = extraTooltip .. s_format(colorCodes.MAGIC.."+%d%%", jewelEffect)
				tooltip:AddSeparator(10)
				tooltip:AddLine(fontSizeBig, extraTooltip, "FONTIN SC")
				tooltip:AddSeparator(10)
			end

			scale = scale + (jewelEffect / 100)
		end
	end

	for _, modList in ipairs{item.enchantModLines, item.runeModLines, item.implicitModLines, item.explicitModLines} do
		if modList[1] then
			for _, modLine in ipairs(modList) do
				local variantCount = item:GetModLineVariantCount(modLine)
				if variantCount > 0 then
					local bg = modLine.desecrated and "HoverModBgAbyss" or nil
					local formattedModLine
					if scale ~= 1 then
						local copyModLine = copyTable(modLine)
						local modsList = copyTable(modLine.modList)
						local scaledList = new("ModList"):ModList()
						scaledList:ScaleAddList(modsList, scale)
						for j, mod in ipairs(scaledList) do
							local newValue
							if type(mod.value) == "number" then
								newValue = mod.value
							elseif type(mod.value) == "table" then
								if mod.value.mod then
									newValue = mod.value.mod.value
								else
									newValue = mod.value.value
								end
							end
							if type(newValue) == "number" then
								copyModLine.line = copyModLine.line:gsub("%d*%.?%d+", math.abs(newValue), 1) -- Only scale first number in line
							end
						end
						formattedModLine = itemLib.formatModLine(copyModLine, dbMode)
					else
						formattedModLine = itemLib.formatModLine(modLine, dbMode)
					end
					for _ = 1, variantCount do
						tooltip:AddLine(fontSizeBig, formattedModLine, "FONTIN SC", bg, modLine)
					end

					-- Show mods from granted passives
					if modLine.modList[1] and modLine.modList[1].name == "GrantedPassive" then
						for _, node in ipairs(self.build.spec:ResolveGrantedPassiveNodes(modLine.modList[1].value)) do
							local displayed = false
							if node.sd then
								for _, stat in ipairs(node.sd) do
									tooltip:AddLine(fontSizeBig, "^x7F7F7F"..stat, "FONTIN SC")
									displayed = true
								end
							end
							if not displayed and node.isJewelSocket then
								tooltip:AddLine(fontSizeBig, "^x7F7F7F"..(node.name or "Jewel Socket"), "FONTIN SC")
							end
						end
						-- Add separator only for anoints
						if item.implicitModLines then
							tooltip:AddSeparator(10)
						end
					end
				end
			end
			tooltip:AddSeparator(10)
		end
	end

	-- Cluster jewel notables/keystone
	if item.clusterJewel then
		tooltip:AddSeparator(10)
		if #item.jewelData.clusterJewelNotables > 0 then
			for _, name in ipairs(item.jewelData.clusterJewelNotables) do
				local node = self.build.spec.tree.clusterNodeMap[name]
				if node then
					tooltip:AddLine(fontSizeBig, colorCodes.MAGIC .. node.dn, "FONTIN SC")
					for _, stat in ipairs(node.sd) do
						tooltip:AddLine(fontSizeBig, "^x7F7F7F"..stat, "FONTIN SC")
					end
				end
			end
		elseif item.jewelData.clusterJewelKeystone then
			local node = self.build.spec.tree.clusterNodeMap[item.jewelData.clusterJewelKeystone]
			if node then
				tooltip:AddLine(fontSizeBig, colorCodes.MAGIC .. node.dn)
				for _, stat in ipairs(node.sd) do
					tooltip:AddLine(fontSizeBig, "^x7F7F7F"..stat)
				end
			end
		end
		tooltip:AddSeparator(10)
	end

	-- Corrupted item label
	if item.corrupted or item.mirrored or item.doubleCorrupted or item.sanctified then
		if #item.explicitModLines == 0 then
			tooltip:AddSeparator(10)
		end
		if item.mirrored then
			tooltip:AddLine(fontSizeBig, colorCodes.NEGATIVE.."Mirrored", "FONTIN SC")
		end
		if item.sanctified then
			tooltip:AddLine(fontSizeBig, colorCodes.FRACTURED.."Sanctified", "FONTIN SC")
		end
		if item.doubleCorrupted then
			tooltip:AddLine(fontSizeBig, colorCodes.NEGATIVE.."Twice Corrupted", "FONTIN SC")
		elseif item.corrupted then
			tooltip:AddLine(fontSizeBig, colorCodes.NEGATIVE.."Corrupted", "FONTIN SC")
		end
		tooltip:AddSeparator(10)
	end

	-- Show flavour text:
	if flavourText then
		for _, line in ipairs(flavourText) do
			tooltip:AddLine(fontSizeBig, colorCodes.UNIQUE .. line, "FONTIN SC ITALIC")
		end
		tooltip:AddSeparator(14)
	end

	-- Skill tooltip. We add child tooltips, which will be rendered to the right of the main
	-- tooltip, growing downwards
	if not tooltip.childTooltips then
		tooltip.childTooltips = {}
	end
	local gemMaxWidth = 450
	for _, tt in ipairs(tooltip.childTooltips) do
		tt:Clear()
		tt.maxWidth = gemMaxWidth
	end
	if item.grantedSkills and #item.grantedSkills > 0 then
		tooltip:AddSeparator(14)
		tooltip:AddLine(14,
			colorCodes.TIP ..
			"Tip: Hold Shift to display a tooltip for the granted skill" ..
			(#item.grantedSkills > 1 and "s" or "") .. ".")
		for i, itemSkill in ipairs(item.grantedSkills) do
			if not tooltip.childTooltips[i] then
				tooltip.childTooltips[i] = new("Tooltip"):Tooltip()
				tooltip.childTooltips[i].maxWidth = gemMaxWidth
			end
			-- find gem since the item data only contains the skill id
			local skill = data.skills[itemSkill.skillId]
			if skill and skill.id and IsKeyDown("SHIFT") then
				local gemId = data.gemForSkill[skill] or ""
				local gem = data.gems[gemId]
				if gem then
					local gemInst = {
						gemData = gem,
						level = itemSkill.level or 1,
						quality = 0,
						grantedEffect = skill
					}
					gemTooltip.AddGemTooltip(tooltip.childTooltips[i], self.build, gemInst, {
						includeQualityRange = true,
					})
				end
			end
		end
	end
	-- Stat differences
	local itemTabHint = self.build.viewMode == "ITEMS" and "" or " in the Items tab"
	if not self.showStatDifferences then
		tooltip:AddSeparator(14)
		tooltip:AddLine(14, colorCodes.TIP.."Tip: Press Ctrl+D"..itemTabHint.." to enable the display of stat differences.")
		return
	end
	local calcFunc, calcBase = self.build.calcsTab:GetMiscCalculator()
	if base.flask then
		-- Special handling for flasks
		local stats = { }
		local flaskData = item.flaskData
		local modDB = self.build.calcsTab.mainEnv.modDB
		local output = self.build.calcsTab.mainOutput
		local durInc = modDB:Sum("INC", nil, "FlaskDuration")
		local effectInc = modDB:Sum("INC", { actor = "player" }, "FlaskEffect")
		local lifeDur = 0
		local manaDur = 0

		if item.base.flask.life or item.base.flask.mana then
			local rateInc = modDB:Sum("INC", nil, "FlaskRecoveryRate")
			if item.base.flask.life then
				local lifeInc = modDB:Sum("INC", nil, "FlaskLifeRecovery")
				local lifeMore = modDB:More(nil, "FlaskLifeRecovery")
				local lifeRateInc = modDB:Sum("INC", nil, "FlaskLifeRecoveryRate")
				local instantPerc = flaskData.instantPerc + modDB:Sum("BASE", nil, "FlaskInstantRecovery", "LifeFlaskInstantRecovery")

				-- More life recovery while on low life is not affected by flask effect (verified ingame).
				-- Since this will be multiplied by the flask effect value below we have to counteract this by removing the flask effect from the value beforehand.
				-- This is also the reason why this value needs a separate multiplier and cannot just be calculated into FlaskLifeRecovery.
				local lifeMoreOnLowLife = modDB:More(nil, "FlaskLifeRecoveryLowLife")
				local lowLifeMulti = (lifeMoreOnLowLife > 1 and ((lifeMoreOnLowLife - 1) / (1 + effectInc / 100)) + 1 or 1)

				local inst = flaskData.lifeBase * instantPerc / 100 * (1 + lifeInc / 100) * lifeMore * (1 + effectInc / 100) * lowLifeMulti
				local base = flaskData.lifeBase * (1 - instantPerc / 100) * (1 + lifeInc / 100) * lifeMore * (1 + effectInc / 100) * (1 + durInc / 100) * lowLifeMulti
				local grad = base * output.LifeRecoveryRateMod
				local esGrad = base * output.EnergyShieldRecoveryRateMod
				lifeDur = flaskData.duration * (1 + durInc / 100) / (1 + rateInc / 100) / (1 + lifeRateInc / 100)

				if not modDB:Flag(nil, "LifeFlaskDoesNotApply") then
					-- LocalLifeFlaskAdditionalLifeRecovery flask mods
					if flaskData.lifeAdditional > 0 and not self.build.configTab.input.conditionFullLife then
						local totalAdditionalAmount = (flaskData.lifeAdditional/100) * flaskData.lifeTotal * output.LifeRecoveryRateMod
						local additionalGrad = (lifeDur/10) * totalAdditionalAmount
						local leftoverDur = 10 - lifeDur
						local leftoverAmount = totalAdditionalAmount - additionalGrad

						if inst > 0 then
							if grad > 0 then
								t_insert(stats, s_format("^8Life recovered: ^7%d ^8(^7%d^8 instantly, plus ^7%d ^8over^7 %.2fs^8, and an additional ^7%d ^8over subsequent ^7%.2fs^8)",
										inst + grad + totalAdditionalAmount, inst, grad + additionalGrad, lifeDur, leftoverAmount, leftoverDur))
							else
								lifeDur = 0
								t_insert(stats, s_format("^8Life recovered: ^7%d ^8(^7%d^8 instantly, and an additional ^7%d ^8over ^7%.2fs^8)",
										inst + totalAdditionalAmount, inst, totalAdditionalAmount, 10))
							end
						else
							t_insert(stats, s_format("^8Life recovered: ^7%d ^8(^7%d ^8over ^7%.2fs^8, and an additional ^7%d ^8over subsequent ^7%.2fs^8)",
							grad + totalAdditionalAmount, grad + additionalGrad, lifeDur, leftoverAmount, leftoverDur))
						end
					else
						if inst > 0 and grad > 0 then
							t_insert(stats, s_format("^8Life recovered: ^7%d ^8(^7%d^8 instantly, plus ^7%d ^8over^7 %.2fs^8)", inst + grad, inst, grad, lifeDur))
						-- modifiers to recovery amount or duration
						elseif inst + grad ~= flaskData.lifeTotal or (inst == 0 and lifeDur ~= flaskData.duration) then
							if inst > 0 then
								lifeDur = 0
								t_insert(stats, s_format("^8Life recovered: ^7%d ^8instantly", inst))
							elseif grad > 0 then
								t_insert(stats, s_format("^8Life recovered: ^7%d ^8over ^7%.2fs", grad, lifeDur))
							end
						end
					end
				end
				if modDB:Flag(nil, "LifeFlaskAppliesToEnergyShield") then
					if inst > 0 and esGrad > 0 then
						t_insert(stats, s_format("^8Energy Shield recovered: ^7%d ^8(^7%d^8 instantly, plus ^7%d ^8over^7 %.2fs^8)", inst + esGrad, inst, esGrad, lifeDur))
					elseif inst > 0 and esGrad == 0 then
						t_insert(stats, s_format("^8Energy Shield recovered: ^7%d ^8instantly", inst))
					elseif inst == 0 and esGrad > 0 then
						t_insert(stats, s_format("^8Energy Shield recovered: ^7%d ^8over ^7%.2fs", esGrad, lifeDur))
					end
				end
			end
			if item.base.flask.mana then
				local manaInc = modDB:Sum("INC", nil, "FlaskManaRecovery")
				local manaMore = modDB:More(nil, "FlaskManaRecovery")
				local manaRateInc = modDB:Sum("INC", nil, "FlaskManaRecoveryRate")
				local instantPerc = flaskData.instantPerc + modDB:Sum("BASE", nil, "FlaskInstantRecovery",  "ManaFlaskInstantRecovery")
				local inst = flaskData.manaBase * instantPerc / 100 * (1 + manaInc / 100) * manaMore * (1 + effectInc / 100)
				local base = flaskData.manaBase * (1 - instantPerc / 100) * (1 + manaInc / 100) * manaMore * (1 + effectInc / 100) * (1 + durInc / 100)
				local grad = base * output.ManaRecoveryRateMod
				local lifeGrad = base * output.LifeRecoveryRateMod
				manaDur = flaskData.duration * (1 + durInc / 100) / (1 + rateInc / 100) / (1 + manaRateInc / 100)

				if inst > 0 and grad > 0 then
					t_insert(stats, s_format("^8Mana recovered: ^7%d ^8(^7%d^8 instantly, plus ^7%d ^8over^7 %.2fs^8)", inst + grad, inst, grad, manaDur))
				elseif inst + grad ~= flaskData.manaTotal or (inst == 0 and manaDur ~= flaskData.duration) then
					if inst > 0 then
						manaDur = 0
						t_insert(stats, s_format("^8Mana recovered: ^7%d ^8instantly", inst))
					elseif grad > 0 then
						t_insert(stats, s_format("^8Mana recovered: ^7%d ^8over ^7%.2fs", grad, manaDur))
					end
				end
				if modDB:Flag(nil, "ManaFlaskAppliesToLife") then
					if lifeGrad > 0 then
						t_insert(stats, s_format("^8Life recovered: ^7%d ^8over ^7%.2fs", lifeGrad, manaDur))
					end
				end
			end
		end
		local effectMod = 1 + (flaskData.effectInc + effectInc) / 100
		if effectMod ~= 1 then
			t_insert(stats, s_format("^8Flask effect modifier: ^7%+d%%", effectMod * 100 - 100))
		end
		local usedInc = modDB:Sum("INC", nil, "FlaskChargesUsed")
		if item.base.flask.life then
			usedInc = usedInc + modDB:Sum("INC", nil, "LifeFlaskChargesUsed")
		end
		if item.base.flask.mana then
			usedInc = usedInc + modDB:Sum("INC", nil, "ManaFlaskChargesUsed")
		end
		if usedInc ~= 0 then
			local used = m_floor(flaskData.chargesUsed * (1 + usedInc / 100))
			t_insert(stats, s_format("^8Charges used: ^7%d ^8of ^7%d ^8(^7%d ^8uses)", used, flaskData.chargesMax, m_floor(flaskData.chargesMax / used)))
		end
		local gainInc = flaskData.gainInc + modDB:Sum("INC", nil, "FlaskChargesGained")
		if item.base.flask.life then
			gainInc = gainInc + modDB:Sum("INC", nil, "LifeFlaskChargesGained")
		end
		if item.base.flask.mana then
			gainInc = gainInc + modDB:Sum("INC", nil, "ManaFlaskChargesGained")
		end
		local gainMod = flaskData.gainMod * (1 + gainInc / 100)
		if gainMod ~= 1 then
			t_insert(stats, s_format("^8Charge gain modifier: ^7%+d%%", gainMod * 100 - 100))
		end

		-- charge generation
		local chargesGenerated = flaskData.gainBase + modDB:Sum("BASE", nil, "FlaskChargesGenerated")
		if item.base.flask.life then
			chargesGenerated = chargesGenerated + modDB:Sum("BASE", nil, "LifeFlaskChargesGenerated")
		end
		if item.base.flask.mana then
			chargesGenerated = chargesGenerated + modDB:Sum("BASE", nil, "ManaFlaskChargesGenerated")
		end

		local totalChargesGenerated = chargesGenerated * gainMod
		if totalChargesGenerated > 0 then
			t_insert(stats, s_format("^8Charges generated: ^7%.2f^8 per second", totalChargesGenerated))
		end

		local chanceToNotConsumeCharges = m_min(modDB:Sum("BASE", nil, "FlaskChanceNotConsumeCharges"), 100)
		if chanceToNotConsumeCharges ~= 0 then
			t_insert(stats, s_format("^8Chance to not consume charges: ^7%d%%", chanceToNotConsumeCharges))
		end

		-- flask uptime
		local hasUptime = not item.base.flask.life and not item.base.flask.mana
		local flaskDuration = flaskData.duration * (1 + durInc / 100)

		if item.base.flask.life and (flaskData.lifeEffectNotRemoved or modDB:Flag(nil, "LifeFlaskEffectNotRemoved")) then
			hasUptime = true
			flaskDuration = lifeDur
		elseif item.base.flask.mana and (flaskData.manaEffectNotRemoved or modDB:Flag(nil, "ManaFlaskEffectNotRemoved")) then
			hasUptime = true
			flaskDuration = manaDur
		end

		if hasUptime then
			local flaskChargesUsed = flaskData.chargesUsed * (1 + usedInc / 100)
			if flaskChargesUsed > 0 and flaskDuration > 0 then
				local averageChargesGenerated = totalChargesGenerated * flaskDuration
				local percentageMin = m_min(averageChargesGenerated / flaskChargesUsed * 100, 100)
				if percentageMin < 100 and chanceToNotConsumeCharges < 100 then
					local averageChargesUsed = flaskChargesUsed * (100 - chanceToNotConsumeCharges) / 100
					local percentageAvg = m_min(averageChargesGenerated / averageChargesUsed * 100, 100)
					t_insert(stats, s_format("^8Flask uptime: ^7%d%%^8 average, ^7%d%%^8 minimum", percentageAvg, percentageMin))
				else
					t_insert(stats, s_format("^8Flask uptime: ^7100%%^8"))
				end
			end
		end

		if stats[1] then
			tooltip:AddLine(14, "^7Effective flask stats:")
			for _, stat in ipairs(stats) do
				tooltip:AddLine(14, stat)
			end
		end
		local output = calcFunc({ toggleFlask = item })
		local header
		if self.build.calcsTab.mainEnv.flasks[item] then
			header = "^7Deactivating this flask will give you:"
		else
			header = "^7Activating this flask will give you:"
		end
		self.build:AddStatComparesToTooltip(tooltip, calcBase, output, header)
	elseif base.charm then
		-- Special handling for charms
		local stats = { }
		local charmData = item.charmData
		local modDB = self.build.calcsTab.mainEnv.modDB
		local output = self.build.calcsTab.mainOutput
		local durInc = modDB:Sum("INC", nil, "CharmDuration")
		local effectInc = modDB:Sum("INC", { actor = "player" }, "CharmEffect")

		if item.rarity == "MAGIC" then
			effectInc = effectInc + modDB:Sum("INC", { actor = "player" }, "MagicCharmEffect")
		end
		local effectMod = (1 + (charmData.effectInc + effectInc) / 100) * (1 + (item.quality or 0) / 100)
		if effectMod ~= 1 then
			t_insert(stats, s_format("^8Charm effect modifier: ^7%+d%%", effectMod * 100 - 100))
		end

		if durInc ~= 0 then
			t_insert(stats, s_format("^8Charm effect duration: ^7%.1f0s", charmData.duration * (1 + durInc / 100)))
		end

		if stats[1] then
			tooltip:AddLine(14, "^7Effective charm stats:")
			for _, stat in ipairs(stats) do
				tooltip:AddLine(14, stat)
			end
		end
		local output = calcFunc({ toggleCharm = item })
		local header
		if self.build.calcsTab.mainEnv.charms[item] then
			header = "^7Deactivating this charm will give you:"
		else
			header = "^7Activating this charm will give you:"
		end
		self.build:AddStatComparesToTooltip(tooltip, calcBase, output, header)
	else
		self:UpdateSockets()
		-- Build sorted list of slots to compare with
		local compareSlots = { }
		for slotName, slot in pairs(self.slots) do
			if self:IsItemValidForSlot(item, slotName) and not slot.inactive and (not slot.weaponSet or slot.weaponSet == (self.activeItemSet.useSecondWeaponSet and 2 or 1)) and slot.shown() then
				t_insert(compareSlots, slot)
			end
		end

		tooltip:AddLine(14, colorCodes.TIP .. "Tip: Press Ctrl+D"..itemTabHint.." to disable the display of stat differences.")

		local function getReplacedItemAndOutput(compareSlot)
			local selItem = self.items[compareSlot.selItemId]
			local output = calcFunc({ repSlotName = compareSlot.slotName, repItem = item ~= selItem and item or nil })
			return selItem, output
		end
		local function addCompareForSlot(compareSlot, selItem, output)
			if not selItem or not output then
				selItem, output = getReplacedItemAndOutput(compareSlot)
			end
			local header
			if item == selItem then
				header = "^7Removing this item from " .. compareSlot.label .. " will give you:"
			else
				header = string.format("^7Equipping this item in %s will give you:%s",
					compareSlot.label or compareSlot.slotName,
					selItem and "\n(replacing " .. colorCodes[selItem.rarity] .. selItem.name .. "^7)" or "")
			end
			self.build:AddStatComparesToTooltip(tooltip, calcBase, output, header)
		end

		-- if we have a specific slot to compare to, and the user has "Show
		-- tooltips only for affected slots" checked, we can just compare that
		-- one slot
		if main.slotOnlyTooltips and slot then
			slot = type(slot) ~= "string" and slot or self.slots[slot]
			if slot then addCompareForSlot(slot) end
			return
		end


		local slots = {}
		local isUnique = item.rarity == "UNIQUE" or item.rarity == "RELIC"
		local currentSameUniqueCount = 0
		for _, compareSlot in ipairs(compareSlots) do
			local selItem, output = getReplacedItemAndOutput(compareSlot)
			local isSameUnique = isUnique and selItem and item.name == selItem.name
			if isUnique and isSameUnique and item.limit then
				currentSameUniqueCount = currentSameUniqueCount + 1
			end
			table.insert(slots,
				{ selItem = selItem, output = output, compareSlot = compareSlot, isSameUnique = isSameUnique })
		end

		-- limited uniques: only compare to slots with the same item if more don't fit
		if currentSameUniqueCount == item.limit then
			for _, slotEntry in ipairs(slots) do
				if slotEntry.isSameUnique then
					addCompareForSlot(slotEntry.compareSlot, slotEntry.selItem, slotEntry.output)
				end
			end
			return
		end


		-- either the same unique or same base type
		local function similar(compareItem, sameUnique)
			-- empty slot
			if not compareItem then return 0 end

			local sameBaseType = not isUnique
				and compareItem.rarity ~= "UNIQUE" and compareItem.rarity ~= "RELIC"
				and item.base.type == compareItem.base.type
				and item.base.subType == compareItem.base.subType
			if sameBaseType or sameUnique then
				return 1
			else
				return 0
			end
		end
		-- sort by:
		-- 1. empty sockets
		-- 2. same base group jewel or unique
		-- 3. DPS
		-- 4. EHP
		local function sortFunc(a, b)
			if a == b then return end

			local aParams = { a.compareSlot.selItemId == 0 and 1 or 0, similar(a.selItem, a.isSameUnique), a.output
				.FullDPS, a.output.CombinedDPS, a.output.TotalEHP, a.compareSlot.label, a.compareSlot.slotName }
			local bParams = { b.compareSlot.selItemId == 0 and 1 or 0, similar(b.selItem, b.isSameUnique), b.output
				.FullDPS, b
				.output.CombinedDPS, b.output.TotalEHP, b.compareSlot.label, b.compareSlot.slotName }
			for i = 1, #aParams do
				if aParams[i] == nil or bParams[i] == nil then
					-- continue
				elseif aParams[i] > bParams[i] then
					return true
				elseif aParams[i] < bParams[i] then
					return false
				end
			end
			return false
		end
		table.sort(slots, sortFunc)

		for _, slotEntry in ipairs(slots) do
			addCompareForSlot(slotEntry.compareSlot, slotEntry.selItem, slotEntry.output)
		end
	end
	if launch.devModeAlt then
		-- Modifier debugging info
		tooltip:AddSeparator(10)
		for _, mod in ipairs(modList) do
			tooltip:AddLine(fontSizeSmall, "^7"..modLib.formatMod(mod), "VAR")
		end
	end
end

function ItemsTabClass:CreateUndoState()
	local state = { }
	state.activeItemSetId = self.activeItemSetId
	state.items = { }
	for k, v in pairs(self.items) do
		state.items[k] = copyTableSafe(self.items[k], true, true)
	end
	state.itemOrderList = copyTable(self.itemOrderList)
	state.slotSelItemId = { }
	for slotName, slot in pairs(self.slots) do
		state.slotSelItemId[slotName] = slot.selItemId
	end
	state.itemSets = copyTableSafe(self.itemSets)
	state.itemSetOrderList = copyTable(self.itemSetOrderList)
	return state
end

function ItemsTabClass:RestoreUndoState(state)
	self.items = state.items
	wipeTable(self.itemOrderList)
	for k, v in pairs(state.itemOrderList) do
		self.itemOrderList[k] = v
	end
	for slotName, selItemId in pairs(state.slotSelItemId) do
		self.slots[slotName]:SetSelItemId(selItemId)
	end
	self.itemSets = state.itemSets
	wipeTable(self.itemSetOrderList)
	for k, v in pairs(state.itemSetOrderList) do
		self.itemSetOrderList[k] = v
	end
	self.activeItemSetId = state.activeItemSetId
	self.activeItemSet = self.itemSets[self.activeItemSetId]
	for slotName, slot in pairs(self.runeSlots) do
		slot:SelByValue(self.activeItemSet[slotName].runeName, "name")
	end
	self:PopulateSlots()
end

//! Optional temporal List/receiving witness for the unchanged selected build.
#![cfg(not(target_arch = "wasm32"))]
#[path = "support/json_evidence.rs"]
mod json_evidence;
#[allow(dead_code)]
#[path = "support/configuration_preparation_source.rs"]
mod source;

use mlua::{Function, Lua, LuaSerdeExt, Table, Value};
use poe_optimizer_pob::{runtime::RuntimeError, source as pinned};
use serde_json::{Value as Json, json};
use sha2::{Digest, Sha256};
use std::{
    fs,
    path::{Path, PathBuf},
    process::{Command, Stdio},
    time::{Duration, Instant},
};

const TEST: &str = "unchanged_inherited_minion_modifiers_are_original_and_repeatable";
const CHILD: &str = "POE_INHERITED_MINION_SOURCE_CHILD";
const OUTPUT: &str = "POE_INHERITED_MINION_SOURCE_OUT";
const XML: &str = "tests/fixtures/builds/breadth-20260908/build-05.xml";
const COMMON: &str = include_str!("support/owned_minion_physical_damage_source.lua");
const OBSERVER: &str = include_str!("support/inherited_minion_modifier_observer.lua");
const BOOTSTRAP: &[u8] = include_bytes!("support/configuration_preparation_source.rs");

fn hash(bytes: &[u8]) -> String {
    format!("{:x}", Sha256::digest(bytes))
}
fn helpers(lua: &Lua) -> Result<Table, RuntimeError> {
    let marker = "local methods={";
    assert_eq!(COMMON.matches(marker).count(), 1);
    let prefix = COMMON.split_once(marker).unwrap().0;
    Ok(lua
        .load(format!(
            "{prefix}\nreturn {{original=original,upvalue=upvalue,scalar=scalar,scalars=scalars,clone=clone,equal=equal,sourceOccurrence=sourceOccurrence,recipientOccurrence=recipientOccurrence,sourceConfig=sourceConfig,offeringOutputSnapshot=offeringOutputSnapshot}}"
        ))
        .set_name("@existing-source-helpers")
        .eval()?)
}
fn equal(a: &Json, b: &Json, label: &str) {
    assert_eq!(json_evidence::first_difference(a, b, "$"), None, "{label}");
}
fn rows(value: &Json) -> &[Json] {
    if value.as_object().is_some_and(serde_json::Map::is_empty) {
        return &[];
    }
    value.as_array().unwrap()
}
fn validate_trace(trace: &Json) {
    assert_eq!(trace["kind"], "original-inherited-minion-modifier-delivery");
    assert_eq!(trace["original_functions_preserved"], true);
    assert_eq!(trace["observer_removed"], true);
    assert_eq!(trace["business_methods_replaced"], false);
    assert_eq!(trace["scope"]["native_coverage_authorized"], false);
    let calls = rows(&trace["perform_calls"]);
    assert!(!calls.is_empty());
    for (index, call) in calls.iter().enumerate() {
        assert_eq!(call["perform_id"], index + 1);
        assert_eq!(call["returned"], true);
    }
    let deliveries = rows(&trace["deliveries"]);
    assert!(!deliveries.is_empty());
    for (index, call) in deliveries.iter().enumerate() {
        assert_eq!(call["delivery_id"], index + 1);
        let id = call["perform_id"].as_u64().unwrap() as usize;
        assert!(id > 0 && id <= calls.len());
        assert_eq!(call["env_id"], calls[id - 1]["env_id"]);
        assert_eq!(call["mode"], calls[id - 1]["mode"]);
        assert!(matches!(
            call["line"].as_u64(),
            Some(1854 | 3123 | 3377 | 3384)
        ));
        assert_eq!(call["returned"], true);
        assert_eq!(call["original_list_return_observed"], true);
        assert_eq!(call["original_list_call_count"], 1);
        assert_eq!(call["cfg"]["present"], true);
        for (at, added) in rows(&call["added"]).iter().enumerate() {
            assert_eq!(added["position"], at + 1);
            assert_eq!(added["original_append_observed"], true);
            assert_eq!(
                added["after_count"].as_u64().unwrap(),
                added["before_count"].as_u64().unwrap() + 1
            );
        }
    }
    let gates = rows(&trace["gates"]);
    for gate in gates {
        let id = gate["perform_id"].as_u64().unwrap() as usize;
        assert!(id > 0 && id <= calls.len());
        assert_eq!(gate["env_id"], calls[id - 1]["env_id"]);
        assert_eq!(gate["mode"], calls[id - 1]["mode"]);
    }
    for call in calls {
        // A loop header can have entry, iteration and termination events.
        // Keep all events; only business calls have unique delivery identities.
        for line in [1844, 2037, 3117, 3397, 3406] {
            assert!(
                gates
                    .iter()
                    .any(|r| r["perform_id"] == call["perform_id"] && r["line"] == line),
                "required gate {line} for perform {}",
                call["perform_id"]
            );
        }
    }
    for pool in rows(&trace["life_pool_calls"]) {
        let id = pool["perform_id"].as_u64().unwrap() as usize;
        assert!(id > 0 && id <= calls.len());
        assert_eq!(pool["env_id"], calls[id - 1]["env_id"]);
        assert_eq!(pool["mode"], calls[id - 1]["mode"]);
        assert_eq!(pool["returned"], true);
    }
}

#[test]
fn inherited_observer_parses_without_executing_source() {
    Lua::new().load(OBSERVER).into_function().unwrap();
}

#[test]
#[ignore = "four fresh unchanged original PoB loads; explicit optional source acquisition"]
fn unchanged_inherited_minion_modifiers_are_original_and_repeatable() {
    let root = PathBuf::from(env!("CARGO_MANIFEST_DIR"))
        .join("../..")
        .canonicalize()
        .unwrap();
    let out = PathBuf::from(std::env::var_os(OUTPUT).expect("fresh output directory"));
    let out = if out.is_absolute() {
        out
    } else {
        root.join(out)
    };
    if let Some(label) = std::env::var_os(CHILD) {
        child(&root, &out, label.to_str().unwrap());
        return;
    }
    assert!(!out.exists(), "fresh acquisition directory required");
    fs::create_dir_all(&out).unwrap();
    for (name, bytes) in [
        (
            "acquisition-driver.rs",
            include_bytes!("owned_inherited_minion_modifier_source.rs").as_slice(),
        ),
        ("acquisition-observer.lua", OBSERVER.as_bytes()),
        ("acquisition-helpers.lua", COMMON.as_bytes()),
        ("acquisition-bootstrap.rs", BOOTSTRAP),
    ] {
        fs::write(out.join(name), bytes).unwrap();
    }
    let labels = ["observed-a", "observed-b", "plain-off", "plain-on"];
    for label in labels {
        let log = fs::File::create(out.join(format!("{label}.log"))).unwrap();
        let mut process = Command::new(std::env::current_exe().unwrap())
            .args(["--exact", TEST, "--ignored", "--nocapture"])
            .env(CHILD, label)
            .env(OUTPUT, &out)
            .current_dir(root.join("vendor/path-of-building-poe2/src"))
            .stdout(Stdio::from(log.try_clone().unwrap()))
            .stderr(Stdio::from(log))
            .spawn()
            .unwrap();
        let start = Instant::now();
        loop {
            if let Some(status) = process.try_wait().unwrap() {
                assert!(status.success(), "inspect {label}.log");
                break;
            }
            if start.elapsed() > Duration::from_secs(600) {
                process.kill().unwrap();
                process.wait().unwrap();
                panic!("source deadline: {label}.log");
            }
            std::thread::sleep(Duration::from_millis(100));
        }
    }
    let loads: Vec<Json> = labels
        .iter()
        .map(|label| {
            serde_json::from_slice(&fs::read(out.join(format!("{label}.json"))).unwrap()).unwrap()
        })
        .collect();
    let a = &loads[0]["additional_observation"];
    let b = &loads[1]["additional_observation"];
    validate_trace(a);
    validate_trace(b);
    equal(a, b, "independent unchanged temporal receiving traces");
    for (label, output) in [
        ("second observed", &b["snapshot"]),
        ("plain JIT off", &loads[2]["additional_observation"]),
        ("plain JIT on", &loads[3]["additional_observation"]),
    ] {
        equal(&a["snapshot"], output, label);
    }
    let files: Vec<_> = labels
        .iter()
        .map(|label| {
            let file = format!("{label}.json");
            let bytes = fs::read(out.join(&file)).unwrap();
            json!({"file":file,"bytes":bytes.len(),"sha256":hash(&bytes)})
        })
        .collect();
    let report = json!({"schema_version":1,"kind":"original-inherited-minion-modifier-evidence",
        "source_revision":pinned::UPSTREAM_REVISION,"manifest_sha256":pinned::manifest_sha256(),
        "xml":{"path":XML,"sha256":hash(&fs::read(root.join(XML)).unwrap())},
        "driver_sha256":hash(include_bytes!("owned_inherited_minion_modifier_source.rs")),
        "observer_sha256":hash(OBSERVER.as_bytes()),"helper_sha256":hash(COMMON.as_bytes()),
        "bootstrap_sha256":hash(BOOTSTRAP),"files":files,
        "complete_loads":4,"instrumented_loads":2,"instrumented_jit_enabled":false,
        "plain_jit_modes":[false,true],"all_scalar_outputs_exact":true,
        "comparison":{"all_trace_fields_exact":true,"raw_list_and_addmod_order_retained":true,
            "native_order_authority":false},
        "counts":{"perform_calls":rows(&a["perform_calls"]).len(),
            "deliveries":rows(&a["deliveries"]).len(),"gates":rows(&a["gates"]).len(),
            "life_pool_calls":rows(&a["life_pool_calls"]).len()},
        "native_coverage_authorized":false});
    fs::write(
        out.join("source.json"),
        serde_json::to_vec(&report).unwrap(),
    )
    .unwrap();
}

fn child(root: &Path, out: &Path, label: &str) {
    assert!(matches!(
        label,
        "observed-a" | "observed-b" | "plain-off" | "plain-on"
    ));
    let instrumented = label.starts_with("observed-");
    let jit = label == "plain-on";
    let xml = fs::read_to_string(root.join(XML)).unwrap();
    assert_eq!(
        hash(xml.as_bytes()),
        "442e048f4bc2d69c05bed2a7cda68580abb5c32f96990ad70f77b8ca614fe089"
    );
    let before = |lua: &Lua| -> Result<(), RuntimeError> {
        lua.globals().set("inheritedMinionJit", jit)?;
        lua.globals()
            .set("physicalDamagePreconversionEvidence", true)?;
        lua.load("if inheritedMinionJit then jit.on() else jit.off();jit.flush() end")
            .exec()?;
        Ok(())
    };
    let install = |lua: &Lua| -> Result<Function, RuntimeError> {
        assert!(!lua.load("return jit.status()").eval::<bool>()?);
        let factory: Function = lua
            .load(OBSERVER)
            .set_name("@inherited-minion-modifier-observer")
            .eval()?;
        Ok(factory.call(helpers(lua)?)?)
    };
    let after = |lua: &Lua| -> Result<Json, RuntimeError> {
        assert_eq!(lua.load("return jit.status()").eval::<bool>()?, jit);
        let value: Value = if instrumented {
            lua.globals().get("inheritedMinionModifierObservation")?
        } else {
            helpers(lua)?
                .get::<Function>("offeringOutputSnapshot")?
                .call(())?
        };
        Ok(lua.from_value(value)?)
    };
    let scratch = tempfile::tempdir().unwrap();
    let observed = source::observe_with_build_hook_unwrapped(
        &root.join("vendor/path-of-building-poe2"),
        scratch.path(),
        &xml,
        None,
        false,
        Some(&before),
        instrumented.then_some(&install),
        Some(&after),
    )
    .unwrap_or_else(|error| panic!("{label}: {error}"));
    assert_eq!(observed["configuration_method_wrappers"], false);
    assert_eq!(observed["source_hash"], pinned::manifest_sha256());
    assert_eq!(observed["original_build_output_available"], true);
    fs::write(
        out.join(format!("{label}.json")),
        serde_json::to_vec(&observed).unwrap(),
    )
    .unwrap();
}

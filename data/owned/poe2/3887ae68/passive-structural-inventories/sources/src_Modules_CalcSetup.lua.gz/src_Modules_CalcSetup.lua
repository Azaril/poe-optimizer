-- Path of Building
--
-- Module: Calc Setup
-- Initialises the environment for calculations.
--
---@class Calcs
local calcs = require("Modules.CalcBase")

local pairs = pairs
local ipairs = ipairs
local t_insert = table.insert
local t_remove = table.remove
local m_min = math.min
local m_max = math.max
local band = AND64

local tempTable1 = { }

local function addGrantedPassiveNode(env, node)
	env.allocNodes[node.id] = env.spec.nodes[node.id] or node -- use the conquered node data, if available
	env.grantedPassives[node.id] = true
	env.extraRadiusNodeList[node.id] = nil
end

-- Initialise modifier database with stats and conditions common to all actors
function calcs.initModDB(env, modDB)
	modDB:NewMod("FireResistMax", "BASE", data.characterConstants["base_maximum_all_resistances_%"], "Base")
	modDB:NewMod("ColdResistMax", "BASE", data.characterConstants["base_maximum_all_resistances_%"], "Base")
	modDB:NewMod("LightningResistMax", "BASE", data.characterConstants["base_maximum_all_resistances_%"], "Base")
	modDB:NewMod("ChaosResistMax", "BASE", data.characterConstants["base_maximum_all_resistances_%"], "Base")
	modDB:NewMod("TotemFireResistMax", "BASE", 75, "Base")
	modDB:NewMod("TotemColdResistMax", "BASE", 75, "Base")
	modDB:NewMod("TotemLightningResistMax", "BASE", 75, "Base")
	modDB:NewMod("TotemChaosResistMax", "BASE", 75, "Base")
	modDB:NewMod("BaseBlockChanceMax", "BASE", data.characterConstants["object_inherent_base_maximum_block_%_from_ot"], "Base")
	modDB:NewMod("BaseSpellBlockChanceMax", "BASE", data.characterConstants["object_inherent_base_maximum_block_%_from_ot"], "Base")
	modDB:NewMod("SpellDodgeChanceMax", "BASE", 75, "Base")
	modDB:NewMod("ChargeDuration", "BASE", 15, "Base")
	modDB:NewMod("PowerChargesMax", "BASE", data.characterConstants["max_power_charges"], "Base")
	modDB:NewMod("FrenzyChargesMax", "BASE", data.characterConstants["max_frenzy_charges"], "Base")
	modDB:NewMod("EnduranceChargesMax", "BASE", data.characterConstants["max_endurance_charges"], "Base")
	modDB:NewMod("MaximumRage", "BASE", data.gameConstants["BaseMaximumRage"], "Base")
	modDB:NewMod("SiphoningChargesMax", "BASE", 0, "Base")
	modDB:NewMod("ChallengerChargesMax", "BASE", 0, "Base")
	modDB:NewMod("BlitzChargesMax", "BASE", 0, "Base")
	modDB:NewMod("InspirationChargesMax", "BASE", 5, "Base")
	modDB:NewMod("CrabBarriersMax", "BASE", 0, "Base")
	modDB:NewMod("BrutalChargesMax", "BASE", 0, "Base")
	modDB:NewMod("AbsorptionChargesMax", "BASE", 0, "Base")
	modDB:NewMod("AfflictionChargesMax", "BASE", 0, "Base")
	modDB:NewMod("BloodChargesMax", "BASE", 5, "Base")
	modDB:NewMod("MaxLifeLeechRate", "BASE", 20, "Base")
	modDB:NewMod("MaxManaLeechRate", "BASE", 20, "Base")
	modDB:NewMod("ImpaleStacksMax", "BASE", 5, "Base")
	modDB:NewMod("IgniteStacksMax", "BASE", 1, "Base")
	modDB:NewMod("BleedStacksMax", "BASE", 1, "Base")
	modDB:NewMod("PoisonStacksMax", "BASE", 1, "Base")
	modDB:NewMod("MaxEnergyShieldLeechRate", "BASE", 10, "Base")
	modDB:NewMod("MaxLifeLeechInstance", "BASE", 10, "Base")
	modDB:NewMod("MaxManaLeechInstance", "BASE", 10, "Base")
	modDB:NewMod("MaxEnergyShieldLeechInstance", "BASE", 10, "Base")
	modDB:NewMod("TrapThrowingTime", "BASE", 0.6, "Base")
	modDB:NewMod("MineLayingTime", "BASE", 0.3, "Base")
	modDB:NewMod("WarcryCastTime", "BASE", 0.8, "Base")
	modDB:NewMod("TotemPlacementTime", "BASE", 0.6, "Base")
	modDB:NewMod("BallistaPlacementTime", "BASE", 0.35, "Base")
	modDB:NewMod("ShockStacksMax", "BASE", 1, "Base")
	modDB:NewMod("ChillStacksMax", "BASE", 1, "Base")
	modDB:NewMod("ScorchStacksMax", "BASE", 1, "Base")
	modDB:NewMod("MovementSpeed", "INC", -30, "Base", { type = "Condition", var = "Maimed" })
	modDB:NewMod("Evasion", "INC", -15, "Base", { type = "Condition", var = "Maimed" })
	modDB:NewMod("MovementSpeed", "INC", -30, "Base", { type = "Condition", var = "Hindered" })
	modDB:NewMod("AilmentThreshold", "BASE", 50, "Base", { type = "PercentStat", stat = "Life", percent = 1 })
	modDB:NewMod("PoiseThreshold", "BASE", 50, "Base", { type = "PercentStat", stat = "Life", percent = 1 })
	modDB:NewMod("DamageTaken", "INC", 10, "Base", { type = "Condition", var = "Intimidated"})
	modDB:NewMod("DamageTaken", "INC", 10, "Base", { type = "Condition", var = "Intimidated", neg = true}, { type = "Condition", var = "Party:Intimidated"})
	modDB:NewMod("Damage", "INC", -10, "Base", { type = "Condition", var = "Intimidated"})
	modDB:NewMod("Damage", "INC", -10, "Base", { type = "Condition", var = "Intimidated", neg = true}, { type = "Condition", var = "Party:Intimidated"})
	modDB:NewMod("DamageTaken", "INC", 10, "Base", ModFlag.Spell, { type = "Condition", var = "Unnerved"})
	modDB:NewMod("DamageTaken", "INC", 10, "Base", ModFlag.Spell, { type = "Condition", var = "Unnerved", neg = true}, { type = "Condition", var = "Party:Unnerved"})
	modDB:NewMod("Damage", "MORE", -10, "Base", { type = "Condition", var = "Debilitated"})
	modDB:NewMod("DamageGainAsRandom", "BASE", 2, "Faerie Fire", { type = "Multiplier", var = "FaerieFireStack", limit = 10, actor = "enemy" })
	modDB:NewMod("Condition:Burning", "FLAG", true, "Base", { type = "IgnoreCond" }, { type = "Condition", var = "Ignited" })
	modDB:NewMod("Condition:Poisoned", "FLAG", true, "Base", { type = "IgnoreCond" }, { type = "MultiplierThreshold", var = "PoisonStack", threshold = 1 })
	modDB:NewMod("ShockBase", "BASE", data.gameConstants["BaseShockMagnitude"], "Base", { type = "ActorCondition", actor = "enemy", var = "Shocked" })
	modDB:NewMod("ChillBase", "BASE", 30, "Base", { type = "ActorCondition", actor = "enemy", var = "Chilled" })
	modDB:NewMod("Blind", "FLAG", true, "Base", { type = "Condition", var = "Blinded" })
	modDB:NewMod("Chill", "FLAG", true, "Base", { type = "Condition", var = "Chilled" })
	modDB:NewMod("Freeze", "FLAG", true, "Base", { type = "Condition", var = "Frozen" })
	modDB:NewMod("Fortify", "FLAG", true, "Base", { type = "Condition", var = "Fortify" })
	modDB:NewMod("Fortified", "FLAG", true, "Base", { type = "Condition", var = "Fortified" })
	modDB:NewMod("Fanaticism", "FLAG", true, "Base", { type = "Condition", var = "Fanaticism" })
	modDB:NewMod("Onslaught", "FLAG", true, "Base", { type = "Condition", var = "Onslaught" })
	modDB:NewMod("UnholyMight", "FLAG", true, "Base", { type = "Condition", var = "UnholyMight" })
	modDB:NewMod("ChaoticMight", "FLAG", true, "Base", { type = "Condition", var = "ChaoticMight" })
	modDB:NewMod("Adrenaline", "FLAG", true, "Base", { type = "Condition", var = "Adrenaline" })
	modDB:NewMod("LesserMassiveShrine", "FLAG", true, "Base", { type = "Condition", var = "LesserMassiveShrine" })
	modDB:NewMod("LesserBrutalShrine", "FLAG", true, "Base", { type = "Condition", var = "LesserBrutalShrine" })
	modDB:NewMod("DiamondShrine", "FLAG", true, "Base", { type = "Condition", var = "DiamondShrine" })
	modDB:NewMod("MassiveShrine", "FLAG", true, "Base", { type = "Condition", var = "MassiveShrine" })
	modDB:NewMod("AlchemistsGenius", "FLAG", true, "Base", { type = "Condition", var = "AlchemistsGenius" })
	modDB:NewMod("LuckyHits", "FLAG", true, "Base", { type = "Condition", var = "LuckyHits" })
	modDB:NewMod("HeavyStunBuildup", "MORE", 50, "Base", { type = "Condition", var = "Dazed"})
	modDB:NewMod("ColdCannotHeavyStun", "FLAG", true)
	modDB:NewMod("Convergence", "FLAG", true, "Base", { type = "Condition", var = "Convergence" })
	modDB:NewMod("PhysicalDamageReduction", "BASE", -15, "Base", { type = "Condition", var = "Crushed" })
	modDB:NewMod("CritChanceCap", "BASE", 100, "Base")
	modDB:NewMod("PresenceRadius", "BASE", data.characterConstants["base_presence_radius"], "Base")
	modDB:NewMod("SurroundedRadius", "BASE", data.misc.SurroundedRadiusBase, "Base")
	modDB:NewMod("SurroundedMinimum", "BASE", data.gameConstants["BaseRequiredEnemiesToBeConsideredSurrounded"], "Base")
	modDB.conditions["Buffed"] = env.mode_buffs
	modDB.conditions["Combat"] = env.mode_combat
	modDB.conditions["Effective"] = env.mode_effective
end

local function capitaliseWord(a, b)
	return a .. string.lower(b)
end

local function getCorruptedJewelEffect(env, item, node)
	if not item or item.type ~= "Jewel" or not item.corrupted or not node or node.containJewelSocket or node.sinister or item.base.subType == "Charm" then
		return 0
	end
	local rarity = item.rarity:gsub("(%a)(%u*)", capitaliseWord)
	return env.modDB.multipliers["Corrupted" .. rarity .. "JewelEffect"] or 0
end

local function runRadiusJewelFunc(rad, node, out, data)
	local scale = rad.effectScale
	if not scale or scale == 1 then
		rad.func(node, out, data)
		return
	end

	local start = #out
	rad.func(node, out, data)
	if #out == start then
		return
	end

	local scaledList = new("ModList"):ModList()
	for i = start + 1, #out do
		scaledList:AddMod(out[i])
	end
	for i = #out, start + 1, -1 do
		t_remove(out, i)
	end
	out:ScaleAddList(scaledList, scale)

	for i = start + 1, #out do
		local mod = out[i]
		if mod.parsedLine then
			local value = mod.value
			while type(value) == "table" and value.mod do
				value = value.mod.value
			end
			if type(value) == "table" then
				value = value.value
			end
			if type(value) == "number" then
				mod.parsedLine = mod.parsedLine:gsub("%d*%.?%d+", math.abs(value), 1)
			end
		end
	end
end

local function refreshJewelStatCache(env)
	local normalNode = { type = "Normal" }
	local attributeNode = { type = "Normal", isAttribute = true }
	local notableNode = { type = "Notable" }
	GlobalCache.cachedData[env.mode].radiusJewelData = { }

	for _, rad in pairs(env.radiusJewelList) do
		if not GlobalCache.cachedData[env.mode].radiusJewelData[rad.nodeId] then
			GlobalCache.cachedData[env.mode].radiusJewelData[rad.nodeId] = { }
			GlobalCache.cachedData[env.mode].radiusJewelData[rad.nodeId].hash = rad.jewelHash
			GlobalCache.cachedData[env.mode].radiusJewelData[rad.nodeId].smallModList = new("ModList"):ModList()
			GlobalCache.cachedData[env.mode].radiusJewelData[rad.nodeId].attributeModList = new("ModList"):ModList()
			GlobalCache.cachedData[env.mode].radiusJewelData[rad.nodeId].notableModList = new("ModList"):ModList()
		end
		runRadiusJewelFunc(rad, normalNode, GlobalCache.cachedData[env.mode].radiusJewelData[rad.nodeId].smallModList, rad.data)
		runRadiusJewelFunc(rad, attributeNode, GlobalCache.cachedData[env.mode].radiusJewelData[rad.nodeId].attributeModList, rad.data)
		runRadiusJewelFunc(rad, notableNode, GlobalCache.cachedData[env.mode].radiusJewelData[rad.nodeId].notableModList, rad.data)
	end
end

-- Recycle a modlist so that we do not allocate many tables for each node.
local function resetModList(list)
	for i = #list, 1, -1 do
		list[i] = nil
	end
	list.multipliers = wipeTable(list.multipliers)
	list.conditions = wipeTable(list.conditions)
	list.actor = wipeTable(list.actor)
	list.parent = false
	return list
end

---@param reuse table|nil A ModList to recycle instead of allocating. Only safe when the caller discards the result.
function calcs.buildModListForNode(env, node, reuse, incSmallPassiveSkill, includeKeystoneMods)
	local localSmallIncEffect = 0
	local localNotableIncEffect = 0
	local modList = reuse and resetModList(reuse) or new("ModList"):ModList()
	if node.type == "Keystone" then
		if includeKeystoneMods then
			modList:AddList(node.modList)
		end
		if node.keystoneMod then
			modList:AddMod(node.keystoneMod)
		end
	else
		modList:AddList(node.modList)
	end

	if #env.radiusJewelList > 0 and not GlobalCache.cachedData[env.mode].radiusJewelData then
		refreshJewelStatCache(env)
	end
	-- Run first pass radius jewels // jewel functions caught by jewelOtherFuncs
	for _, rad in pairs(env.radiusJewelList) do
		if rad.type == "Other" and rad.nodes[node.id] and rad.nodes[node.id].type ~= "Mastery" then
			if rad.item.baseName:find("Time%-Lost") == nil and rad.item.baseName:find("Timeless Jewel") == nil then
				runRadiusJewelFunc(rad, node, modList, rad.data)
			elseif node.type == "Normal" or node.type == "Notable" then
				local cache = GlobalCache.cachedData[env.mode].radiusJewelData[rad.nodeId]
				if not cache or (cache.hash ~= rad.jewelHash) then
					refreshJewelStatCache(env)
				end
				if node.type == "Normal" and node.isAttribute and cache and #cache.attributeModList > 0 then
					modList:CopyList(cache.attributeModList)
				elseif node.type == "Normal" and not node.isAttribute and cache and #cache.smallModList > 0 then
					modList:CopyList(cache.smallModList)
				elseif node.type == "Notable" and cache and #cache.notableModList > 0 then
					modList:CopyList(cache.notableModList)
				end
				break
			end
		end
	end

	-- prefilter the modlist so that every :Flag() call does not have to go through the entire mod list
	local hasNoEffect, hasAllocNoEffect, hasScale, hasOtherEffect, hasExtraSkill, hasExplode
	for i = 1, #modList do
		local name = modList[i].name
		if name == "PassiveSkillHasNoEffect" then
			hasNoEffect = true
		elseif name == "AllocatedPassiveSkillHasNoEffect" then
			hasAllocNoEffect = true
		elseif name == "PassiveSkillEffect" then
			hasScale = true
		elseif name == "PassiveSkillHasOtherEffect" then
			hasOtherEffect = true
		elseif name == "ExtraSkill" then
			hasExtraSkill = true
		elseif name == "CanExplode" then
			hasExplode = true
		end
	end

	if (hasNoEffect and modList:Flag(nil, "PassiveSkillHasNoEffect")) or (env.allocNodes[node.id] and (hasAllocNoEffect and modList:Flag(nil, "AllocatedPassiveSkillHasNoEffect"))) then
		wipeTable(modList)
		hasScale = false
		hasOtherEffect = nil
		hasExtraSkill = nil
		hasExplode = nil
	end

	-- Apply effect scaling
	if hasScale then
		local scale = calcLib.mod(modList, nil, "PassiveSkillEffect")
		if scale ~= 1 then
			local scaledList = new("ModList"):ModList()
			scaledList:ScaleAddList(modList, scale)
			modList = scaledList
		end
	end

	-- Run second pass radius jewels
	local rescan = false
	for i = 1, #env.radiusJewelList do
		local rad = env.radiusJewelList[i]
		if rad.nodes[node.id] and rad.nodes[node.id].type ~= "Mastery" and (rad.type == "Threshold" or (rad.type == "Self" and env.allocNodes[node.id]) or (rad.type == "SelfUnalloc" and not env.allocNodes[node.id])) then
			runRadiusJewelFunc(rad, node, modList, rad.data)
			rescan = true
			hasOtherEffect = nil
			hasExtraSkill = nil
			hasExplode = nil
		end
	end

	if rescan then
		for i = 1, #modList do
			local name = modList[i].name
			if name == "PassiveSkillHasOtherEffect" then
				hasOtherEffect = true
			elseif name == "ExtraSkill" then
				hasExtraSkill = true
			elseif name == "CanExplode" then
				hasExplode = true
			end
		end
	end

	if hasOtherEffect and modList:Flag(nil, "PassiveSkillHasOtherEffect") then
		local newMods = modList:List(nil, "NodeModifier")
		for i = 1, #newMods do
			local mod = newMods[i].mod
			if i == 1 then
				wipeTable(modList)
				hasExtraSkill = nil
				hasExplode = nil
			end
			if mod.name == "ExtraSkill" then
				hasExtraSkill = true
			elseif mod.name == "CanExplode" then
				hasExplode = true
			end
			modList:AddMod(mod)
		end
	end

	node.grantedSkills = wipeTable(node.grantedSkills)
	if hasExtraSkill then
		local list = modList:List(nil, "ExtraSkill")
		for i = 1, #list do
			local skill = list[i]
			if skill.name ~= "Unknown" then
				t_insert(node.grantedSkills, {
					skillId = skill.skillId,
					level = skill.level,
					noSupports = true,
					source = "Tree:" .. node.id
				})
			end
		end
	end

	if hasExplode then
		if modList:Flag(nil, "CanExplode") then
			t_insert(env.explodeSources, node)
		end
	end

	for i, mod in ipairs(modList) do
		local added = false
		for j = #mod, 1, -1 do
			if mod[j].type == "Condition" and mod[j].var and mod[j].var:match("^WeaponSet") then
				added = true
				if node.allocMode ~= 0 then -- only update the conditional for WS1/WS2
					mod[j].var = "WeaponSet".. node.allocMode
				else -- if normal and condition exists, remove it
					t_remove(mod, j)
				end
			end
		end
		-- only add the conditional for WS1/WS2
		if not added and node.allocMode ~= 0 then
			table.insert(mod, { type = "Condition", var = "WeaponSet".. node.allocMode })
		elseif mod.parsedLine then
			local jewelSource = tonumber(mod.source:match("%d+"))
			if env.build.spec.nodes[jewelSource].allocMode ~= 0 then
				table.insert(mod, { type = "Condition", var = "WeaponSet".. env.build.spec.nodes[jewelSource].allocMode })
			end
		end

		local hasWSCondition = false
		-- if the jewelMod has a WS Condition, only add the incEffect given it matches the activeWeaponSet
		-- otherwise the mod came from a jewel that is allocMode 0, so it always applies
		if mod.name == "JewelSmallPassiveSkillEffect" then
			for _, modCriteria in ipairs(mod) do
				if modCriteria.type == "Condition" and modCriteria.var and modCriteria.var:match("^WeaponSet") then
					if (tonumber(modCriteria.var:match("(%d)")) == (env.build.itemsTab.activeItemSet.useSecondWeaponSet and 2 or 1)) then
						localSmallIncEffect = mod.value
					end
					hasWSCondition = true
				end
			end
			if not hasWSCondition then
				localSmallIncEffect = mod.value
			end
		end
		if mod.name == "JewelNotablePassiveSkillEffect" then
			for _, modCriteria in ipairs(mod) do
				if modCriteria.type == "Condition" and modCriteria.var and modCriteria.var:match("^WeaponSet") then
					if (tonumber(modCriteria.var:match("(%d)")) == (env.build.itemsTab.activeItemSet.useSecondWeaponSet and 2 or 1)) then
						localNotableIncEffect = mod.value
					end
					hasWSCondition = true
				end
			end
			if not hasWSCondition then
				localNotableIncEffect = mod.value
			end
		end
	end

	-- Apply Inc Node scaling from Hulking Form
	if (incSmallPassiveSkill + localSmallIncEffect) > 0 and node.type == "Normal" and not node.isAttribute and not node.ascendancyName then
		local scale = 1 + (incSmallPassiveSkill + localSmallIncEffect) / 100
		local scaledList = new("ModList"):ModList()
		scaledList:ScaleAddList(modList, scale)
		modList = scaledList
	end

	if localNotableIncEffect > 0 and node.type == "Notable" and not node.isAttribute and not node.ascendancyName then
		local scale = 1 + localNotableIncEffect / 100
		local scaledList = new("ModList"):ModList()
		scaledList:ScaleAddList(modList, scale)
		modList = scaledList
	end

	return modList
end

-- Build list of modifiers from the listed tree nodes
function calcs.buildModListForNodeList(env, nodeList, finishJewels, includeKeystoneMods)
	-- Initialise radius jewels
	for _, rad in pairs(env.radiusJewelList) do
		wipeTable(rad.data)
		rad.data.modSource = "Tree:"..rad.nodeId
	end

	-- calculate inc from SmallPassiveSkillEffect
	local inc = 0
	for _, node in pairs(nodeList) do
		inc = inc + node.modList:Sum("INC", nil ,"SmallPassiveSkillEffect")
	end

	-- Add node modifiers
	local modList = new("ModList"):ModList()
	-- Outside MAIN mode the per-node list is merged into modList and then
	-- dropped, so a single list can be recycled for every node instead of
	-- allocating one each time.
	local scratch = env.mode ~= "MAIN" and new("ModList"):ModList() or nil
	for _, node in pairs(nodeList) do
		local nodeModList = calcs.buildModListForNode(env, node, scratch, inc, includeKeystoneMods)
		modList:AddList(nodeModList)
		if env.mode == "MAIN" then
			node.finalModList = nodeModList
		end
	end

	if finishJewels then
		-- Process extra radius nodes; these are unallocated nodes near conversion or threshold jewels that need to be processed
		for _, node in pairs(env.extraRadiusNodeList) do
			local nodeModList = calcs.buildModListForNode(env, node, scratch, inc)
			if env.mode == "MAIN" then
				node.finalModList = nodeModList
			end
		end

		-- Finalise radius jewels
		for _, rad in pairs(env.radiusJewelList) do
			runRadiusJewelFunc(rad, nil, modList, rad.data)
			if env.mode == "MAIN" then
				if not rad.item.jewelRadiusData then
					rad.item.jewelRadiusData = { }
				end -- used to calc Attributes in radius in itemsTab
				rad.item.jewelRadiusData[rad.nodeId] = rad.data
			end
		end
	end

	return modList
end

function wipeEnv(env, accelerate)
	-- Always wipe the below as we will be pushing in the modifiers,
	-- multipliers and conditions for player and enemy DBs via `parent`
	-- extensions of those DBs later which allow us to do a table-pointer
	-- link and save time on having to do a copyTable() function.
	wipeTable(env.modDB.mods)
	wipeTable(env.modDB.conditions)
	wipeTable(env.modDB.multipliers)
	wipeTable(env.enemyDB.mods)
	wipeTable(env.enemyDB.conditions)
	wipeTable(env.enemyDB.multipliers)
	if env.minion then
		wipeTable(env.minion.modDB.mods)
		wipeTable(env.minion.modDB.conditions)
		wipeTable(env.minion.modDB.multipliers)
	end

	if accelerate.everything then
		return
	end

	-- Passive tree node allocations
	-- Also in a further pass tracks Legion influenced mods
	if not accelerate.nodeAlloc then
		wipeTable(env.allocNodes)
		-- Usually states: `Allocates <NAME>` (e.g., amulet anointment)
		wipeTable(env.grantedPassives)
		wipeTable(env.grantedSkillsNodes)
	end

	if not accelerate.requirementsItems then
		-- Item-related tables
		wipeTable(env.itemModDB.mods)
		wipeTable(env.itemModDB.conditions)
		wipeTable(env.itemModDB.multipliers)
		-- 1) Jewels and Jewel-Radius related node modifications
		-- 2) Player items
		-- 3) Granted Skill from items (e.g., Curse on Hit rings)
		-- 4) Flasks
		wipeTable(env.radiusJewelList)
		wipeTable(env.extraRadiusNodeList)
		wipeTable(env.player.itemList)
		wipeTable(env.grantedSkillsItems)
		wipeTable(env.flasks)
		wipeTable(env.charms)

		-- Special / Unique Items that have their own ModDB()
		if env.talismanModList then
			wipeTable(env.talismanModList)
		end
		if env.theIronMass then
			wipeTable(env.theIronMass)
		end
		if env.weaponModList1 then
			wipeTable(env.weaponModList1)
		end

		-- Requirements from Items (Str, Dex, Int)
		wipeTable(env.requirementsTableItems)
	end

	-- Requirements from Gems (Str, Dex, Int)
	if not accelerate.requirementsGems then
		wipeTable(env.requirementsTableGems)
	end

	if not accelerate.skills then
		-- Player Active Skills generation
		wipeTable(env.player.activeSkillList)
		env.sourceGemPropertyInfo = { }

		-- Enhances Active Skills with skill ModFlags, KeywordFlags
		-- and modifiers that affect skill scaling (e.g., global buffs/effects)
		wipeTable(env.auxSkillList)
	end
end

local function getGemModList(env, groupCfg, socketColor, socketNum)
	local gemCfg = copyTable(groupCfg, true)
	gemCfg.socketColor = socketColor
	gemCfg.socketNum = socketNum
	return env.modDB:Tabulate("LIST", gemCfg, "GemProperty")
end

local function applyGemMods(effect, modList)
	for _, mod in ipairs(modList) do
		local match = true
		local value = mod.value
		if value.keywordList then
			for _, keyword in ipairs(value.keywordList) do
				if not calcLib.gemIsType(effect, keyword, true) then
					match = false
					break
				end
			end
		elseif not calcLib.gemIsType(effect, value.keyword, true) then
			match = false
		end
		if value.gemRequirements then
			for req, val in pairs(value.gemRequirements) do
				match = match and effect.gemData[req] > val
			end
		end
		if match then
			effect[value.key] = (effect[value.key] or 0) + value.value
			effect.gemPropertyInfo = effect.gemPropertyInfo or {}
			t_insert(effect.gemPropertyInfo, mod)
		end
	end
end

local function applySocketMods(env, gem, groupCfg, socketNum, modSource)
	local socketCfg = copyTable(groupCfg, true)
	socketCfg.skillGem = gem
	socketCfg.socketNum = socketNum
	for _, value in ipairs(env.modDB:List(socketCfg, "SocketProperty")) do
		env.player.modDB:AddMod(modLib.setSource(value.value, modSource or groupCfg.slotName or ""))
	end
end

local function addBestSupport(supportEffect, appliedSupportList, mode)
	local add = true
	for index, otherSupport in ipairs(appliedSupportList) do
		-- Check if there's another better support already present
		if supportEffect.grantedEffect == otherSupport.grantedEffect then
			add = false
			if supportEffect.level > otherSupport.level or (supportEffect.level == otherSupport.level and supportEffect.quality > otherSupport.quality) then
				if mode == "MAIN" then
					otherSupport.superseded = true
				end
				appliedSupportList[index] = supportEffect
			else
				supportEffect.superseded = true
			end
			break
		elseif supportEffect.grantedEffect.gemFamily and otherSupport.grantedEffect.gemFamily then
			for _, family in ipairs(supportEffect.grantedEffect.gemFamily) do
				for _, otherFamily in ipairs(otherSupport.grantedEffect.gemFamily) do
					if family == otherFamily then
						add = false
						if mode == "MAIN" then
							otherSupport.superseded = true
						end
						appliedSupportList[index] = supportEffect
						break
					end
				end
			end
		elseif supportEffect.grantedEffect.plusVersionOf == otherSupport.grantedEffect.id then
			add = false
			if mode == "MAIN" then
				otherSupport.superseded = true
			end
			appliedSupportList[index] = supportEffect
		elseif otherSupport.grantedEffect.plusVersionOf == supportEffect.grantedEffect.id then
			add = false
			supportEffect.superseded = true
		end
	end
	if add then
		t_insert(appliedSupportList, supportEffect)
	end
end

local function processGrantedEffect(grantedEffect, gemInstance, env, groupCfg, gemIndex, propertyModList, processedSockets, targetListList)
	if not grantedEffect or not grantedEffect.support then
		return
	end
	local supportEffect = {
		grantedEffect = grantedEffect,
		level = gemInstance.level,
		quality = gemInstance.quality,
		srcInstance = gemInstance,
		gemData = gemInstance.gemData,
		superseded = false,
		isSupporting = {},
	}
	if env.mode == "MAIN" then
		gemInstance.displayEffect = supportEffect
		gemInstance.supportEffect = supportEffect
	end
	if gemInstance.gemData then
		local playerItems = env.player.itemList
		local socketedIn = playerItems[groupCfg.slotName] and playerItems[groupCfg.slotName].sockets and playerItems[groupCfg.slotName].sockets[gemIndex]
		applyGemMods(supportEffect, socketedIn and getGemModList(env, groupCfg, socketedIn.color, gemIndex) or propertyModList)
		if not processedSockets[gemInstance] then
			processedSockets[gemInstance] = true
			applySocketMods(env, gemInstance.gemData, groupCfg, gemIndex, playerItems[groupCfg.slotName] and playerItems[groupCfg.slotName].name)
			-- Keep track of the gem count for each color socketed in this group
			groupCfg.intelligenceGems = (groupCfg.intelligenceGems or 0) + (gemInstance.gemData.tags.intelligence and 1 or 0)
			groupCfg.dexterityGems = (groupCfg.dexterityGems or 0) + (gemInstance.gemData.tags.dexterity and 1 or 0)
			groupCfg.strengthGems = (groupCfg.strengthGems or 0) + (gemInstance.gemData.tags.strength and 1 or 0)
		end
	end
	-- Validate support gem level in case there is no active skill (and no full calculation)
	calcLib.validateGemLevel(supportEffect)

	for _, targetList in ipairs(targetListList) do
		addBestSupport(supportEffect, targetList, env.mode)
	end
end
local function getNormalizedSkillLevel(grantedSkill)
	-- Levels in socketGroup.gemList[1].level are normalized
	-- grantedSkill.level is not causing group match miss which causes all things that rely on group order to fail
	local normalizedGrantedSkill = {
		grantedEffect = data.skills[grantedSkill.skillId],
		level = grantedSkill.level
	}
	calcLib.validateGemLevel(normalizedGrantedSkill)
	return normalizedGrantedSkill.level
end

local thornsStats = { "PhysicalMin", "PhysicalMax", "FireMin", "FireMax", "ColdMin", "ColdMax", "LightningMin", "LightningMax", "ChaosMin", "ChaosMax" }
local function modDBHasThornsDamage(modDB)
	for _, stat in ipairs(thornsStats) do
		local mods = modDB.mods[stat]
		if mods then
			for _, mod in ipairs(mods) do
				if mod.type == "BASE" and band(mod.flags or 0, ModFlag.Thorns) ~= 0 then
					return true
				end
			end
		end
	end
	return modDB.parent and modDBHasThornsDamage(modDB.parent)
end

local function defaultRadiusJewelFunc(node, out, data)
	-- Default function just tallies all stats in radius
	if node then
		for _, stat in pairs({ "Str", "Dex", "Int" }) do
			data[stat] = (data[stat] or 0) + out:Sum("BASE", nil, stat)
		end
	end
end
---@alias CalcEnvMode "MAIN"|"CALCS"|"CALCULATOR"
-- Initialise environment:
-- 1. Initialises the player and enemy modifier databases
-- 2. Merges modifiers for all items
-- 3. Builds a list of jewels with radius functions
-- 4. Merges modifiers for all allocated passive nodes
-- 5. Builds a list of active skills and their supports (calcs.createActiveSkill)
-- 6. Builds modifier lists for all active skills (calcs.buildActiveSkillModList)
---@param build Build
---@param mode CalcEnvMode
---@param override CalcOverride?
---@param specEnv any?
---@return Env
---@return ModDB? cachedPlayerDB
---@return ModDB? cachedEnemyDB
---@return ModDB? cachedMinionDB
function calcs.initEnv(build, mode, override, specEnv)
	-- accelerator variables
	local cachedPlayerDB = specEnv and specEnv.cachedPlayerDB or nil
	local cachedEnemyDB = specEnv and specEnv.cachedEnemyDB or nil
	local cachedMinionDB = specEnv and specEnv.cachedMinionDB or nil
	---@type Env?
	local env = specEnv and specEnv.env or nil
	local accelerate = specEnv and specEnv.accelerate or { }

	-- environment variables
	local override = override or { }
	local modDB = nil
	local enemyDB = nil
	local classStats = nil

	if not env then
		env = { }
		env.build = build
		env.data = build.data
		env.configInput = build.configTab.input
		env.configPlaceholder = build.configTab.placeholder
		env.calcsInput = build.calcsTab.input
		env.mode = mode
		env.buildBreakdown = mode == "MAIN" or mode == "CALCS"
		env.spec = override.spec or build.spec
		env.classId = env.spec.curClassId

		modDB = new("ModDB"):ModDB()
		env.modDB = modDB
		enemyDB = new("ModDB"):ModDB()
		env.enemyDB = enemyDB
		env.itemModDB = new("ModDB"):ModDB()

		env.enemyLevel = build.configTab.enemyLevel or m_min(data.misc.MaxEnemyLevel, build.characterLevel)

		-- Create player/enemy actors
		env.player = {
			modDB = env.modDB,
			level = build.characterLevel,
		}
		env.modDB.actor = env.player
		env.enemy = {
			modDB = env.enemyDB,
			level = env.enemyLevel,
		}
		enemyDB.actor = env.enemy
		env.player.enemy = env.enemy
		env.enemy.enemy = env.player
		enemyDB.actor.player = env.player
		env.modDB.actor.player = env.player

		-- Set up requirements tracking
		env.requirementsTableItems = { }
		env.requirementsTableGems = { }

		-- Prepare item, skill, flask tables
		env.radiusJewelList = wipeTable(env.radiusJewelList)
		env.extraRadiusNodeList = wipeTable(env.extraRadiusNodeList)
		env.player.itemList = { }
		env.grantedSkills = { }
		env.grantedSkillsNodes = { }
		env.grantedSkillsItems = { }
		env.explodeSources = { }
		env.itemWarnings = { }
		env.flasks = { }
		env.charms = { }

		-- tree based
		env.grantedPassives = { }

		-- skill-related
		env.player.activeSkillList = { }
		env.auxSkillList = { }
	--elseif accelerate.everything then
	--	local minionDB = nil
	--	env.modDB.parent, env.enemyDB.parent, minionDB = specCopy(env)
	--	if minionDB then
	--		env.minion.modDB.parent = minionDB
	--	end
	--	wipeEnv(env, accelerate)
	else
		wipeEnv(env, accelerate)
		modDB = env.modDB
		enemyDB = env.enemyDB
	end

	-- Set buff mode
	local buffMode
	if mode == "CALCS" then
		buffMode = env.calcsInput.misc_buffMode
	else
		buffMode = "EFFECTIVE"
	end
	if buffMode == "EFFECTIVE" then
		env.mode_buffs = true
		env.mode_combat = true
		env.mode_effective = true
	elseif buffMode == "COMBAT" then
		env.mode_buffs = true
		env.mode_combat = true
		env.mode_effective = false
	elseif buffMode == "BUFFED" then
		env.mode_buffs = true
		env.mode_combat = false
		env.mode_effective = false
	else
		env.mode_buffs = false
		env.mode_combat = false
		env.mode_effective = false
	end
	classStats = env.spec.tree.characterData and env.spec.tree.characterData[env.classId] or env.spec.tree.classes[env.classId]

	if not cachedPlayerDB then
		-- Initialise modifier database with base values
		for _, stat in pairs({"Str","Dex","Int"}) do
			modDB:NewMod(stat, "BASE", classStats["base_"..stat:lower()], "Base")
		end
		modDB.multipliers["Level"] = m_max(1, m_min(100, build.characterLevel))
		calcs.initModDB(env, modDB)
		modDB:NewMod("Life", "BASE", data.characterConstants["life_per_level"], "Base", { type = "Multiplier", var = "Level", base = 16 })
		modDB:NewMod("Mana", "BASE", data.characterConstants["mana_per_level"], "Base", { type = "Multiplier", var = "Level", base = 30 })
		modDB:NewMod("ManaRegen", "BASE", env.data.misc.ManaRegenBase, "Base", { type = "PerStat", stat = "Mana", div = 1 }, { type = "Condition", var = "NoInherentManaRegen", neg = true })
		modDB:NewMod("WardRegenPercent", "BASE", data.gameConstants["BaseWardRegenerationPercentPerMinute"]/60, "Base" )
		modDB:NewMod("Spirit", "BASE", 0, "Base")
		modDB:NewMod("Devotion", "BASE", 0, "Base")
		modDB:NewMod("Tribute", "BASE", 0, "Base")
		modDB:NewMod("Evasion", "BASE", data.characterConstants["base_evasion_rating"], "Base")
		modDB:NewMod("Accuracy", "BASE", data.characterConstants["accuracy_rating_per_level"], "Base", { type = "Multiplier", var = "Level", base = -data.characterConstants["accuracy_rating_per_level"] })
		modDB:NewMod("CritMultiplier", "BASE", data.characterConstants["base_critical_hit_damage_bonus"], "Base")
		modDB:NewMod("DotMultiplier", "BASE", 50, "Base", { type = "Condition", var = "CriticalStrike" })
		modDB:NewMod("FireResist", "BASE", env.configInput.resistancePenalty or -60, "Base")
		modDB:NewMod("ColdResist", "BASE", env.configInput.resistancePenalty or -60, "Base")
		modDB:NewMod("LightningResist", "BASE", env.configInput.resistancePenalty or -60, "Base")
		modDB:NewMod("ChaosResist", "BASE", 0, "Base")
		modDB:NewMod("TotemFireResist", "BASE", 40, "Base")
		modDB:NewMod("TotemColdResist", "BASE", 40, "Base")
		modDB:NewMod("TotemLightningResist", "BASE", 40, "Base")
		modDB:NewMod("TotemChaosResist", "BASE", 20, "Base")
		modDB:NewMod("MaximumFortification", "BASE", data.characterConstants["base_max_fortification"], "Base")
		modDB:NewMod("MaximumValour", "BASE", 50, "Base")
		modDB:NewMod("SoulEaterMax", "BASE", 45, "Base")
		modDB:NewMod("Multiplier:IntensityLimit", "BASE", 3, "Base")
		modDB:NewMod("Multiplier:DemonFlameMaximum", "BASE", 10, "Base")
		modDB:NewMod("Damage", "INC", data.characterConstants["damage_+%_per_10_rampage_stacks"], "Base", { type = "Multiplier", var = "Rampage", limit = data.characterConstants["max_rampage_stacks"] / 20, div = 20 })
		modDB:NewMod("MovementSpeed", "INC", data.characterConstants["movement_velocity_+%_per_10_rampage_stacks"], "Base", { type = "Multiplier", var = "Rampage", limit = data.characterConstants["max_rampage_stacks"] / 20, div = 20 })
		modDB:NewMod("Speed", "INC", 5, "Base", ModFlag.Attack, { type = "Multiplier", var = "SoulEater"})
		modDB:NewMod("Speed", "INC", 5, "Base", ModFlag.Cast, { type = "Multiplier", var = "SoulEater" })
		modDB:NewMod("ActiveTrapLimit", "BASE", data.characterConstants["base_number_of_traps_allowed"], "Base")
		modDB:NewMod("ActiveMineLimit", "BASE", data.characterConstants["base_number_of_remote_mines_allowed"], "Base")
		modDB:NewMod("MineThrowCount", "BASE", 1, "Base")
		modDB:NewMod("TrapThrowCount", "BASE", 1, "Base")
		modDB:NewMod("ActiveBrandLimit", "BASE", 3, "Base")
		modDB:NewMod("EnemyCurseLimit", "BASE", 1, "Base")
		modDB:NewMod("EnemyMarkLimit", "BASE", 1, "Base")
		modDB:NewMod("SocketedCursesHexLimitValue", "BASE", 1, "Base")
		modDB:NewMod("ProjectileCount", "BASE", 1, "Base")
		modDB:NewMod("PhysicalHeavyStunBuildup", "MORE", data.characterConstants["physical_hit_damage_stun_multiplier_+%_final_from_ot"], "Physical Damage")
		modDB:NewMod("EnemyHeavyStunBuildup", "MORE", data.characterConstants["melee_hit_damage_stun_multiplier_+%_final_from_ot"], "Melee Damage", ModFlag.Melee)
		modDB:NewMod("AilmentMagnitude", "MORE", 100, "Base", 0, KeywordFlag.Bleed, { type = "ActorCondition", actor = "enemy", varList = { "Moving", "BleedAggravated" } }, { type = "Condition", var = "NoExtraBleedDamageToMovingEnemy", neg = true })
		modDB:NewMod("Condition:BloodStance", "FLAG", true, "Base", { type = "Condition", var = "SandStance", neg = true })
		modDB:NewMod("Condition:PrideMinEffect", "FLAG", true, "Base", { type = "Condition", var = "PrideMaxEffect", neg = true })
		modDB:NewMod("MovementSpeed", "INC", 50, "Base", { type = "Condition", var = "Sprinting" })
		modDB:NewMod("Condition:CanSprint", "FLAG", true, "Base", { type = "Condition", var = "CannotSprint", neg = true })
		modDB:NewMod("PerBrutalTripleDamageChance", "BASE", data.characterConstants["chance_to_deal_triple_damage_%_per_brutal_charge"], "Base")
		modDB:NewMod("PerAfflictionAilmentDamage", "BASE", 8, "Base")
		modDB:NewMod("PerAfflictionNonDamageEffect", "BASE", 8, "Base")
		modDB:NewMod("PerAbsorptionElementalEnergyShieldRecoup", "BASE", data.characterConstants["elemental_damage_taken_goes_to_energy_shield_over_4_seconds_%_per_absorption_charge"], "Base")
		modDB:NewMod("CharmLimit", "BASE", 0, "Base")
		modDB:NewMod("ManaDegenPercent", "BASE", 1, "Base", { type = "Multiplier", var = "EffectiveManaBurnStacks" })
		modDB:NewMod("LifeDegenPercent", "BASE", 1, "Base", { type = "Multiplier", var = "WeepingWoundsStacks" })
		modDB:NewMod("WeaponSwapSpeed", "BASE", data.characterConstants["base_weapon_swap_duration_ms"], "Base")  -- 250ms
		modDB:NewMod("Speed", "INC", 2, "Base", ModFlag.Attack, { type = "Multiplier", var = "Tailwind", limit = 10 })
		modDB:NewMod("Speed", "INC", 2, "Base", ModFlag.Cast, { type = "Multiplier", var = "Tailwind", limit = 10 })
		modDB:NewMod("MovementSpeed", "INC", 1, "Base", { type = "Multiplier", var = "Tailwind", limit = 10 })
		modDB:NewMod("DeflectEffect", "INC", 1, "Base", { type = "Multiplier", var = "Tailwind", limit = 10 })
		modDB:NewMod("Evasion", "INC", 10, "Base", { type = "Multiplier", var = "Tailwind", limit = 10 })
		modDB:NewMod("SkillSlots", "BASE", 9, "Base")
		modDB:NewMod("MaxLineageCount", "BASE", 1, "Base")
		modDB:NewMod("Multiplier:AncestralBoostEffect", "BASE", 1, "Base", { type = "Condition", var = "AncestrallyBoosted" })
		modDB:NewMod("AncestralBoostMoreDamage", "BASE", 30, "Base", 0, 0, { type = "Multiplier", var = "AncestralBoostEffect" }, { type = "SkillType", skillType = SkillType.Slam }, { type = "Condition", var = "AncestrallyBoosted" })
		modDB:NewMod("AncestralBoostAreaOfEffect", "INC", 25, "Base", 0, 0, { type = "Multiplier", var = "AncestralBoostEffect" }, { type = "SkillType", skillType = SkillType.Slam }, { type = "Condition", var = "AncestrallyBoosted" })
		modDB:NewMod("AdditionalStrikeTarget", "BASE", 2, "Base", 0, 0, { type = "Multiplier", var = "AncestralBoostEffect" }, { type = "SkillType", skillType = SkillType.Slam, neg = true }, { type = "Condition", var = "AncestrallyBoosted" })
		modDB:NewMod("Condition:Empowered", "FLAG", 1, "Base", { type = "Condition", var = "AncestrallyBoosted" })


		-- Initialise enemy modifier database
		calcs.initModDB(env, enemyDB)
		enemyDB:NewMod("Accuracy", "BASE", env.data.monsterAccuracyTable[env.enemyLevel], "Base")
		enemyDB:NewMod("Condition:AgainstDamageOverTime", "FLAG", true, "Base", ModFlag.Dot, { type = "ActorCondition", actor = "player", var = "Combat" })

		-- Add mods from the config tab
		env.modDB:AddList(build.configTab.modList)
		env.enemyDB:AddList(build.configTab.enemyModList)

		-- Add mods from the party tab
		env.enemyDB:AddList(build.partyTab.enemyModList)

		cachedPlayerDB, cachedEnemyDB, cachedMinionDB = specCopy(env)
	else
		env.modDB.parent = cachedPlayerDB
		env.enemyDB.parent = cachedEnemyDB
		if cachedMinionDB and env.minion then
			env.minion.modDB.parent = cachedMinionDB
		end
	end

	if override.conditions then
		for _, flag in ipairs(override.conditions) do
			modDB.conditions[flag] = true
		end
	end

	local allocatedNotableCount = env.spec.allocatedNotableCount
	local allocatedSmithBodyArmourNodeCount = env.spec.allocatedSmithBodyArmourNodeCount
	local allocatedMasteryCount = env.spec.allocatedMasteryCount
	local allocatedMasteryTypeCount = env.spec.allocatedMasteryTypeCount
	local allocatedMasteryTypes = copyTable(env.spec.allocatedMasteryTypes)



	if not accelerate.nodeAlloc then
		-- Build list of passive nodes
		local nodes
		if override.addNodes or override.removeNodes then
			nodes = { }
			if override.addNodes then
				for node in pairs(override.addNodes) do
					if not node.allocMode then
						node.allocMode = 0
					end
					nodes[node.id] = node
					if node.type == "Mastery" then
						allocatedMasteryCount = allocatedMasteryCount + 1

						if not allocatedMasteryTypes[node.name] then
							allocatedMasteryTypes[node.name] = 1
							allocatedMasteryTypeCount = allocatedMasteryTypeCount + 1
						else
							local prevCount = allocatedMasteryTypes[node.name]
							allocatedMasteryTypes[node.name] = prevCount + 1
							if prevCount == 0 then
								allocatedMasteryTypeCount = allocatedMasteryTypeCount + 1
							end
						end
					elseif node.type == "Notable" then
						allocatedNotableCount = allocatedNotableCount + 1
						if node.applyToArmour then
							allocatedSmithBodyArmourNodeCount = allocatedSmithBodyArmourNodeCount + 1
						end
					end
				end
			end
			for _, node in pairs(env.spec.allocNodes) do
				if not override.removeNodes or not override.removeNodes[node] then
					nodes[node.id] = node
				elseif override.removeNodes[node] then
					if node.type == "Mastery" then
						allocatedMasteryCount = allocatedMasteryCount - 1

						allocatedMasteryTypes[node.name] = allocatedMasteryTypes[node.name] - 1
						if allocatedMasteryTypes[node.name] == 0 then
							allocatedMasteryTypeCount = allocatedMasteryTypeCount - 1
						end
					elseif node.type == "Notable" then
						allocatedNotableCount = allocatedNotableCount - 1
						if node.applyToArmour then
							allocatedSmithBodyArmourNodeCount = allocatedSmithBodyArmourNodeCount - 1
						end
					end
				end
			end
		else
			nodes = copyTable(env.spec.allocNodes, true)
		end
		env.allocNodes = nodes
		for nodeId, node in pairs(env.allocNodes) do
			if node.isGrantedPassive and node.isFreeAllocate then
				env.allocNodes[nodeId] = nil
			end
		end
	end

	local nodesModsList = calcs.buildModListForNodeList(env, env.allocNodes, true, true)
	env.useAltGemQualityStats = nodesModsList:Flag(nil, "GemlingQuality")
	local canUseBonded = nodesModsList:Flag(nil, "CanUseBonded")

	if allocatedNotableCount and allocatedNotableCount > 0 then
		modDB:NewMod("Multiplier:AllocatedNotable", "BASE", allocatedNotableCount)
	end
	if allocatedSmithBodyArmourNodeCount and allocatedSmithBodyArmourNodeCount > 0 then
		modDB:NewMod("Multiplier:AllocatedConnectedNotable", "BASE", allocatedSmithBodyArmourNodeCount)
	end
	if allocatedMasteryCount and allocatedMasteryCount > 0 then
		modDB:NewMod("Multiplier:AllocatedMastery", "BASE", allocatedMasteryCount)
	end
	if allocatedMasteryTypeCount and allocatedMasteryTypeCount > 0 then
		modDB:NewMod("Multiplier:AllocatedMasteryType", "BASE", allocatedMasteryTypeCount)
	end
	if allocatedMasteryTypes["Life Mastery"] and allocatedMasteryTypes["Life Mastery"] > 0 then
		modDB:NewMod("Multiplier:AllocatedLifeMastery", "BASE", allocatedMasteryTypes["Life Mastery"])
	end

	-- add Conditional WeaponSet# base on weapon set from item
	modDB:NewMod("Condition:WeaponSet" .. (build.itemsTab.activeItemSet.useSecondWeaponSet and 2 or 1) , "FLAG", true, "Weapon Set")

	local weaponFlagState = {
		giantsBlood = nodesModsList:Flag(nil, "GiantsBlood") or modDB:Flag(nil, "GiantsBlood") or false,
		instrumentsOfPower = nodesModsList:Flag(nil, "InstrumentsOfPower") or modDB:Flag(nil, "InstrumentsOfPower") or false,
		lordOfTheWilds = nodesModsList:Flag(nil, "LordOfTheWilds") or modDB:Flag(nil, "LordOfTheWilds") or false,
	}
	-- Only mutate equipped items in the real build pass; calculator overrides (e.g. node power) are transient.
	if mode == "MAIN" then
		local cache = build.itemsTab.lastWeaponFlagState
		local losingGiantsBlood = cache and cache.giantsBlood and not weaponFlagState.giantsBlood
		local losingInstrumentsOfPower = cache and cache.instrumentsOfPower and not weaponFlagState.instrumentsOfPower
		local losingLordOfTheWilds = cache and cache.lordOfTheWilds and not weaponFlagState.lordOfTheWilds
		if losingGiantsBlood or losingInstrumentsOfPower or losingLordOfTheWilds then -- Only validate socket when losing Keystone / Ascendancy
			build.itemsTab:ValidateWeaponSlots(weaponFlagState)
		end
		build.itemsTab.lastWeaponFlagState = { giantsBlood = weaponFlagState.giantsBlood, instrumentsOfPower = weaponFlagState.instrumentsOfPower, lordOfTheWilds = weaponFlagState.lordOfTheWilds }
	end

	-- Build and merge item modifiers, and create list of radius jewels
	if not accelerate.requirementsItems then
		local grantedNodes = env.spec:CollectGrantedPassiveNodesFromItems(build.itemsTab, env.allocNodes, env.configInput.ignoreJewelLimits, override, nodesModsList)
		if mode == "MAIN" then
			if build.spec:SetGrantedPassiveNodes(grantedNodes) then
				build.itemsTab:UpdateSockets()
			end
		end
		for _, node in pairs(grantedNodes) do
			addGrantedPassiveNode(env, node)
		end

		-- save augment counts so we can track going over count limits
		local augmentCounts = {}
		if modDB:Flag(nil, "SocketRunesOnCharacter") or nodesModsList:Flag(nil, "SocketRunesOnCharacter") then
			for runeSlotName, slot in pairs(build.itemsTab.runeSlots) do
				local rune = slot:GetSelValue()
				if runeSlotName == override.repSlotName then
					rune = override.repRune
				end
				if rune.name ~= "None" then
					augmentCounts[rune.name] = (augmentCounts[rune.name] or 0) + 1
				end
				for _, mod in ipairs(rune.mods) do
					env.itemModDB:AddMod(mod)
				end
			end
		end
		local items = {}
		local jewelLimits = {}
		local giantsBlood = weaponFlagState.giantsBlood
		local instrumentsOfPower = weaponFlagState.instrumentsOfPower
		local lordOfTheWilds = weaponFlagState.lordOfTheWilds
		for _, slot in pairs(build.itemsTab.orderedSlots) do
			local slotName = slot.slotName
			-- ignore item in Ring 3 if The Unseen Hand is not allocated
			if slotName == "Ring 3" and not nodesModsList:Flag(nil, "AdditionalRingSlot") then
				goto continue
			end
			local item
			if slotName == override.repSlotName then
				item = override.repItem
			elseif slot.nodeId and override.spec then
				item = build.itemsTab.items[env.spec.jewels[slot.nodeId]]
			else
				item = build.itemsTab.items[slot.selItemId]
			end
			-- if we are replacing the main hand weapon, we should unequip the off hand weapon if it's not allowed
			local overrideTwoHand = override.repItem and override.repItem.base.type and not (env.data.weaponTypeInfo[override.repItem.base.type] or {}).oneHand
			if overrideTwoHand and override.repSlotName and override.repSlotName:match("^Weapon 1") and slotName:match("^Weapon 2") then
				local allowLordOfTheWilds = lordOfTheWilds and override.repItem.base.type == "Talisman" and item and item.base.type == "Sceptre" and item.rarity ~= "UNIQUE" and item.rarity ~= "RELIC"
				local allowInstrumentsOfPower = instrumentsOfPower and override.repItem.base.type == "Staff" and item and item.base.type == "Focus"
				local allowGiantsBlood = giantsBlood and item and item.type ~= "Quiver" and (override.repItem.base.type == "Two Hand Sword" or override.repItem.base.type == "Two Hand Axe" or override.repItem.base.type == "Two Hand Mace")
				local allowQuiver = (override.repItem.base.type == "Bow" and item and item.base.type == "Quiver")
				local allowOffHand = allowLordOfTheWilds or allowInstrumentsOfPower or allowGiantsBlood or allowQuiver
				if not allowOffHand then
					goto continue
				end
			end
			if item and item.grantedSkills then
				-- Find skills granted by this item
				for _, skill in ipairs(item.grantedSkills) do
					local skillData = env.data.skills[skill.skillId]
					local grantedSkill = copyTable(skill)
					grantedSkill.nameSpec = skillData and skillData.name or nil
					grantedSkill.sourceItem = item
					grantedSkill.slotName = slotName
					t_insert(env.grantedSkillsItems, grantedSkill)
				end
			end
			if item and item.baseModList and item.baseModList:Flag(nil, "CanExplode") then
				t_insert(env.explodeSources, item)
			end

			if slot.weaponSet and slot.weaponSet ~= (build.itemsTab.activeItemSet.useSecondWeaponSet and 2 or 1) then
				goto continue
			end
			if slot.weaponSet == 2 and build.itemsTab.activeItemSet.useSecondWeaponSet then
				slotName = slotName:gsub(" Swap","")
			end
			local node = slot.nodeId and env.spec.nodes[slot.nodeId]
			if slot.nodeId then
				-- Slot is a jewel socket, check if socket is allocated
				if not env.allocNodes[slot.nodeId] then
					goto continue
				elseif item and not build.itemsTab:IsItemValidForSlot(item, slot.slotName) then
					goto continue
				elseif item then
					if item.jewelData then
						item.jewelData.limitDisabled = nil
					end
					if item and item.type == "Jewel" and item.name:match("The Adorned, Diamond") then
						if item.jewelData.corruptedMagicJewelIncEffect then
							env.modDB.multipliers["CorruptedMagicJewelEffect"] = item.jewelData.corruptedMagicJewelIncEffect / 100
						end
						if item.jewelData.corruptedRareJewelIncEffect then
							env.modDB.multipliers["CorruptedRareJewelEffect"] = item.jewelData.corruptedRareJewelIncEffect / 100
						end
					end
					if item.limit and not env.configInput.ignoreJewelLimits then
						local limitKey = item.base.subType == "Timeless" and "Historic" or item.title
						if jewelLimits[limitKey] and jewelLimits[limitKey] >= item.limit then
							if item.jewelData then
								item.jewelData.limitDisabled = true
							end
							env.itemWarnings.jewelLimitWarning = env.itemWarnings.jewelLimitWarning or { }
							t_insert(env.itemWarnings.jewelLimitWarning, limitKey)
							goto continue
						else
							jewelLimits[limitKey] = (jewelLimits[limitKey] or 0) + 1
						end
					end
					if item and not (node and node.sinister) and ( item.jewelRadiusIndex or (override and override.extraJewelFuncs and #override.extraJewelFuncs > 0) ) then
						-- Jewel has a radius, add it to the list
						local funcList = (item.jewelData and item.jewelData.funcList) or { { type = "Self", func = defaultRadiusJewelFunc } }
						for _, func in ipairs(funcList) do
							t_insert(env.radiusJewelList, {
								nodes = node.nodesInRadius and node.nodesInRadius[item.jewelRadiusIndex] or { },
								func = func.func,
								type = func.type,
								item = item,
								nodeId = slot.nodeId,
								attributes = node.attributesInRadius and node.attributesInRadius[item.jewelRadiusIndex] or { },
								data = { },
								-- store this to compare with cache later
								jewelHash = getHashFromString(item.modSource..item.raw)
							})
							if func.type ~= "Self" and node.nodesInRadius then
								-- Add nearby unallocated nodes to the extra node list
								for nodeId, node in pairs(node.nodesInRadius[item.jewelRadiusIndex]) do
									if not env.allocNodes[nodeId] then
										env.extraRadiusNodeList[nodeId] = env.spec.nodes[nodeId]
									end
								end
							end
						end
						for _, funcData in ipairs(override and override.extraJewelFuncs and override.extraJewelFuncs:List({item = item}, "ExtraJewelFunc") or {}) do
							local radius
							for index, data in pairs(data.jewelRadius) do
								if funcData.radius == data.label then
									radius = index
									break
								end
							end
							t_insert(env.radiusJewelList, {
								nodes = node.nodesInRadius and node.nodesInRadius[radius] or { },
								func = funcData.func,
								type = funcData.type,
								item = item,
								nodeId = slot.nodeId,
								attributes = node.attributesInRadius and node.attributesInRadius[radius] or { },
								data = { }
							})
							if funcData.type ~= "Self" and node.nodesInRadius then
								-- Add nearby unallocated nodes to the extra node list
								for nodeId, node in pairs(node.nodesInRadius[radius]) do
									if not env.allocNodes[nodeId] then
										env.extraRadiusNodeList[nodeId] = env.spec.nodes[nodeId]
									end
								end
							end
						end
					end
				end
			end
			items[slotName] = item
			::continue::
		end

		for _, rad in ipairs(env.radiusJewelList) do
			local effect = getCorruptedJewelEffect(env, rad.item, env.spec.nodes[rad.nodeId])
			if effect ~= 0 then
				rad.effectScale = 1 + effect
				rad.jewelHash = tostring(rad.jewelHash or getHashFromString(rad.item.modSource..rad.item.raw)) .. ":" .. rad.effectScale
			end
		end

		if not env.configInput.ignoreItemDisablers then
			local itemDisabled = {}
			local itemDisablers = {}
			if modDB:Flag(nil, "CanNotUseHelm") then
				itemDisabled["Helmet"] = { disabled = true, size = 1 }
			end
			for _, slot in pairs(build.itemsTab.orderedSlots) do
				local slotName = slot.slotName
				if items[slotName] then
					local srcList = items[slotName]:GetActiveModListForSlotNum(slot.slotNum, canUseBonded)
					for _, mod in ipairs(srcList) do
						-- checks if it disables another slot
						for _, tag in ipairs(mod) do
							if tag.type == "DisablesItem" then
								-- e.g. Tincture in Flask 5 while using a Micro-Distillery Belt
								if tag.excludeItemType and items[tag.slotName] and items[tag.slotName].type == tag.excludeItemType then
									break
								end
								itemDisablers[slotName] = tag.slotName
								itemDisabled[tag.slotName] = slotName
								break
							end
						end
					end
				end
			end
			local visited = {}
			local trueDisabled = {}
			for slot in pairs(itemDisablers) do
				if not visited[slot] then
					-- find chain start
					local curChain = { slot = true }
					while itemDisabled[slot] do
						slot = itemDisabled[slot]
						if curChain[slot] then break end -- detect cycles
						curChain[slot] = true
					end

					-- step through the chain of disabled items, disabling every other one
					repeat
						visited[slot] = true
						slot = itemDisablers[slot]
						if not slot then break end
						visited[slot] = true
						trueDisabled[slot] = true
						slot = itemDisablers[slot]
					until(not slot or visited[slot])
				end
			end
			for slot in pairs(trueDisabled) do
				items[slot] = nil
			end
		end

		for _, slot in pairs(build.itemsTab.orderedSlots) do
			local slotName = slot.slotName
			local item = items[slotName]
			local node = slot.nodeId and env.spec.nodes[slot.nodeId]
			if item and item.type == "Flask" then
				if slot.active then
					env.flasks[item] = true
				end
				if item.base.subType == "Life" then
					local highestLifeRecovery = env.itemModDB.multipliers["LifeFlaskRecovery"] or 0
					if item.flaskData.lifeTotal > highestLifeRecovery then
						env.itemModDB.multipliers["LifeFlaskRecovery"] = item.flaskData.lifeTotal
					end
				end
				env.itemModDB.multipliers[item.base.subType..slotName:gsub(" ", "").."MaxCharges"] = item.flaskData.chargesMax
				item = nil
			elseif item and item.type == "Charm" then
				if slot.active then
					env.charms[item] = true
				end
				item = nil
			end
			local scale = 1
			-- unequips Jewel if parentSlot providing the socket is removed
			if item and item.type == "Jewel" and slot.parentSlot then
				-- Check if the item in the parent slot has enough Jewel Sockets
				local parentItem = env.player.itemList[slot.parentSlot.slotName]
				local parentSlotHidden = slot.parentSlot.slotName == "Ring 3" and not (modDB:Flag(nil, "AdditionalRingSlot") or nodesModsList:Flag(nil, "AdditionalRingSlot"))
				if parentSlotHidden or not parentItem or parentItem.jewelSocketCount < slot.slotNum then
					item = nil
				else
					scale = parentItem.socketedJewelEffectModifier
				end
			end
			if slot.nodeId and item and item.type == "Jewel" and item.jewelData and item.jewelData.jewelIncEffectFromClassStart and not (node and node.sinister) then
				if node and node.distanceToClassStart then
					scale = scale + node.distanceToClassStart * (item.jewelData.jewelIncEffectFromClassStart / 100)
				end
			end

			local addSourceSlotNum = false
			if slot.nodeId and item and item.type == "Jewel" then
				if node and node.containJewelSocket then
					addSourceSlotNum = true
					local inc = node.modList:Sum("INC", nil, "SocketedJewelEffect")
					scale = scale + (inc / 100)
				end
			end

			if item then
				env.player.itemList[slotName] = item
				-- Merge mods for this item
				local srcList = item:GetActiveModListForSlotNum(slot.slotNum, canUseBonded)
				local corruptedJewelEffect = slot.nodeId and getCorruptedJewelEffect(env, item, node) or 0

				-- Remove Spirit Base if CannotGainSpiritFromEquipment flag is true
				if nodesModsList:Flag(nil, "CannotGainSpiritFromEquipment") then
					srcList = copyTable(srcList, true)
					for index = #srcList, 1, -1 do
						local mod = srcList[index]
						if mod.name == "Spirit" and mod.type == "BASE" then
							t_remove(srcList, index)
						end
					end
				end

				if addSourceSlotNum then
					srcList = copyTable(srcList, false)
					for _, mod in ipairs(srcList) do
						mod.sourceSlotNum = slot.slotNum
					end
				end

				if item.requirements and not accelerate.requirementsItems then
					t_insert(env.requirementsTableItems, {
						source = "Item",
						sourceItem = item,
						sourceSlot = slotName,
						Str = item.requirements.strMod,
						Dex = item.requirements.dexMod,
						Int = item.requirements.intMod,
					})
				end
				-- Rune / Soul Core / Idol Sockets
				local socketed = 0
				for i = 1, item.itemSocketCount do
					local runeName = item.runes[i]
					if runeName and runeName ~= "None" then
						augmentCounts[item.runes[i]] = (augmentCounts[item.runes[i]] or 0) + 1
						socketed = socketed + 1
						-- Track Idols vs non-Idol augments (Runes + Soul Cores) across all equipment
						local runeData = data.itemMods.Runes[runeName]
						local augType
						if runeData then
							for _, baseEntry in pairs(runeData) do
								if type(baseEntry) == "table" and baseEntry.type then
									augType = baseEntry.type
									break
								end
							end
						end
						if augType == "Idol" then
							env.itemModDB.multipliers["IdolsInEquipment"] = (env.itemModDB.multipliers["IdolsInEquipment"] or 0) + 1
						elseif augType then
							env.itemModDB.multipliers["NonIdolAugmentsInEquipment"] = (env.itemModDB.multipliers["NonIdolAugmentsInEquipment"] or 0) + 1
						end
					end
				end
				env.itemModDB.multipliers["RunesSocketedIn"..slotName] = socketed

				if item.type == "Jewel" and item.base.subType == "Abyss" then
					-- Update Abyss Jewel conditions/multipliers
					local cond = "Have"..item.baseName:gsub(" ","")
					if not env.itemModDB.conditions[cond] then
						env.itemModDB.conditions[cond] = true
						env.itemModDB.multipliers["AbyssJewelType"] = (env.itemModDB.multipliers["AbyssJewelType"] or 0) + 1
					end
					if slot.parentSlot then
						env.itemModDB.conditions[cond.."In"..slot.parentSlot.slotName] = true
					end
					env.itemModDB.multipliers["AbyssJewel"] = (env.itemModDB.multipliers["AbyssJewel"] or 0) + 1
					if item.rarity == "NORMAL" then env.itemModDB.multipliers["NormalAbyssJewels"] = (env.itemModDB.multipliers["NormalAbyssJewels"] or 0) + 1 end
					if item.rarity == "MAGIC" then env.itemModDB.multipliers["MagicAbyssJewels"] = (env.itemModDB.multipliers["MagicAbyssJewels"] or 0) + 1 end
					if item.rarity == "RARE" then env.itemModDB.multipliers["RareAbyssJewels"] = (env.itemModDB.multipliers["RareAbyssJewels"] or 0) + 1 end
					if item.rarity == "UNIQUE" or item.rarity == "RELIC" then env.itemModDB.multipliers["UniqueAbyssJewels"] = (env.itemModDB.multipliers["UniqueAbyssJewels"] or 0) + 1 end
					env.itemModDB.multipliers[item.baseName:gsub(" ","")] = (env.itemModDB.multipliers[item.baseName:gsub(" ","")] or 0) + 1
				end
				if item.type == "Amulet" and env.allocNodes[39935] and env.allocNodes[39935].dn == "Necromantic Talisman" then
					-- Special handling for Necromantic Talisman
					env.talismanModList = new("ModList"):ModList()
					for _, mod in ipairs(srcList) do
						-- add all Amulet mods (no more need to exclude for 'gems socketed in' mods)
						env.talismanModList:ScaleAddMod(mod, scale)
					end
				elseif (slotName == "Weapon 1" or slotName == "Weapon 2") and modDB.conditions["AffectedByEnergyBlade"] then
					local previousItem = env.player.itemList[slotName]
					local type = previousItem and previousItem.weaponData and previousItem.weaponData[1].type
					local info = env.data.weaponTypeInfo[type]
					if info and type ~= "Bow" then
						local name = info.oneHand and "Energy Blade One Handed" or "Energy Blade Two Handed"
						local item = new("Item"):Item()
						item.name = name
						item.base = data.itemBases[name]
						item.baseName = name
						item.classRequirementModLines = { }
						item.buffModLines = { }
						item.enchantModLines = { }
						item.implicitModLines = { }
						item.explicitModLines = { }
						item.quality = 0
						item.rarity = "NORMAL"
						if item.baseName.implicit then
							local implicitIndex = 1
							for line in item.baseName.implicit:gmatch("[^\n]+") do
								local modList, extra = modLib.parseMod(line)
								t_insert(item.implicitModLines, { line = line, extra = extra, modList = modList or { }, modTags = item.baseName.implicitModTypes and item.baseName.implicitModTypes[implicitIndex] or { } })
								implicitIndex = implicitIndex + 1
							end
						end
						item:NormaliseQuality()
						item:BuildAndParseRaw()
						item.sockets = previousItem.sockets
						item.itemSocketCount = previousItem.itemSocketCount
						env.player.itemList[slotName] = item
					else
						env.itemModDB:ScaleAddList(srcList, scale)
					end
				elseif slotName == "Weapon 1" and item.name == "The Iron Mass, Gladius" then
					-- Special handling for The Iron Mass
					env.theIronMass = new("ModList"):ModList()
					for _, mod in ipairs(srcList) do
						-- Filter out mods that apply to socketed gems, or which add supports
						local add = true
						for _, tag in ipairs(mod) do
							if tag.type == "SocketedIn" then
								add = false
								break
							end
						end
						if add then
							env.theIronMass:ScaleAddMod(mod, scale)
						end
						-- Add all the stats to player as well
						env.itemModDB:ScaleAddMod(mod, scale)
					end
				elseif slotName == "Weapon 1" and item.grantedSkills[1] and item.grantedSkills[1].skillId == "UniqueAnimateWeapon" then
					-- Special handling for The Dancing Dervish
					env.weaponModList1 = new("ModList"):ModList()
					for _, mod in ipairs(srcList) do
						-- Filter out mods that apply to socketed gems, or which add supports
						local add = true
						for _, tag in ipairs(mod) do
							if tag.type == "SocketedIn" then
								add = false
								break
							end
						end
						if add then
							env.weaponModList1:ScaleAddMod(mod, scale)
						else
							env.itemModDB:ScaleAddMod(mod, scale)
						end
					end
				elseif item.type == "Focus" and calcLib.mod(nodesModsList, nil, "EffectOfBonusesFromFocus") ~=1 then
					scale = calcLib.mod(nodesModsList, nil, "EffectOfBonusesFromFocus") - 1
					local combinedList = new("ModList"):ModList()
					for _, mod in ipairs(srcList) do
						combinedList:MergeMod(mod)
					end
					local scaledList = new("ModList"):ModList()
					scaledList:ScaleAddList(combinedList, scale)
					for _, mod in ipairs(scaledList) do
						combinedList:MergeMod(mod, true)
					end
					env.itemModDB:AddList(combinedList)
				elseif item.name:match("Kalandra's Touch") then
					-- Reset mult counters since they don't work for kalandra
					if item["corrupted"] then
						env.itemModDB.multipliers["CorruptedItem"] = (env.itemModDB.multipliers["CorruptedItem"] or 0) - 1
					else
						env.itemModDB.multipliers["NonCorruptedItem"] = (env.itemModDB.multipliers["NonCorruptedItem"] or 0) + 1
					end
					local otherRing = items[(slotName == "Ring 1" and "Ring 2") or (slotName == "Ring 2" and "Ring 1")]
					if otherRing and not otherRing.name:match("Kalandra's Touch") then
						for _, mod in ipairs(otherRing.modList or otherRing.slotModList[slot.slotNum] or {}) do
							-- Filter out SocketedIn type mods
							for _, tag in ipairs(mod) do
								if tag.type == "SocketedIn" then
									goto skip_mod
								end
							end

							local modCopy = copyTable(mod)
							modLib.setSource(modCopy, item.modSource)
							env.itemModDB:ScaleAddMod(modCopy, scale)

							::skip_mod::
						end
						-- Adjust multipliers based on other ring
						if item["corrupted"] then
							env.itemModDB.multipliers["CorruptedItem"] = (env.itemModDB.multipliers["CorruptedItem"] or 0) + 1
						else
							env.itemModDB.multipliers["NonCorruptedItem"] = (env.itemModDB.multipliers["NonCorruptedItem"] or 0) - 1
						end
					end

					-- Only ExtraSkill implicit mods work (none should but this is likely an in game bug)
					for _, mod in ipairs(srcList) do
						if mod.name == "ExtraSkill" then
							env.itemModDB:ScaleAddMod(mod, scale)
						end
					end
				elseif corruptedJewelEffect ~= 0 then
					scale = scale + corruptedJewelEffect
					local combinedList = new("ModList"):ModList()
					for _, mod in ipairs(srcList) do
						combinedList:MergeMod(mod)
					end
					env.itemModDB:ScaleAddList(combinedList, scale)
				else
					env.itemModDB:ScaleAddList(srcList, scale)
				end
				-- set conditions on restricted items
				if item.classRestriction then
					env.itemModDB.conditions[item.title:gsub(" ", "")] = item.classRestriction
				end
				if item.charmLimit then
					env.modDB:NewMod("CharmLimit", "BASE", item.charmLimit, item.title)
				end
				if item.spiritValue and not nodesModsList:Flag(nil, "CannotGainSpiritFromEquipment") then
					env.modDB:NewMod("Spirit", "BASE", item.spiritValue, item.title)
				end
				if item.type ~= "Jewel" and item.type ~= "Flask" and item.type ~= "Charm" then
					-- Update item counts
					local key
					if item.rarity == "UNIQUE" or item.rarity == "RELIC" then
						key = "UniqueItem"
					elseif item.rarity == "RARE" then
						key = "RareItem"
					elseif item.rarity == "MAGIC" then
						key = "MagicItem"
					else
						key = "NormalItem"
					end
					env.itemModDB.multipliers[key] = (env.itemModDB.multipliers[key] or 0) + 1
					env.itemModDB.conditions[key .. "In" .. slotName] = true
					if item["corrupted"] then
						env.itemModDB.multipliers["CorruptedItem"] = (env.itemModDB.multipliers["CorruptedItem"] or 0) + 1
					else
						env.itemModDB.multipliers["NonCorruptedItem"] = (env.itemModDB.multipliers["NonCorruptedItem"] or 0) + 1
					end

					env.itemModDB.multipliers[item.type:gsub(" ", ""):gsub(".+Handed", "").."Item"] = (env.itemModDB.multipliers[item.type:gsub(" ", ""):gsub(".+Handed", "").."Item"] or 0) + 1
				end
			end
		end
		if override.toggleFlask then
			if env.flasks[override.toggleFlask] then
				env.flasks[override.toggleFlask] = nil
			else
				env.flasks[override.toggleFlask] = true
			end
		end
		if override.toggleCharm then
			if env.charms[override.toggleCharm] then
				env.charms[override.toggleCharm] = nil
			else
				env.charms[override.toggleCharm] = true
			end
		end

		local augmentLimits = { }
		for augmentName, count in pairs(augmentCounts) do
			local dbAugment = data.itemMods.Runes[augmentName] or {}
			local _, dbMod = next(dbAugment)
			if dbMod and dbMod.limit then
				local limit = augmentLimits[dbMod.limitId or augmentName]
				if not limit then
					limit = { count = 0, max = dbMod.limit, names = { } }
					augmentLimits[dbMod.limitId or augmentName] = limit
				end
				limit.count += count
				t_insert(limit.names, augmentName)
			end
		end
		for _, limit in pairs(augmentLimits) do
			if limit.count > limit.max and env.build.calcsTab.mainEnv then
				table.sort(limit.names)
				env.build.calcsTab.mainEnv.itemWarnings.augmentLimitWarning = env.build.calcsTab.mainEnv.itemWarnings.augmentLimitWarning or { }
				t_insert(env.build.calcsTab.mainEnv.itemWarnings.augmentLimitWarning, table.concat(limit.names, ", "))
			end
		end
	end

	-- Merge env.itemModDB with env.ModDB
	mergeDB(env.modDB, env.itemModDB)

	-- Add granted passives (e.g., amulet anoints)
	if not accelerate.nodeAlloc then
		for _, passive in pairs(env.modDB:List(nil, "GrantedPassive")) do
			for _, node in ipairs(env.spec:ResolveGrantedPassiveNodes(passive)) do
				if node and (not override.removeNodes or not override.removeNodes[node.id]) then
					addGrantedPassiveNode(env, node)
				end
			end
		end
	end

	-- Add granted ascendancy node (e.g., Forbidden Flame/Flesh combo)
	local matchedName = { }
	for _, ascTbl in pairs(env.modDB:List(nil, "GrantedAscendancyNode")) do
		local name = ascTbl.name
		if matchedName[name] and matchedName[name].side ~= ascTbl.side and matchedName[name].matched == false then
			matchedName[name].matched = true
			local node = env.spec.tree.ascendancyMap[name]
			if node and (not override.removeNodes or not override.removeNodes[node.id]) then
				if env.itemModDB.conditions["ForbiddenFlesh"] == env.spec.curClassName and env.itemModDB.conditions["ForbiddenFlame"] == env.spec.curClassName then
					env.allocNodes[node.id] = node
					env.grantedPassives[node.id] = true
				end
			end
		else
			matchedName[name] = { side = ascTbl.side, matched = false }
		end
	end

	-- Merge modifiers for allocated passives
	env.modDB:AddList(calcs.buildModListForNodeList(env, env.allocNodes, true))

	if not override or (override and not override.extraJewelFuncs) then
		override = override or {}
		override.extraJewelFuncs = new("ModList"):ModList()
		override.extraJewelFuncs.actor = env.player
		for _, mod in ipairs(env.modDB:Tabulate("LIST", nil, "ExtraJewelFunc")) do
			override.extraJewelFuncs:AddMod(mod.mod)
		end
		if #override.extraJewelFuncs > 0 then
			return calcs.initEnv(build, mode, override, specEnv)
		end
	end

	if env.player.itemList["Weapon 2"] and env.player.itemList["Weapon 2"].type == "Quiver" then
		local quiverEffectMod = env.modDB:Sum("INC", nil, "EffectOfBonusesFromQuiver") / 100
		local modList = env.player.itemList["Weapon 2"]:GetActiveModListForSlotNum(2, canUseBonded)
		for _, mod in ipairs(modList) do
			local modCopy = copyTable(mod)
			modCopy.source = "Many Sources:".. colorCodes.SOURCE .. tostring(quiverEffectMod * 100) .. "% Quiver Bonus Effect"
			modDB:ScaleAddMod(modCopy, quiverEffectMod)
		end
	end
	
	if env.player.itemList["Amulet"] and env.player.itemList["Amulet"].type == "Amulet" then
		local amuletEffectMod = env.modDB:Sum("INC", nil, "EffectOfBonusesFromAmulet") / 100
		local modList = env.player.itemList["Amulet"]:GetActiveModListForSlotNum(nil, canUseBonded)
		for _, mod in ipairs(modList) do
			local modCopy = copyTable(mod)
			modCopy.source = "Many Sources:".. colorCodes.SOURCE .. tostring(amuletEffectMod * 100) .. "% Amulet Bonus Effect"
			modDB:ScaleAddMod(modCopy, amuletEffectMod)
		end
	end

	-- Find skills granted by tree nodes
	if not accelerate.nodeAlloc then
		for _, node in pairs(env.allocNodes) do
			if node.grantedSkills then
				for _, skill in ipairs(node.grantedSkills) do
					local grantedSkill = copyTable(skill)
					grantedSkill.sourceNode = node
					t_insert(env.grantedSkillsNodes, grantedSkill)
				end
			end
		end
	end

	-- Merge Granted Skills Tables
	env.grantedSkills = tableConcat(env.grantedSkillsNodes, env.grantedSkillsItems)

	local virtuousMoteSkillCount = accelerate.skills and env.virtuousMoteSkillCount or { Str = 3, Dex = 3, Int = 3 }
	local virtuousMoteSkillCounted = { }

	if not accelerate.skills then
		if env.mode == "MAIN" then
			-- Process extra skills granted by items or tree nodes
			local markList = wipeTable(tempTable1)
			for _, grantedSkill in ipairs(env.grantedSkills) do
				-- Check if a matching group already exists
				local group
				for index, socketGroup in pairs(build.skillsTab.socketGroupList) do
					if socketGroup.source == grantedSkill.source and socketGroup.slot == grantedSkill.slotName then
						if socketGroup.gemList[1] and socketGroup.gemList[1].skillId == grantedSkill.skillId and (socketGroup.gemList[1].level == grantedSkill.level or socketGroup.gemList[1].level == getNormalizedSkillLevel(grantedSkill)) then
							group = socketGroup
							markList[socketGroup] = true
							break
						end
					end
				end
				if not group then
					-- Create a new group for this skill
					group = { label = "", enabled = true, gemList = { }, source = grantedSkill.source, slot = grantedSkill.slotName }
					t_insert(build.skillsTab.socketGroupList, group)
					markList[group] = true
				end

				-- Update the group
				group.sourceItem = grantedSkill.sourceItem
				group.sourceNode = grantedSkill.sourceNode
				local activeGemInstance = group.gemList[1] or {
					skillId = grantedSkill.skillId,
					nameSpec = grantedSkill.nameSpec,
					quality = 0,
					enabled = true,
				}
				activeGemInstance.fromItem = grantedSkill.sourceItem ~= nil
				activeGemInstance.level = grantedSkill.level
				activeGemInstance.gemId = data.gemForSkill[data.skills[grantedSkill.skillId]]
				activeGemInstance.enableGlobal1 = true
				activeGemInstance.noSupports = grantedSkill.noSupports
				group.noSupports = grantedSkill.noSupports
				activeGemInstance.noReservation = grantedSkill.noReservation
				activeGemInstance.triggered = grantedSkill.triggered
				activeGemInstance.triggerChance = grantedSkill.triggerChance
				wipeTable(group.gemList)
				t_insert(group.gemList, activeGemInstance)
				build.skillsTab:ProcessSocketGroup(group)
			end

			if #env.explodeSources ~= 0 then
				-- Check if a matching group already exists
				local group
				for _, socketGroup in pairs(build.skillsTab.socketGroupList) do
					if socketGroup.source == "Explode" then
						group = socketGroup
						break
					end
				end
				if not group then
					-- Create a new group for this skill
					group = { label = "On Kill Monster Explosion", enabled = true, gemList = { }, source = "Explode", noSupports = true }
					t_insert(build.skillsTab.socketGroupList, group)
				end
				-- Hack to remove duplicates
				local explodeBySource = { }
				for _, explodeSource in ipairs(env.explodeSources) do
					explodeBySource[explodeSource.modSource or explodeSource.id] = explodeSource
				end
				-- Update the group
				group.explodeSources = explodeBySource
				local gemsBySource = { }
				for _, gem in ipairs(group.gemList) do
					if gem.explodeSource then
						gemsBySource[gem.explodeSource.modSource or gem.explodeSource.id] = gem
					end
				end
				wipeTable(group.gemList)
				for _, explodeSource in pairs(explodeBySource) do
					local activeGemInstance
					if gemsBySource[explodeSource.modSource or explodeSource.id] then
						activeGemInstance = gemsBySource[explodeSource.modSource or explodeSource.id]
					else
						activeGemInstance = {
							skillId = "EnemyExplode",
							quality = 0,
							enabled = true,
							level = 1,
							triggered = true,
							explodeSource = explodeSource,
						}
					end
					t_insert(group.gemList, activeGemInstance)
				end
				markList[group] = true
				build.skillsTab:ProcessSocketGroup(group)
			end

			do
				local hasThornsDamage = modDBHasThornsDamage(env.modDB)
				if not hasThornsDamage then
					for _, socketGroup in pairs(build.skillsTab.socketGroupList) do
						if socketGroup.source ~= "Thorns" and socketGroup.enabled ~= false then
							for _, gem in ipairs(socketGroup.gemList) do
								local grantedEffect = gem.enabled ~= false and env.data.skills[gem.skillId]
								if grantedEffect and grantedEffect.grantsThornsDamage then
									hasThornsDamage = true
									break
								end
							end
						end
						if hasThornsDamage then
							break
						end
					end
				end

				local group
				for _, socketGroup in pairs(build.skillsTab.socketGroupList) do
					if socketGroup.source == "Thorns" then
						group = socketGroup
						break
					end
				end
				if not hasThornsDamage then
					if group then
						wipeTable(group.gemList)
					end
				else
					if not group then
						group = { label = "Thorns", enabled = true, gemList = { }, source = "Thorns", noSupports = true }
						t_insert(build.skillsTab.socketGroupList, group)
					end

					group.thornsSources = env.thornsSources
					wipeTable(group.gemList)

					local activeGemInstance = {
						skillId = "ThornsPlayer",
						quality = 0,
						enabled = true,
						level = 1,
						triggered = true,
					}
					t_insert(group.gemList, activeGemInstance)
					markList[group] = true
					build.skillsTab:ProcessSocketGroup(group)
				end
			end


			-- Remove any socket groups that no longer have a matching item
			local i = 1
			while build.skillsTab.socketGroupList[i] do
				local socketGroup = build.skillsTab.socketGroupList[i]
				if socketGroup.source and not markList[socketGroup] then
					t_remove(build.skillsTab.socketGroupList, i)
					if build.skillsTab.displayGroup == socketGroup then
						build.skillsTab.displayGroup = nil
					end
				else
					i = i + 1
				end
			end
		end

		-- Get the weapon data tables for the equipped weapons
		env.player.weaponData1 = env.player.itemList["Weapon 1"] and env.player.itemList["Weapon 1"].weaponData and env.player.itemList["Weapon 1"].weaponData[1] or copyTable(env.data.unarmedWeaponData[env.classId])
		if env.player.weaponData1.countsAsDualWielding then
			env.player.weaponData2 = env.player.itemList["Weapon 1"].weaponData[2]
		elseif not env.player.itemList["Weapon 2"] then
			-- Hollow Palm Technique
			if (not env.player.itemList["Weapon 1"]) and env.modDB.mods.Keystone then
				for _, keystone in ipairs(env.modDB.mods.Keystone) do
					if keystone.value == "Hollow Palm Technique" then
						env.player.weaponData2 = copyTable(env.data.unarmedWeaponData[env.classId])
						for i = 1, 2 do
							env.player["weaponData" .. tostring(i)].asThoughUsing = env.player["weaponData" .. tostring(i)].asThoughUsing or { }
							env.player["weaponData" .. tostring(i)].asThoughUsing["Staff"] = true
						end
						env.player.modDB.conditions["HollowPalm"] = true -- Had to add condition here because it was otherwise not recognized correctly when "DisableSkill" is processed
						break
					end
				end
			end
			-- Facebreaker: Can Attack as though using a One Handed Mace while both of your hand slots are empty
			if (not env.player.itemList["Weapon 1"]) and env.modDB:Flag(nil, "CanAttackAsOneHandMaceUnarmed") then
				env.player.weaponData1.asThoughUsing = env.player.weaponData1.asThoughUsing or { }
				env.player.weaponData1.asThoughUsing["One Hand Mace"] = true
			end
			if (not env.player.itemList["Weapon 1"]) and env.modDB:Flag(nil, "UseFacebreakerItemDamage") then
				env.player.weaponData1.FacebreakerItemDamage = true
				for _, damageType in ipairs({ "Physical", "Lightning", "Cold", "Fire", "Chaos" }) do
					env.player.weaponData1["Facebreaker"..damageType.."Min"] = env.modDB:Sum("BASE", nil, "Facebreaker"..damageType.."Min")
					env.player.weaponData1["Facebreaker"..damageType.."Max"] = env.modDB:Sum("BASE", nil, "Facebreaker"..damageType.."Max")
				end
			end
			env.player.weaponData2 = env.player.weaponData2 or { }
		else
			env.player.weaponData2 = env.player.itemList["Weapon 2"].weaponData and env.player.itemList["Weapon 2"].weaponData[2] or { }
		end

		-- Determine main skill group
		if env.mode == "CALCS" then
			env.calcsInput.skill_number = m_min(m_max(#build.skillsTab.socketGroupList, 1), env.calcsInput.skill_number or 1)
			env.mainSocketGroup = env.calcsInput.skill_number
		else
			build.mainSocketGroup = m_min(m_max(#build.skillsTab.socketGroupList, 1), build.mainSocketGroup or 1)
			env.mainSocketGroup = build.mainSocketGroup
		end

		-- Process supports and put them into the correct buckets
		env.crossLinkedSupportGroups = {}
		for _, mod in ipairs(env.modDB:Tabulate("LIST", nil, "LinkedSupport")) do
			env.crossLinkedSupportGroups[mod.mod.sourceSlot] = env.crossLinkedSupportGroups[mod.mod.sourceSlot] or {}
			t_insert(env.crossLinkedSupportGroups[mod.mod.sourceSlot], mod.value.targetSlotName)
		end

		local supportLists = { }
		local groupCfgList = { }
		local processedSockets = {}
		-- Process support gems adding them to applicable support lists
		for index, group in ipairs(build.skillsTab.socketGroupList) do
			local slot = group.slot and build.itemsTab.slots[group.slot]
			group.slotEnabled = not slot or not slot.weaponSet or slot.weaponSet == (build.itemsTab.activeItemSet.useSecondWeaponSet and 2 or 1)
			-- if group is main skill or group is enabled
			if index == env.mainSocketGroup or (group.enabled and group.slotEnabled) then
				local slotName = group.slot and group.slot:gsub(" Swap","")
				groupCfgList[slotName or "noSlot"] = groupCfgList[slotName or "noSlot"] or {}
				groupCfgList[slotName or "noSlot"][group] = groupCfgList[slotName or "noSlot"][group] or {
					slotName = slotName,
					propertyModList = env.modDB:Tabulate("LIST", {slotName = slotName}, "GemProperty")
				}
				local groupCfg = groupCfgList[slotName or "noSlot"][group]
				local propertyModList = groupCfg.propertyModList
				local targetListList = {}
				if groupCfg.slotName then
					supportLists[groupCfg.slotName] = supportLists[groupCfg.slotName] or {}
					supportLists[groupCfg.slotName][group] = supportLists[groupCfg.slotName][group] or {}
					t_insert(targetListList, supportLists[groupCfg.slotName][group])
				else
					supportLists[group] = supportLists[group] or {}
					t_insert(targetListList, supportLists[group])
				end

				-- if not unique item that provides skills
				if not group.source then
					-- Add extra supports from the item this group is socketed in
					for _, value in ipairs(env.modDB:List(groupCfg, "ExtraSupport")) do
						local grantedEffect = env.data.skills[value.skillId]
						-- Some skill gems share the same name as support gems, e.g. Barrage.
						-- Since a support gem is expected here, if the first lookup returns a skill, then
						-- prepending "Support" to the skillId will find the support version of the gem.
						if grantedEffect and not grantedEffect.support then
							grantedEffect = env.data.skills["Support"..value.skillId]
						end
						grantedEffect.fromItem = true
						if grantedEffect then
							for _, targetList in ipairs(targetListList) do
								t_insert(targetList, {
									grantedEffect = grantedEffect,
									gemData = env.data.gems[env.data.gemForBaseName[grantedEffect.name:lower()] or env.data.gemForBaseName[(grantedEffect.name .. " Support"):lower()]],
									level = value.level,
									quality = 0,
									enabled = true,
									isSupporting = { },
								})
							end
						end
					end
				end

				for gemIndex, gemInstance in ipairs(group.gemList) do
					-- Add support gems from this group
					if env.mode == "MAIN" then
						gemInstance.displayEffect = nil
						gemInstance.supportEffect = nil
					end
					if gemInstance.enabled then
						if gemInstance.gemData then
							processGrantedEffect(gemInstance.gemData.grantedEffect, gemInstance, env, groupCfg, gemIndex, propertyModList, processedSockets, targetListList)
							for _, additional in ipairs(gemInstance.gemData.additionalGrantedEffects) do
								processGrantedEffect(additional, gemInstance, env, groupCfg, gemIndex, propertyModList, processedSockets, targetListList)
							end
						else
							processGrantedEffect(gemInstance.grantedEffect, gemInstance, env, groupCfg, gemIndex, propertyModList, processedSockets, targetListList)
						end
					end
				end
			end
		end

		-- Process active skills adding the applicable supports
		local socketGroupSkillListList = { }
		for index, group in ipairs(build.skillsTab.socketGroupList) do
			if index == env.mainSocketGroup or (group.enabled and group.slotEnabled) then
				local slotName = group.slot and group.slot:gsub(" Swap","")
				groupCfgList[slotName or "noSlot"][group] = groupCfgList[slotName or "noSlot"][group] or {
					slotName = slotName,
					propertyModList = env.modDB:Tabulate("LIST", {slotName = slotName}, "GemProperty")
				}
				local groupCfg = groupCfgList[slotName or "noSlot"][group]
				local propertyModList = groupCfg.propertyModList
				socketGroupSkillListList[slotName or "noSlot"] = socketGroupSkillListList[slotName or "noSlot"] or {}
				socketGroupSkillListList[slotName or "noSlot"][group] = socketGroupSkillListList[slotName or "noSlot"][group] or {}
				local socketGroupSkillList = socketGroupSkillListList[slotName or "noSlot"][group]
				local slotHasActiveSkill = false

				-- Create active skills
				for gemIndex, gemInstance in ipairs(group.gemList) do
					if gemInstance.enabled and (gemInstance.gemData or gemInstance.grantedEffect) then
						local grantedEffectList = gemInstance.gemData and gemInstance.gemData.grantedEffectList or { gemInstance.grantedEffect }
						for index, grantedEffect in ipairs(grantedEffectList) do
							if not grantedEffect.support and not grantedEffect.hideFromSideBar and (not grantedEffect.hasGlobalEffect or gemInstance["enableGlobal"..index]) then
								slotHasActiveSkill = true
								if gemInstance.gemData and not virtuousMoteSkillCounted[gemInstance] and not (group.gemList[gemIndex].fromNode or group.gemList[gemIndex].fromItem) then
									virtuousMoteSkillCounted[gemInstance] = true
									local requiredAttributes = { }
									if gemInstance.gemData.reqStr > 0 then
										t_insert(requiredAttributes, "Str")
									end
									if gemInstance.gemData.reqDex > 0 then
										t_insert(requiredAttributes, "Dex")
									end
									if gemInstance.gemData.reqInt > 0 then
										t_insert(requiredAttributes, "Int")
									end
									local moteValue = #requiredAttributes == 1 and 2 or 1
									for _, attr in ipairs(requiredAttributes) do
										virtuousMoteSkillCount[attr] = virtuousMoteSkillCount[attr] + moteValue
									end
								end
								local activeEffect = {
									grantedEffect = grantedEffect,
									level = gemInstance.level,
									quality = gemInstance.quality,
									qualityId = gemInstance.qualityId,
									corrupted = gemInstance.corrupted,
									corruptLevel = gemInstance.corruptLevel,
									srcInstance = gemInstance,
									gemData = gemInstance.gemData,
								}
								if activeEffect.corruptLevel then
									activeEffect.level = m_max(activeEffect.level + activeEffect.corruptLevel, 1)
								end
								if env.mode == "CALCS" then
									activeEffect.statSetCalcs = { index = gemInstance.statSetCalcs and gemInstance.statSetCalcs[grantedEffect.id] or 1}
								else
									activeEffect.statSet = { index = gemInstance.statSet and gemInstance.statSet[grantedEffect.id] or 1}
								end
								if gemInstance.gemData then
									local playerItems = env.player.itemList
									local socketedIn = playerItems[groupCfg.slotName] and playerItems[groupCfg.slotName].sockets and playerItems[groupCfg.slotName].sockets[gemIndex]
									applyGemMods(activeEffect, socketedIn and getGemModList(env, groupCfg, socketedIn.color, gemIndex) or propertyModList)
									if not processedSockets[gemInstance] then
										processedSockets[gemInstance] = true
										applySocketMods(env, gemInstance.gemData, groupCfg, gemIndex, playerItems[groupCfg.slotName] and playerItems[groupCfg.slotName].name)
										-- Keep track of the gem count for each color socketed in this group
										groupCfg.intelligenceGems = (groupCfg.intelligenceGems or 0) + (gemInstance.gemData.tags.intelligence and 1 or 0)
										groupCfg.dexterityGems = (groupCfg.dexterityGems or 0) + (gemInstance.gemData.tags.dexterity and 1 or 0)
										groupCfg.strengthGems = (groupCfg.strengthGems or 0) + (gemInstance.gemData.tags.strength and 1 or 0)
									end
								end
								if env.mode == "MAIN" then
									gemInstance.displayEffect = activeEffect
								end
								local appliedSupportList = {}
								if not group.noSupports then
									appliedSupportList = copyTable(supportLists[group] or supportLists[slotName][group], true)
									-- add displayGemList for tooltip to display all gems linked to active skills
									group.displayGemList = copyTable(group.gemList, true)
									-- if skill granted by unique item, go through all support groups in slot
									if group.source then
										if supportLists[slotName] then
											-- add socketed supports from other socketGroups
											for _, otherSocketGroup in ipairs(build.skillsTab.socketGroupList) do
												if otherSocketGroup.slot and otherSocketGroup.slot == group.slot then
													for _, gem in ipairs(otherSocketGroup.gemList) do
														if gem.gemData and gem.gemData.grantedEffect and gem.gemData.grantedEffect.support then
															t_insert(group.displayGemList, gem)
														end
													end
												end
											end
											for _, supportGroup in pairs(supportLists[slotName]) do
												for _, supportEffect in ipairs(supportGroup) do
													addBestSupport(supportEffect, appliedSupportList, env.mode)
												end
											end
										end
									end
									-- then add supports from crossLinked socketGroups
									for crossLinkedSupportSlot, crossLinkedSupportGroup in pairs(env.crossLinkedSupportGroups) do
										for _, crossLinkedSupportedSlot in ipairs(crossLinkedSupportGroup) do
											if crossLinkedSupportedSlot == slotName and supportLists[crossLinkedSupportSlot] then
												for _, otherSocketGroup in ipairs(build.skillsTab.socketGroupList) do
													if otherSocketGroup.slot and otherSocketGroup.slot == crossLinkedSupportSlot then
														for _, gem in ipairs(otherSocketGroup.gemList) do
															if gem.gemData and gem.gemData.grantedEffect and gem.gemData.grantedEffect.support then
																t_insert(group.displayGemList, gem)
															end
														end
													end
												end
												for _, supportGroup in pairs(supportLists[crossLinkedSupportSlot]) do
													for _, supportEffect in ipairs(supportGroup) do
														addBestSupport(supportEffect, appliedSupportList, env.mode)
													end
												end
											end
										end
									end
								end
								local activeSkill = calcs.createActiveSkill(activeEffect, appliedSupportList, env, env.player, group)
								if gemInstance.gemData then
									activeSkill.slotName = groupCfg.slotName
								end
								t_insert(socketGroupSkillList, activeSkill)
								t_insert(env.player.activeSkillList, activeSkill)
							end
						end
						if gemInstance.gemData and not (accelerate.requirementsGems or group.gemList[gemIndex].fromNode or group.gemList[gemIndex].fromItem) then
							t_insert(env.requirementsTableGems, {
								source = "Gem",
								sourceGem = gemInstance,
								Str = gemInstance.reqStr,
								Dex = gemInstance.reqDex,
								Int = gemInstance.reqInt,
							})
						end
					end
				end

				if not slotHasActiveSkill and group.displayGemList then
					group.displayGemList = nil
				end
			end
		end

		-- Process calculated active skill lists
		for index, group in ipairs(build.skillsTab.socketGroupList) do
			local slotName = group.slot and group.slot:gsub(" Swap","")
			socketGroupSkillListList[slotName or "noSlot"] = socketGroupSkillListList[slotName or "noSlot"] or {}
			socketGroupSkillListList[slotName or "noSlot"][group] = socketGroupSkillListList[slotName or "noSlot"][group] or {}
			local socketGroupSkillList = socketGroupSkillListList[slotName or "noSlot"][group]
			if index == env.mainSocketGroup or (group.enabled and group.slotEnabled) then
				groupCfgList[slotName or "noSlot"][group] = groupCfgList[slotName or "noSlot"][group] or {
					slotName = slotName,
					propertyModList = env.modDB:Tabulate("LIST", {slotName = slotName}, "GemProperty")
				}
				local groupCfg = groupCfgList[slotName or "noSlot"][group]
				for _, value in ipairs(env.modDB:List(groupCfg, "GroupProperty")) do
					env.player.modDB:AddMod(modLib.setSource(value.value, groupCfg.slotName or ""))
				end

				if index == env.mainSocketGroup and #socketGroupSkillList > 0 then
					-- Select the main skill from this socket group
					local activeSkillIndex
					if env.mode == "CALCS" then
						group.mainActiveSkillCalcs = m_min(#socketGroupSkillList, group.mainActiveSkillCalcs or 1)
						activeSkillIndex = group.mainActiveSkillCalcs
					else
						activeSkillIndex = m_min(#socketGroupSkillList, group.mainActiveSkill or 1)
						if env.mode == "MAIN" then
							group.mainActiveSkill = activeSkillIndex
						end
					end
					env.player.mainSkill = socketGroupSkillList[activeSkillIndex]
				end
			end

			if env.mode == "MAIN" then
				-- Create display label for the socket group if the user didn't specify one
				if group.label and group.label:match("%S") then
					group.displayLabel = group.label
				else
					group.displayLabel = nil
					for _, gemInstance in ipairs(group.gemList) do
						local grantedEffect = gemInstance.gemData and gemInstance.gemData.grantedEffect or gemInstance.grantedEffect
						local gemName = gemInstance.gemData and gemInstance.gemData.name
						if grantedEffect and not grantedEffect.support and gemInstance.enabled then
							if grantedEffect.name:match("^Companion:") or grantedEffect.name:match("^Spectre:") then
								group.displayLabel = (group.displayLabel and group.displayLabel..", " or "") .. gemInstance.nameSpec
							else
								group.displayLabel = (group.displayLabel and group.displayLabel..", " or "") .. (gemName or grantedEffect.name)
							end
						end
					end
					group.displayLabel = group.displayLabel or "<No active skills>"
				end

				-- Save the active skill list for display in the socket group tooltip
				group.displaySkillList = socketGroupSkillList
			elseif env.mode == "CALCS" then
				group.displaySkillListCalcs = socketGroupSkillList
			end

			-- Check for enabled energy blade to see if we need to regenerate everything.
			if not modDB.conditions["AffectedByEnergyBlade"] and group.enabled and group.slotEnabled then
				for _, gemInstance in ipairs(group.gemList) do
					local grantedEffect = gemInstance.gemData and gemInstance.gemData.grantedEffect or gemInstance.grantedEffect
					if grantedEffect and not grantedEffect.support and gemInstance.enabled and grantedEffect.name == "Energy Blade" then
						override.conditions = override.conditions or { }
						t_insert(override.conditions, "AffectedByEnergyBlade")
						return calcs.initEnv(build, mode, override, specEnv)
					end
				end
			end
		end

		-- UPDATE THIS TO ADD DEFAULT SKILLS FOR EACH WEAPON
		if not env.player.mainSkill then
			-- Add a default main skill if none are specified
			local defaultEffect = {
				grantedEffect = env.data.skills.MeleeUnarmedPlayer,
				level = 1,
				quality = 0,
				enabled = true,
				statSet = { index = 1},
				statSetCalcs = { index = 1}
			}
			env.player.mainSkill = calcs.createActiveSkill(defaultEffect, { }, env, env.player)
			t_insert(env.player.activeSkillList, env.player.mainSkill)
		end

		-- Build skill modifier lists
		for _, activeSkill in pairs(env.player.activeSkillList) do
			calcs.buildActiveSkillModList(env, activeSkill)
		end
	else
		-- Wipe skillData and readd required data the rest of the data will be added by the rest of code this stops iterative calculations on skillData not being reset
		for _, activeSkill in pairs(env.player.activeSkillList) do
			local skillData = copyTable(activeSkill.skillData, true)
			activeSkill.skillData = { }
			for _, value in ipairs(env.modDB:List(activeSkill.skillCfg, "SkillData")) do
				activeSkill.skillData[value.key] = value.value
			end
			for _, value in ipairs(activeSkill.skillModList:List(activeSkill.skillCfg, "SkillData")) do
				activeSkill.skillData[value.key] = value.value
			end
			-- These mods were modified with special expressions in buildActiveSkillModList() use old one to avoid more calculations
			activeSkill.skillData.manaReservationPercent = skillData.manaReservationPercent
			activeSkill.skillData.cooldown = skillData.cooldown
			activeSkill.skillData.storedUses = skillData.storedUses
			activeSkill.skillData.CritChance = skillData.CritChance
			activeSkill.skillData.attackTime = skillData.attackTime
			activeSkill.skillData.attackSpeedMultiplier = skillData.attackSpeedMultiplier
			activeSkill.skillData.soulPreventionDuration = skillData.soulPreventionDuration
			activeSkill.skillData.totemLevel = skillData.totemLevel
			activeSkill.skillData.damageEffectiveness = skillData.damageEffectiveness
			activeSkill.skillData.manaReservationPercent = skillData.manaReservationPercent
		end
	end

	env.virtuousMoteSkillCount = virtuousMoteSkillCount
	env.modDB.multipliers.StrengthMoteSkillCount = virtuousMoteSkillCount.Str
	env.modDB.multipliers.DexterityMoteSkillCount = virtuousMoteSkillCount.Dex
	env.modDB.multipliers.IntelligenceMoteSkillCount = virtuousMoteSkillCount.Int

	-- This needs to be done here at the end as otherwise we will only consider gems in the
	-- selected active skill group
	-- Calculate skill gem and support gem counts
	-- Currently PoB2 doesn't associate weapon skill supports with the actual weapon sets
	-- so it ends up counting all support gems when it should only take into account the active weapon set
	local slotSupportGemSocketsCount = { R = 0, G = 0, B = 0 }
	-- Loop through socket groups to calculate number of socketed gems
	for _, socketGroup in pairs(env.build.skillsTab.socketGroupList) do
		local socketedSupportGems = 0
		if (socketGroup.enabled and socketGroup.gemList) then
			for _, gem in pairs(socketGroup.gemList) do
				if gem.supportEffect and gem.supportEffect.grantedEffect and not gem.supportEffect.grantedEffect.hidden then
					socketedSupportGems = socketedSupportGems + 1
					if gem.supportEffect.grantedEffect.color == 1 then
						slotSupportGemSocketsCount.R = slotSupportGemSocketsCount.R + 1
					elseif gem.supportEffect.grantedEffect.color == 2 then
						slotSupportGemSocketsCount.G = slotSupportGemSocketsCount.G + 1
					elseif gem.supportEffect.grantedEffect.color == 3 then
						slotSupportGemSocketsCount.B = slotSupportGemSocketsCount.B + 1
					end
				end
			end
		end
		-- Warn if socketed gems over socket limit
		if socketedSupportGems > 5 then
			if env.build.calcsTab.mainEnv then
				env.build.calcsTab.mainEnv.itemWarnings.socketLimitWarning = env.build.calcsTab.mainEnv.itemWarnings.socketLimitWarning or { }
				t_insert(env.build.calcsTab.mainEnv.itemWarnings.socketLimitWarning, socketGroup.displayLabel)
			end
		end
	end
	env.modDB.multipliers.RedSupportGems = (env.modDB.multipliers.RedSupportGems or 0) + slotSupportGemSocketsCount.R
	env.modDB.multipliers.GreenSupportGems = (env.modDB.multipliers.GreenSupportGems or 0) + slotSupportGemSocketsCount.G
	env.modDB.multipliers.BlueSupportGems = (env.modDB.multipliers.BlueSupportGems or 0) + slotSupportGemSocketsCount.B
	t_insert(env.requirementsTableGems, {
		source = "Support Gems",
		--sourceName = slotSupportGemSocketsCount.G .. " Green Support Gems",
		Str = tonumber(slotSupportGemSocketsCount.R * 5),
		Dex = tonumber(slotSupportGemSocketsCount.G * 5),
		Int = tonumber(slotSupportGemSocketsCount.B * 5),
	})

	-- Merge Requirements Tables
	env.requirementsTable = tableConcat(env.requirementsTableItems, env.requirementsTableGems)

	-- Crystallised Immunity notable support
	if (slotSupportGemSocketsCount.R > slotSupportGemSocketsCount.G) and (slotSupportGemSocketsCount.R > slotSupportGemSocketsCount.B) then
		env.modDB.conditions["MajorityRedSocketedSupports"] = true;
	elseif (slotSupportGemSocketsCount.G > slotSupportGemSocketsCount.R) and (slotSupportGemSocketsCount.G > slotSupportGemSocketsCount.B) then
		env.modDB.conditions["MajorityGreenSocketedSupports"] = true;
	elseif (slotSupportGemSocketsCount.B > slotSupportGemSocketsCount.R) and (slotSupportGemSocketsCount.B > slotSupportGemSocketsCount.G) then
		env.modDB.conditions["MajorityBlueSocketedSupports"] = true;
	end

	-- Gem Studded, Gemling notable support
	if (slotSupportGemSocketsCount.R >= slotSupportGemSocketsCount.G) and (slotSupportGemSocketsCount.R >= slotSupportGemSocketsCount.B) then
		env.modDB.conditions["MostNumerousRedSocketedSupports"] = true;
	elseif (slotSupportGemSocketsCount.G >= slotSupportGemSocketsCount.R) and (slotSupportGemSocketsCount.G >= slotSupportGemSocketsCount.B) then
		env.modDB.conditions["MostNumerousGreenSocketedSupports"] = true;
	elseif (slotSupportGemSocketsCount.B >= slotSupportGemSocketsCount.R) and (slotSupportGemSocketsCount.B >= slotSupportGemSocketsCount.G) then
		env.modDB.conditions["MostNumerousBlueSocketedSupports"] = true;
	end

	return env, cachedPlayerDB, cachedEnemyDB, cachedMinionDB
end
